# Life Planner - ONE LIFE (Version 1.2)

Kotlin - Jetpack Compose - Material 3 - Room - MVVM-style layers. Offline first.

## Layers
- domain/  pure Kotlin: XP, levels, anti-farm rules, use cases, RPG engine, goal analyzer, schedule templates, shop catalog
- data/    Room entities + DAOs (dates stored ISO yyyy-MM-dd, independent of language/calendar), JSON backup
- core/    Persian calendar (Jalali <-> Gregorian), SecureStore (encrypted prefs, hashed PIN + recovery code), AI client, perf, reminders
- theme/   ThemeConfig (.lptheme JSON, versioned/lenient) + shop presets
- ui/      Compose screens, custom line-icon pack (Icons.kt), Liquid Glass (Glass.kt), widgets, hero art, item art

## Architecture
ui (Compose) -> ViewModel (TaskViewModel, GoalViewModel) -> Repository (data/Repositories.kt) -> Room DAOs. Business rules (XP, repeats, templates, goal cascade) are not in composables.

## Version 2 hooks
Add features by adding a DAO/entity + Room Migration (see MIGRATION_1_2), a use case in domain/, and a screen in ui/.
Shop items are data (ShopCatalog); themes are data (ThemeConfig); backup is versioned JSON.

## Build
Open in Android Studio (Ladybug or newer), let Gradle sync (it downloads Gradle 8.9 from gradle/wrapper; run `gradle wrapper` once if you want the gradlew script), run on a device (minSdk 26). Run unit tests: ./gradlew test

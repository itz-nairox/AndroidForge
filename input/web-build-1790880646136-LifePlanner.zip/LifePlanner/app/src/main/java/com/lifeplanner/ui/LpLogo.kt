package com.lifeplanner.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Life Planner logo drawn in code (same geometry as res/drawable/ic_launcher_foreground.xml). */
@Composable
fun LpLogo(size: Dp = 56.dp, modifier: Modifier = Modifier) {
    val bg = Brush.linearGradient(listOf(Color.White, Color(0xFFE4D9FF)))
    Canvas(modifier.size(size).clip(RoundedCornerShape(size * 0.24f)).background(bg)) {
        val st = { w: Float -> Stroke(w, cap = StrokeCap.Round, join = StrokeJoin.Round) }
        scale(this.size.minDimension / 108f, Offset.Zero) {
            val l = Path().apply { moveTo(36f, 30f); lineTo(36f, 74f); lineTo(62f, 74f) }
            val p = Path().apply {
                moveTo(52f, 74f); lineTo(52f, 32f); lineTo(61f, 32f)
                arcTo(Rect(50f, 32f, 72f, 54f), -90f, 180f, false); lineTo(52f, 54f)
            }
            drawPath(l, Color(0xFF4A22C9), style = st(9f))
            drawPath(p, Color(0xFFF4EEFF), style = st(16f))     // cut-through gap
            drawPath(p, Color(0xFF9B6BFF), style = st(9f))
            val spark = Path().apply { moveTo(78f,24f); lineTo(80f,30f); lineTo(86f,32f); lineTo(80f,34f); lineTo(78f,40f); lineTo(76f,34f); lineTo(70f,32f); lineTo(76f,30f); close() }
            drawPath(spark, Color(0xFF4A22C9))
        }
    }
}

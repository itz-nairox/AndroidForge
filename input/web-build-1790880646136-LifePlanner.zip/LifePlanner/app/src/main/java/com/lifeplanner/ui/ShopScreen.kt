package com.lifeplanner.ui

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lifeplanner.data.AppDatabase
import com.lifeplanner.domain.*
import com.lifeplanner.theme.ThemePresets
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun ShopScreen(db: AppDatabase, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val g = LocalGlass.current
    val balance by remember { db.xp().total() }.collectAsState(0)
    val owned by remember { db.owned().all() }.collectAsState(emptyList())
    val buy = remember { PurchaseUseCase(db) }
    val haptic = rememberHaptic()
    val ctl = LocalThemeCtl.current
    var msg by remember { mutableStateOf("") }
    var preview by remember { mutableStateOf<ShopItem?>(null) }
    LaunchedEffect(msg) { if (msg.isNotEmpty()) { delay(2200); msg = "" } }

    preview?.let { it ->
        ThemePreviewDialog(ThemePresets.of(it.id), it.price, balance, owned.any { o -> o.itemId == it.id },
            onBuy = { scope.launch { if (buy(it, balance)) { haptic(); msg = "Unlocked ${it.name}"; preview = null } else msg = "Not enough XP" } }, onClose = { preview = null })
    }
    Column(Modifier.padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { LIcon(LpIcon.Back) }
            Text("Shop", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
            LIcon(LpIcon.Xp, tint = MaterialTheme.colorScheme.primary, size = 20.dp); Spacer(Modifier.width(4.dp)); Text("$balance XP", style = MaterialTheme.typography.titleMedium)
        }
        AnimatedVisibility(msg.isNotEmpty(), enter = if (g.animations) scaleIn() + fadeIn() else EnterTransition.None, exit = fadeOut()) {
            Text(msg, Modifier.fillMaxWidth().glassSurface().padding(12.dp), color = MaterialTheme.colorScheme.primary) }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(g.spacing.dp)) {
            ItemType.values().forEach { type ->
                item { SectionTitle(type.name, when (type) { ItemType.THEME -> LpIcon.Palette; ItemType.PLAYER -> LpIcon.Football; ItemType.CAR -> LpIcon.Car }) }
                items(ShopCatalog.items.filter { it.type == type }, key = { it.id }) { it ->
                    val o = owned.firstOrNull { x -> x.itemId == it.id }
                    Row(Modifier.fillMaxWidth().glassSurface().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        if (type != ItemType.THEME) ItemArt(it.id, 56.dp) else LIcon(LpIcon.Palette, tint = MaterialTheme.colorScheme.primary, size = 32.dp)
                        Column(Modifier.weight(1f)) { Text(it.name, style = MaterialTheme.typography.titleSmall); if (it.rarity.isNotEmpty()) Text(it.rarity, style = MaterialTheme.typography.labelSmall) }
                        if (o == null) {
                            if (type == ItemType.THEME) TextButton({ preview = it }) { Text("Preview") }
                            LpButton({ scope.launch { if (buy(it, balance)) { haptic(); msg = "Unlocked ${it.name}" } else msg = "Not enough XP" } }, enabled = balance >= it.price) { Text("${it.price} XP") }
                        } else LpOutlinedButton({ scope.launch {
                            db.owned().equip(it, !o.active)
                            if (type == ItemType.THEME) ctl.set(if (!o.active) ThemePresets.of(it.id) else com.lifeplanner.theme.ThemeConfig("Default")) } }) { Text(if (o.active) "Active" else "Activate") }
                    }
                }
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

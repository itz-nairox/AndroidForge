package com.lifeplanner.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** ONE LIFE hero: original vector artwork (effort -> progress -> success): a climbing track, rising steps and a summit star. */
@Composable
fun HeroSection(modifier: Modifier = Modifier) {
    val g = LocalGlass.current
    val accent = MaterialTheme.colorScheme.primary
    val on = MaterialTheme.colorScheme.onSurface
    val t by rememberInfiniteTransition(label = "hero").animateFloat(0f, 1f, infiniteRepeatable(tween(4200, easing = LinearEasing), RepeatMode.Reverse), label = "t")
    val pulse = if (g.animations && g.decor) t else 0.5f
    Box(modifier.fillMaxWidth().height(170.dp).glassSurface()) {
        if (g.decor) Canvas(Modifier.matchParentSize()) {
            val w = size.width; val h = size.height
            // rising steps
            val steps = 6
            for (i in 0 until steps) {
                val sx = w * (0.42f + i * 0.09f); val sh = h * (0.18f + i * 0.11f)
                drawRoundRect(accent.copy(alpha = 0.10f + i * 0.05f), Offset(sx, h - sh - 14f), androidx.compose.ui.geometry.Size(w * 0.075f, sh), androidx.compose.ui.geometry.CornerRadius(10f))
            }
            // track line rising to the summit
            val path = Path().apply {
                moveTo(w * 0.05f, h * 0.88f); cubicTo(w * 0.30f, h * 0.90f, w * 0.45f, h * 0.60f, w * 0.62f, h * 0.55f)
                cubicTo(w * 0.78f, h * 0.50f, w * 0.85f, h * 0.30f, w * 0.93f, h * 0.16f)
            }
            drawPath(path, accent.copy(alpha = 0.85f), style = Stroke(5f, cap = StrokeCap.Round))
            // summit star with soft pulse
            val c = Offset(w * 0.93f, h * 0.16f)
            if (g.glow) drawCircle(accent.copy(alpha = 0.18f + 0.22f * pulse), radius = 26f + 14f * pulse, center = c)
            val star = Path().apply {
                val r1 = 14f; val r2 = 5.5f
                for (k in 0 until 8) { val r = if (k % 2 == 0) r1 else r2; val a = Math.PI / 4 * k - Math.PI / 2
                    val x = c.x + (r * Math.cos(a)).toFloat(); val y = c.y + (r * Math.sin(a)).toFloat(); if (k == 0) moveTo(x, y) else lineTo(x, y) }
                close()
            }
            drawPath(star, accent)
        }
        Column(Modifier.padding(20.dp).align(Alignment.CenterStart)) {
            // Outline / hollow lettering
            val outline = TextStyle(fontSize = 40.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp,
                drawStyle = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f, join = StrokeJoin.Round), color = accent)
            androidx.compose.material3.Text("ONE", style = outline)
            androidx.compose.material3.Text("LIFE", style = outline)
            Spacer(Modifier.height(4.dp))
            Text("Plan it. Build it. Live it.", color = on.copy(alpha = 0.75f), style = MaterialTheme.typography.labelMedium)
        }
    }
}

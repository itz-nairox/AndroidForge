package com.lifeplanner.domain

enum class ItemType { THEME, PLAYER, CAR }
data class ShopItem(val id: String, val name: String, val type: ItemType, val price: Int, val rarity: String = "")

/** Prices live here (single config point). Player/car art must be original or licensed. */
object ShopCatalog {
    val items = listOf(
        ShopItem("theme_glass_studio", "Liquid Glass Studio", ItemType.THEME, 500),
        ShopItem("theme_midnight", "Midnight Galaxy", ItemType.THEME, 600),
        ShopItem("theme_ocean", "Ocean Depth", ItemType.THEME, 650),
        ShopItem("theme_forest", "Forest", ItemType.THEME, 700),
        ShopItem("theme_sunset", "Sunset", ItemType.THEME, 750),
        ShopItem("theme_sakura", "Sakura", ItemType.THEME, 800),
        ShopItem("theme_neon", "Cyber Neon", ItemType.THEME, 900),
        ShopItem("theme_gold", "Legendary Gold", ItemType.THEME, 1000),
        ShopItem("player_common", "Rookie Striker", ItemType.PLAYER, 250, "Common"),
        ShopItem("player_rare", "Playmaker", ItemType.PLAYER, 400, "Rare"),
        ShopItem("player_epic", "Captain", ItemType.PLAYER, 550, "Epic"),
        ShopItem("player_legend", "Legend Forward", ItemType.PLAYER, 700, "Legendary"),
        ShopItem("car_common", "Street Coupe", ItemType.CAR, 400, "Common"),
        ShopItem("car_rare", "Track Racer", ItemType.CAR, 550, "Rare"),
        ShopItem("car_epic", "Turbo GT", ItemType.CAR, 700, "Epic"),
        ShopItem("car_legend", "Hyper Legend", ItemType.CAR, 800, "Legendary"))
}

/** One active item per kind (theme / player / car). */
suspend fun com.lifeplanner.data.OwnedDao.equip(item: ShopItem, on: Boolean) {
    setActive(item.id, on); if (on) deactivateOthers(item.id.substringBefore("_") + "_", item.id)
}

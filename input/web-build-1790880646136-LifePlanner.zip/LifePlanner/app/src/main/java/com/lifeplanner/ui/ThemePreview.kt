package com.lifeplanner.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.lifeplanner.theme.ThemeConfig

private val pages = listOf("Home", "Calendar", "Goals", "Statistics", "Shop")

/** Try a theme on five mock screens before paying. Nothing is applied to the real app until the user unlocks it. */
@Composable
fun ThemePreviewDialog(cfg: ThemeConfig, price: Int, balance: Int, owned: Boolean, onBuy: () -> Unit, onClose: () -> Unit) {
    var page by remember { mutableIntStateOf(0) }
    val fa = LocalLang.current == "fa"
    Dialog(onDismissRequest = onClose) {
        CompositionLocalProvider(LocalGlass provides cfg, LocalParallax provides remember { mutableStateOf(Offset.Zero) }) {
            LifePlannerTheme(cfg) {
                Surface(shape = RoundedCornerShape(cfg.dialogRadius.dp), color = MaterialTheme.colorScheme.background) {
                    PageBackground(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(cfg.name, style = MaterialTheme.typography.titleLarge)
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                pages.forEachIndexed { i, p -> FilterChip(page == i, { page = i }, label = { Text(p) }) } }
                            Column(Modifier.fillMaxWidth().height(250.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                when (page) {
                                    0 -> { Row(Modifier.fillMaxWidth().glassSurface().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                            LpLogo(40.dp); Column(Modifier.weight(1f)) { Text("Level 4"); Text("ONE LIFE", style = MaterialTheme.typography.labelSmall) } }
                                        Column(Modifier.fillMaxWidth().glassSurface().padding(10.dp)) { Text("Today's Progress"); LpProgress(0.62f, ring = 52.dp) }
                                        LpButton({}) { LIcon(LpIcon.Add, size = 18.dp); Text("Quick add") } }
                                    1 -> Column(Modifier.fillMaxWidth().glassSurface().padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        repeat(3) { r -> Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) { repeat(7) { c ->
                                            Box(Modifier.size(28.dp).clip(CircleShape).background(if (r == 1 && c == 3) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primary.copy(alpha = 0.10f)), Alignment.Center) { Text("${r * 7 + c + 1}", style = MaterialTheme.typography.labelSmall) } } } } }
                                    2 -> listOf("IELTS 7.5" to 0.64f, "Programming" to 0.41f, "University" to 0.2f).forEach { (n, p) ->
                                        Row(Modifier.fillMaxWidth().glassSurface().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                            LIcon(LpIcon.Goals, tint = MaterialTheme.colorScheme.primary); Column(Modifier.weight(1f)) { Text(n); LinearProgressIndicator(progress = { p }, Modifier.fillMaxWidth().padding(top = 4.dp)) } } }
                                    3 -> Row(Modifier.fillMaxWidth().height(200.dp).glassSurface().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
                                        listOf(30, 60, 45, 90, 70, 110, 80).forEach { v -> Box(Modifier.weight(1f).height(v.dp).background(MaterialTheme.colorScheme.primary, RoundedCornerShape(cfg.progressRadius.coerceAtMost(8).dp))) } }
                                    else -> Row(Modifier.fillMaxWidth().glassSurface().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        ItemArt("player_epic"); Column(Modifier.weight(1f)) { Text("Captain"); Text("Epic", style = MaterialTheme.typography.labelSmall) }; LpButton({}) { Text("550 XP") } }
                                }
                            }
                            if (!owned) LpButton(onBuy, Modifier.fillMaxWidth(), enabled = balance >= price) { Text(if (fa) "باز کردن با $price XP" else "Unlock for $price XP") }
                            TextButton(onClose, Modifier.align(Alignment.End)) { Text("Back") }
                        }
                    }
                }
            }
        }
    }
}

package com.lifeplanner

import android.app.Application
import androidx.room.Room
import com.lifeplanner.data.AppDatabase
import com.lifeplanner.data.MIGRATION_1_2

class App : Application() {
    lateinit var db: AppDatabase
    val secure by lazy { com.lifeplanner.core.SecureStore(this) }
    override fun onCreate() {
        super.onCreate()
        db = Room.databaseBuilder(this, AppDatabase::class.java, "lifeplanner.db").addMigrations(MIGRATION_1_2).build()
    }
}

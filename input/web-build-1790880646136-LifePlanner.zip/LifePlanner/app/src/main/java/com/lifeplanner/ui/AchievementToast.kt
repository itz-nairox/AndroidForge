package com.lifeplanner.ui

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lifeplanner.core.SecureStore
import com.lifeplanner.data.AppDatabase
import com.lifeplanner.domain.RpgEngine
import kotlinx.coroutines.delay

/** Shows an unlock banner (with haptic) once for every newly earned achievement, on any screen. */
@Composable
fun AchievementWatcher(db: AppDatabase, secure: SecureStore, modifier: Modifier = Modifier) {
    val g = LocalGlass.current; val haptic = rememberHaptic()
    val stats = rememberRpgStats(db)
    var banner by remember { mutableStateOf<String?>(null) }
    val all = RpgEngine.achievements(stats)
    LaunchedEffect(all.filter { it.unlocked }.map { it.id }) {
        val seen = secure.seenAch
        val fresh = all.filter { it.unlocked && it.id !in seen }
        if (fresh.isNotEmpty()) {
            secure.seenAch = seen + fresh.map { it.id }
            banner = if (fresh.size == 1) fresh[0].title else "${fresh.size} achievements"
            haptic(); delay(3200); banner = null
        }
    }
    AnimatedVisibility(banner != null, modifier.statusBarsPadding().padding(top = 8.dp),
        enter = if (g.animations) scaleIn() + slideInVertically { -it } + fadeIn() else EnterTransition.None,
        exit = if (g.animations) fadeOut() + slideOutVertically { -it } else ExitTransition.None) {
        Row(Modifier.glassSurface().padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            LIcon(LpIcon.Trophy, tint = MaterialTheme.colorScheme.primary, size = 28.dp)
            Column { Text("Achievement unlocked", style = MaterialTheme.typography.labelSmall); Text(banner ?: "", style = MaterialTheme.typography.titleSmall) }
        }
    }
}

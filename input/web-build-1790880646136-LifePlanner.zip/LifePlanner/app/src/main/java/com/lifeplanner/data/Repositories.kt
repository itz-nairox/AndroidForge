package com.lifeplanner.data

import androidx.room.withTransaction
import com.lifeplanner.domain.CompleteTaskUseCase
import com.lifeplanner.domain.Difficulty
import com.lifeplanner.domain.ScheduleTemplates
import java.time.LocalDate

/** All task business rules live here (not in composables): repeats, templates, XP-safe completion. */
class TaskRepository(private val db: AppDatabase) {
    private val completer = CompleteTaskUseCase(db.completions(), db.xp())
    fun tasks(date: String) = db.tasks().byDate(date)
    fun completions(date: String) = db.completions().byDate(date)
    suspend fun complete(t: TaskEntity, date: String): Int = completer(t, date)
    suspend fun undo(t: TaskEntity, date: String) = completer.undo(t, date)

    /** Repeats are materialized (30 days / 8 weeks). XP still pays once per task per date and the daily cap applies. */
    suspend fun add(title: String, date: String, time: String?, durationMin: Int, category: String, diff: Difficulty,
                    customXp: Int?, repeat: String, priority: Int, goalId: Long?) {
        val n = when (repeat) { "DAILY" -> 30; "WEEKLY" -> 8; else -> 1 }; val step = if (repeat == "WEEKLY") 7L else 1L
        val reward = (customXp ?: diff.defaultXp).coerceIn(0, 100)
        val start = LocalDate.parse(date)
        db.withTransaction {
            for (i in 0 until n) db.tasks().insert(TaskEntity(title = title, date = start.plusDays(step * i).toString(), startTime = time,
                durationMin = durationMin.coerceIn(5, 720), category = category, difficulty = diff.name, xpReward = reward,
                repeat = repeat, priority = priority.coerceIn(0, 2), goalId = goalId))
        }
    }
    suspend fun update(t: TaskEntity) = db.tasks().update(t)
    suspend fun delete(t: TaskEntity) { db.tasks().deleteCompletions(t.id); db.tasks().delete(t.id) }
    suspend fun applyTemplate(name: String, date: String, existing: List<TaskEntity>) {
        ScheduleTemplates.toTasks(name, date).filter { x -> existing.none { o -> o.title == x.title && o.startTime == x.startTime } }
            .forEach { db.tasks().insert(it) }
    }
}

class GoalRepository(private val db: AppDatabase) {
    suspend fun addGoal(title: String, deadline: String?) = db.goals().insert(GoalEntity(title = title, deadline = deadline))
    suspend fun deleteGoal(id: Long) = db.withTransaction { db.goals().deleteSubsOf(id); db.goals().detachTasks(id); db.goals().deleteGoal(id) }
    suspend fun addSub(goalId: Long, parentId: Long?, title: String) { db.goals().insertSub(SubGoalEntity(goalId = goalId, parentId = parentId, title = title)) }
    suspend fun updateSub(s: SubGoalEntity) = db.goals().updateSub(s)
    suspend fun deleteSubTree(all: List<SubGoalEntity>, id: Long) {
        fun kids(x: Long): List<Long> = all.filter { it.parentId == x }.flatMap { listOf(it.id) + kids(it.id) }
        db.withTransaction { (kids(id) + id).forEach { db.goals().deleteSub(it) } }
    }
    suspend fun addSession(g: GoalEntity) { db.tasks().insert(TaskEntity(title = "${g.title}: session", date = LocalDate.now().toString(), category = "Study",
        difficulty = "MEDIUM", xpReward = 20, goalId = g.id)) }
}

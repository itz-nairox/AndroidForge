package com.lifeplanner.core

import android.app.Activity
import android.content.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import com.lifeplanner.theme.ThemeConfig

data class Perf(val saver: Boolean = false, val smart: Boolean = true, val refresh: String = "AUTO") // AUTO | HIGH | STANDARD

/** Battery Saver: no glow/motion/reflection, lighter blur and glass. */
fun ThemeConfig.effective(saver: Boolean) =
    if (!saver) this else copy(glow = false, motion = false, reflection = false, animations = false, blur = blur / 3, glassIntensity = glassIntensity / 2)

/** Never forces 120Hz: HIGH only picks the best mode the display itself reports; AUTO leaves the system in charge. */
fun applyRefresh(a: Activity, pref: String) = runCatching {
    @Suppress("DEPRECATION") val d = a.windowManager.defaultDisplay
    val cur = d.mode
    val same = d.supportedModes.filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
    val id = when (pref) {
        "HIGH" -> same.maxByOrNull { it.refreshRate }
        "STANDARD" -> same.minByOrNull { kotlin.math.abs(it.refreshRate - 60f) }
        else -> null
    }?.modeId ?: 0
    a.window.attributes = a.window.attributes.apply { preferredDisplayModeId = id }
}.let { }

@Composable
fun rememberBatteryLow(): Boolean {
    val ctx = LocalContext.current
    var low by remember { mutableStateOf(false) }
    DisposableEffect(ctx) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val l = i.getIntExtra("level", 100); val sc = i.getIntExtra("scale", 100).coerceAtLeast(1)
                low = l * 100 / sc <= 20 && i.getIntExtra("plugged", 0) == 0
            }
        }
        ctx.registerReceiver(r, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        onDispose { ctx.unregisterReceiver(r) }
    }
    return low
}

package com.lifeplanner.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.lifeplanner.core.AiClient
import com.lifeplanner.core.SecureStore
import com.lifeplanner.data.AppDatabase
import com.lifeplanner.domain.XpEngine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.time.LocalDate

@Composable
fun AiSettings(s: SecureStore) {
    val scope = rememberCoroutineScope()
    var on by remember { mutableStateOf(s.aiEnabled) }; var share by remember { mutableStateOf(s.aiShare) }
    var prov by remember { mutableStateOf(s.aiProvider) }; var base by remember { mutableStateOf(s.aiBase) }
    var model by remember { mutableStateOf(s.aiModel) }; var key by remember { mutableStateOf(s.aiKey) }
    var status by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        SectionTitle("AI Configuration", LpIcon.Ai)
        Row(verticalAlignment = Alignment.CenterVertically) { Text("AI enabled", Modifier.weight(1f)); Switch(on, { on = it; s.aiEnabled = it }) }
        Row(verticalAlignment = Alignment.CenterVertically) { Text("Let AI see my app data", Modifier.weight(1f)); Switch(share, { share = it; s.aiShare = it }) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("OPENAI" to "https://api.openai.com/v1", "ANTHROPIC" to "https://api.anthropic.com").forEach { (p, url) ->
                FilterChip(prov == p, { prov = p; s.aiProvider = p; base = url; s.aiBase = url }, label = { Text(p) }) }
        }
        OutlinedTextField(base, { base = it; s.aiBase = it }, label = { Text("Base URL") }, singleLine = true)
        OutlinedTextField(model, { model = it; s.aiModel = it }, label = { Text("Model") }, singleLine = true)
        OutlinedTextField(key, { key = it; s.aiKey = it }, label = { Text("API Key") }, singleLine = true, visualTransformation = PasswordVisualTransformation())
        LpButton(onClick = { scope.launch { status = "Testing..."
            status = AiClient.chat(s, "Reply with OK.", "ping", 64).fold({ "Connected" }, { it.message ?: "Failed" }) } },
            enabled = key.isNotBlank() && model.isNotBlank()) { Text("Test Connection") }
        if (status.isNotEmpty()) Text(status)
    }
}

@Composable
fun AiScreen(db: AppDatabase, s: SecureStore, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }; var answer by remember { mutableStateOf("") }; var busy by remember { mutableStateOf(false) }
    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) { IconButton(onBack) { LIcon(LpIcon.Back) }; LIcon(LpIcon.Ai, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(8.dp)); Text("AI Assistant", style = MaterialTheme.typography.titleLarge) }
        if (!s.aiEnabled || s.aiKey.isBlank() || s.aiModel.isBlank()) { Text("Turn on and configure AI in Settings. The rest of the app works without it."); return@Column }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("How should I plan for IELTS?", "Make my day lighter today.", "Why was my week weak?", "Build tomorrow's plan.").forEach { p ->
                AssistChip({ q = p }, label = { Text(p) }) } }
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), label = { Text("Ask anything") })
        LpButton(enabled = q.isNotBlank() && !busy, onClick = { scope.launch {
            busy = true
            val ctx = if (s.aiShare) {   // data leaves the device only when the user allowed it
                val today = LocalDate.now().toString()
                val tasks = db.tasks().byDate(today).first().joinToString { "${it.startTime ?: ""} ${it.title}" }
                val goals = db.goals().goals().first().joinToString { it.title }
                val lv = XpEngine.levelFor(db.xp().earned().first())
                val d = LocalDate.now()
                val week = db.stats().gainedByDay(d.minusDays(6).toString(), today).first().joinToString { "${it.date}: ${it.total} XP" }
                val streak = com.lifeplanner.domain.RpgEngine.streak(db.rpg().activeDays().first())
                val done = db.stats().doneByDay(d.minusDays(6).toString(), today).first().joinToString { "${it.date}: ${it.c} done, ${it.m} min" }
                "User data - level ${lv.level}; streak $streak days; today's schedule/tasks: $tasks; goals: $goals; last 7 days XP: $week; completed tasks: $done."
            } else "No user data shared."
            answer = AiClient.chat(s, "You are a concise life-planning coach inside the Life Planner app. Answer in the same language as the question. $ctx", q).fold({ it }, { "Error: ${it.message}" })
            busy = false } }) { Text(if (busy) "Thinking..." else "Send") }
        if (answer.isNotEmpty()) androidx.compose.material3.Text(answer)
    }
}

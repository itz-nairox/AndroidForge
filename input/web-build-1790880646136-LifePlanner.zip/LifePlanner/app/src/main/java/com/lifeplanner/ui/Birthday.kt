package com.lifeplanner.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.lifeplanner.domain.AgeCalc
import java.time.LocalDate

/** Full-screen birthday page: theme-coloured expanding rings + welcome text. No emoji. */
@Composable
fun BirthdayScreen(name: String, birth: LocalDate, onClose: () -> Unit) {
    val g = LocalGlass.current
    val accent = MaterialTheme.colorScheme.primary
    val t by rememberInfiniteTransition(label = "bd").animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearOutSlowInEasing)), label = "ring")
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    val sc by animateFloatAsState(if (shown) 1f else 0.7f, if (g.animations) spring(dampingRatio = 0.55f) else snap(), label = "sc")
    val today = LocalDate.now()
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        if (g.decor && g.animations) Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2, size.height * 0.34f)
            for (k in 0 until 3) { val p = (t + k / 3f) % 1f
                drawCircle(accent.copy(alpha = (1f - p) * 0.5f), radius = 60f + p * size.width * 0.55f, center = c, style = Stroke(3f)) }
        }
        Column(Modifier.fillMaxSize().safeDrawingPadding().padding(32.dp), verticalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterVertically), horizontalAlignment = Alignment.CenterHorizontally) {
            LIcon(LpIcon.Gift, Modifier.scale(sc), tint = accent, size = 72.dp)
            Text("Happy birthday", style = MaterialTheme.typography.headlineLarge, textAlign = TextAlign.Center)
            Text(name, style = MaterialTheme.typography.headlineMedium, color = accent, textAlign = TextAlign.Center)
            Text("${AgeCalc.age(birth, today)} years of ONE LIFE", textAlign = TextAlign.Center)
            Text("${AgeCalc.daysLived(birth, today)} days lived", style = MaterialTheme.typography.labelLarge)
            LpButton(onClose) { Text("Continue") }
        }
    }
}

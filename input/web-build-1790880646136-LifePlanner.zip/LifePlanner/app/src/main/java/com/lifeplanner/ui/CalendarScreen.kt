package com.lifeplanner.ui

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.lifeplanner.core.PersianCalendar
import com.lifeplanner.data.AppDatabase
import com.lifeplanner.data.TaskEntity
import com.lifeplanner.domain.CompleteTaskUseCase
import com.lifeplanner.domain.ScheduleTemplates
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun CalendarScreen(db: AppDatabase) {
    val fa = LocalLang.current == "fa"
    val g = LocalGlass.current
    val today = LocalDate.now()
    var anchor by remember { mutableStateOf(today) }
    var sel by remember { mutableStateOf(today) }
    val scope = rememberCoroutineScope()
    val haptic = rememberHaptic()
    val vm = rememberTaskVm(db)
    var editing by remember { mutableStateOf<TaskEntity?>(null) }

    // Month in the active calendar (Jalali for Persian, Gregorian for English). DB dates stay ISO Gregorian.
    fun monthFirst(d: LocalDate) = if (fa) PersianCalendar.fromGregorian(d).let { PersianCalendar.toGregorian(it.year, it.month, 1) } else d.withDayOfMonth(1)
    val first = monthFirst(anchor)
    val len = if (fa) PersianCalendar.fromGregorian(first).let { PersianCalendar.monthLength(it.year, it.month) } else first.lengthOfMonth()
    val last = first.plusDays(len - 1L)
    val counts by remember(first.toString(), last.toString()) { db.stats().taskCounts(first.toString(), last.toString()) }.collectAsState(emptyList())
    val doneDays by remember(first.toString(), last.toString()) { db.stats().doneByDay(first.toString(), last.toString()) }.collectAsState(emptyList())
    val xp by remember(first.toString(), last.toString()) { db.stats().gainedByDay(first.toString(), last.toString()) }.collectAsState(emptyList())
    val tasks by remember(sel.toString()) { vm.tasks(sel.toString()) }.collectAsState(emptyList())
    val comps by remember(sel.toString()) { vm.completions(sel.toString()) }.collectAsState(emptyList())
    val doneIds = comps.filter { it.completed }.map { it.taskId }.toSet()
    fun num(n: Int) = if (fa) n.toString().toPersianDigitsUi() else n.toString()
    val title = if (fa) PersianCalendar.fromGregorian(first).let { "${PersianCalendar.months[it.month - 1]} ${num(it.year)}" }
                else first.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.ENGLISH))
    val heads = if (fa) listOf("ش", "ی", "د", "س", "چ", "پ", "ج") else listOf("S", "M", "T", "W", "T", "F", "S")
    val offset = if (fa) (first.dayOfWeek.value + 1) % 7 else first.dayOfWeek.value % 7

    editing?.let { EditTaskDialog(it, { t -> vm.update(t); editing = null }, { editing = null }) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton({ anchor = first.minusDays(1) }) { LIcon(LpIcon.Back) }
                Text(title, Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.titleLarge)
                IconButton({ anchor = last.plusDays(1) }) { LIcon(LpIcon.Back, Modifier.rotate(180f)) }
            }
            Row(Modifier.fillMaxWidth()) { heads.forEach { Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium) } }
            AnimatedContent(first, transitionSpec = {
                if (!g.animations) EnterTransition.None togetherWith ExitTransition.None
                else if (targetState > initialState) (slideInHorizontally { it / 3 } + fadeIn()) togetherWith (slideOutHorizontally { -it / 3 } + fadeOut())
                else (slideInHorizontally { -it / 3 } + fadeIn()) togetherWith (slideOutHorizontally { it / 3 } + fadeOut()) }, label = "month") { f ->
                val cells = List(offset) { null } + (0 until len).map { f.plusDays(it.toLong()) }
                Column {
                    cells.chunked(7).forEach { week ->
                        Row(Modifier.fillMaxWidth()) {
                            for (i in 0 until 7) {
                                val d = week.getOrNull(i)
                                val planned = d != null && counts.any { it.date == d.toString() }
                                val allDone = d != null && planned && (doneDays.firstOrNull { it.date == d.toString() }?.c ?: 0) >= (counts.firstOrNull { it.date == d.toString() }?.c ?: 1)
                                Box(Modifier.weight(1f).aspectRatio(1f).padding(2.dp).clip(CircleShape)
                                    .background(when { d == null -> Color.Transparent; d == sel -> MaterialTheme.colorScheme.primary
                                        d == today -> MaterialTheme.colorScheme.primary.copy(alpha = 0.28f); else -> Color.Transparent })
                                    .clickable(enabled = d != null) { sel = d!! }, contentAlignment = Alignment.Center) {
                                    if (d != null) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(num(if (fa) PersianCalendar.fromGregorian(d).day else d.dayOfMonth), color = if (d == sel) MaterialTheme.colorScheme.onPrimary else Color.Unspecified)
                                            if (planned) Box(Modifier.size(5.dp).clip(CircleShape).background(if (allDone) Color(0xFF4CAF50) else MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        item {
            val c = counts.firstOrNull { it.date == sel.toString() }?.c ?: 0
            val dn = doneDays.firstOrNull { it.date == sel.toString() }
            val x = xp.firstOrNull { it.date == sel.toString() }?.total ?: 0
            Column(Modifier.fillMaxWidth().glassSurface().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(formatDate(sel, fa), style = MaterialTheme.typography.titleMedium)
                LpProgress(if (c == 0) 0f else (dn?.c ?: 0) / c.toFloat())
                Text("Tasks: ${num(dn?.c ?: 0)}/${num(c)}   XP: ${num(x)}   Activity: ${num((dn?.m ?: 0))} min")
            }
        }
        item { QuickAdd(db, sel.toString()) }
        item { Text("Apply day template", Modifier.padding(top = 4.dp), style = MaterialTheme.typography.titleSmall)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ScheduleTemplates.all.keys.forEach { n -> AssistChip(onClick = { vm.applyTemplate(n, sel.toString(), tasks) }, label = { Text(n) }) } } }
        items(tasks, key = { it.id }) { t -> TaskRow(t, t.id in doneIds,
            onToggle = { checked -> vm.toggle(t, sel.toString(), checked); if (checked) haptic() },
            onDelete = { vm.delete(t) }, onEdit = { editing = t }) }
    }
}

private fun String.toPersianDigitsUi() = map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")

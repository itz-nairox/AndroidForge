package com.lifeplanner.domain

enum class Difficulty(val defaultXp: Int) { EASY(10), MEDIUM(20), HARD(30) }

/** Configurable: cumulative XP to reach level n+1 = a*n^2 + b*n  (a=25,b=75 -> 100,250,450,700,1000) */
data class LevelConfig(val a: Int = 25, val b: Int = 75, val dailyXpCap: Int = 400) {
    fun xpToReach(nextLevel: Int): Int { val n = nextLevel - 1; return a * n * n + b * n }
}

data class LevelState(val level: Int, val xpIntoLevel: Int, val xpForNext: Int)

object XpEngine {
    fun levelFor(totalXp: Int, cfg: LevelConfig = LevelConfig()): LevelState {
        var level = 1
        while (totalXp >= cfg.xpToReach(level + 1)) level++
        val base = if (level == 1) 0 else cfg.xpToReach(level)
        return LevelState(level, totalXp - base, cfg.xpToReach(level + 1) - base)
    }

    /** Once per task/date + daily XP cap against farming with many trivial tasks. */
    fun grant(task: Difficulty, customXp: Int?, alreadyGrantedForDate: Boolean,
              earnedToday: Int, cfg: LevelConfig = LevelConfig()): Int {
        if (alreadyGrantedForDate) return 0
        val xp = customXp ?: task.defaultXp
        return xp.coerceAtMost((cfg.dailyXpCap - earnedToday).coerceAtLeast(0))
    }
}

package com.lifeplanner.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "task")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String, val description: String = "",
    val date: String,               // ISO yyyy-MM-dd
    val startTime: String? = null, val durationMin: Int = 30,
    val category: String, val difficulty: String, val xpReward: Int,
    val repeat: String = "NONE", val priority: Int = 1,
    val goalId: Long? = null, val subGoalId: Long? = null)

/** Unique (taskId,date): one completion row per day. */
@Entity(tableName = "task_completion", indices = [Index(value = ["taskId", "date"], unique = true)])
data class TaskCompletionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskId: Long, val date: String, val completed: Boolean, val xpGranted: Int = 0)

@Entity(tableName = "xp_transaction")
data class XpTransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String, val source: String, val category: String, val amount: Int)

@Entity(tableName = "goal")
data class GoalEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String, val deadline: String? = null, val notes: String = "")

/** parentId gives an unlimited-depth Goal Tree. */
@Entity(tableName = "sub_goal")
data class SubGoalEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0,
    val goalId: Long, val parentId: Long? = null, val title: String,
    val deadline: String? = null, val notes: String = "", val done: Boolean = false)

@Dao interface TaskDao {
    @Query("SELECT * FROM task WHERE date = :date ORDER BY startTime") fun byDate(date: String): Flow<List<TaskEntity>>
    @Insert suspend fun insert(t: TaskEntity): Long
    @Update suspend fun update(t: TaskEntity)
    @Query("DELETE FROM task WHERE id=:id") suspend fun delete(id: Long)
    @Query("DELETE FROM task_completion WHERE taskId=:id") suspend fun deleteCompletions(id: Long)
}

@Dao interface CompletionDao {
    @Query("SELECT * FROM task_completion WHERE taskId=:id AND date=:date") suspend fun get(id: Long, date: String): TaskCompletionEntity?
    @Upsert suspend fun upsert(c: TaskCompletionEntity)
    @Query("SELECT * FROM task_completion WHERE date=:date") fun byDate(date: String): Flow<List<TaskCompletionEntity>>
}

@Dao interface XpDao {
    @Insert suspend fun insert(x: XpTransactionEntity)
    @Query("SELECT COALESCE(SUM(amount),0) FROM xp_transaction WHERE amount>0") fun earned(): Flow<Int>
    @Query("SELECT COALESCE(SUM(amount),0) FROM xp_transaction") fun total(): Flow<Int>
    @Query("SELECT COALESCE(SUM(amount),0) FROM xp_transaction WHERE date=:d AND amount>0 AND category!='Quest'") suspend fun earnedOn(d: String): Int
    @Query("SELECT COUNT(*) FROM xp_transaction WHERE date=:d AND source=:src AND amount>0") suspend fun countSource(d: String, src: String): Int
    @Query("SELECT COALESCE(SUM(amount),0) FROM xp_transaction") suspend fun totalNow(): Int
}

@Database(entities = [TaskEntity::class, TaskCompletionEntity::class, XpTransactionEntity::class,
    GoalEntity::class, SubGoalEntity::class, OwnedItemEntity::class, QuestClaimEntity::class, ThemePresetEntity::class], version = 2, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun tasks(): TaskDao
    abstract fun completions(): CompletionDao
    abstract fun xp(): XpDao
    abstract fun backup(): BackupDao
    abstract fun rpg(): RpgDao
    abstract fun owned(): OwnedDao
    abstract fun stats(): StatsDao
    abstract fun goals(): GoalDao
    abstract fun presets(): PresetDao
}

val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
    override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS `theme_preset` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `json` TEXT NOT NULL)")
    }
}

/** User-made themes (ThemeCreator). Appearance only: no personal data. */
@Entity(tableName = "theme_preset")
data class ThemePresetEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val name: String, val json: String)

@Dao interface PresetDao {
    @Query("SELECT * FROM theme_preset ORDER BY id DESC") fun all(): Flow<List<ThemePresetEntity>>
    @Insert suspend fun insert(p: ThemePresetEntity): Long
    @Query("DELETE FROM theme_preset WHERE id=:id") suspend fun delete(id: Long)
    @Query("SELECT * FROM theme_preset") suspend fun snapshot(): List<ThemePresetEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putAll(l: List<ThemePresetEntity>)
}

@Dao interface GoalDao {
    @Query("SELECT * FROM goal") fun goals(): Flow<List<GoalEntity>>
    @Insert suspend fun insert(g: GoalEntity): Long
    @Query("SELECT * FROM sub_goal WHERE goalId=:g") fun subs(g: Long): Flow<List<SubGoalEntity>>
    @Insert suspend fun insertSub(s: SubGoalEntity): Long
    @Query("SELECT COALESCE(SUM(MAX(xpReward,1)),0) FROM task WHERE goalId=:g") fun taskCount(g: Long): Flow<Int>   // weighted by difficulty/XP
    @Query("SELECT DISTINCT c.date FROM task_completion c JOIN task t ON t.id=c.taskId WHERE t.goalId=:g AND c.completed=1 AND c.date>=:since") fun goalDays(g: Long, since: String): Flow<List<String>>
    @Query("SELECT COALESCE(SUM(MAX(t.xpReward,1)),0) FROM task_completion c JOIN task t ON t.id=c.taskId WHERE t.goalId=:g AND c.completed=1") fun taskDone(g: Long): Flow<Int>
    @Query("SELECT COALESCE(SUM(t.durationMin),0) FROM task_completion c JOIN task t ON t.id=c.taskId WHERE t.goalId=:g AND c.completed=1") fun goalMinutes(g: Long): Flow<Int>
    @Update suspend fun updateSub(s: SubGoalEntity)
    @Update suspend fun updateGoal(g: GoalEntity)
    @Query("DELETE FROM goal WHERE id=:id") suspend fun deleteGoal(id: Long)
    @Query("DELETE FROM sub_goal WHERE goalId=:id") suspend fun deleteSubsOf(id: Long)
    @Query("DELETE FROM sub_goal WHERE id=:id") suspend fun deleteSub(id: Long)
    @Query("UPDATE task SET goalId=NULL WHERE goalId=:id") suspend fun detachTasks(id: Long)
}

data class DayCount(val date: String, val c: Int)
data class DayDone(val date: String, val c: Int, val m: Int)
data class DayXp(val date: String, val total: Int)

@Dao interface StatsDao {
    @Query("SELECT tc.date AS date, COUNT(*) AS c, COALESCE(SUM(t.durationMin),0) AS m FROM task_completion tc JOIN task t ON t.id=tc.taskId WHERE tc.completed=1 AND tc.date BETWEEN :a AND :b GROUP BY tc.date") fun doneByDay(a: String, b: String): Flow<List<DayDone>>
    @Query("SELECT category, SUM(amount) AS total FROM xp_transaction WHERE amount>0 AND category!='Quest' AND date BETWEEN :a AND :b GROUP BY category") fun catXpBetween(a: String, b: String): Flow<List<CatXp>>
    @Query("SELECT date, SUM(amount) AS total FROM xp_transaction WHERE date BETWEEN :a AND :b AND amount>0 AND category!='Quest' GROUP BY date") fun earnedByDay(a: String, b: String): Flow<List<DayXp>>
    @Query("SELECT date, COUNT(*) AS c FROM task WHERE date BETWEEN :a AND :b GROUP BY date") fun taskCounts(a: String, b: String): Flow<List<DayCount>>
    @Query("SELECT COUNT(*) FROM task_completion c JOIN task t ON t.id=c.taskId WHERE c.completed=1 AND c.xpGranted>0 AND t.difficulty='HARD' AND t.goalId IS NOT NULL AND c.date BETWEEN :a AND :b") fun hardGoalTasks(a: String, b: String): Flow<Int>
    @Query("SELECT COUNT(*) FROM task_completion c JOIN task t ON t.id=c.taskId WHERE c.completed=1 AND c.xpGranted>0 AND (t.category='Study' OR t.category LIKE 'Study/%') AND c.date BETWEEN :a AND :b") fun studyDone(a: String, b: String): Flow<Int>
    @Query("SELECT date, SUM(amount) AS total FROM xp_transaction WHERE date BETWEEN :a AND :b AND amount>0 GROUP BY date") fun gainedByDay(a: String, b: String): Flow<List<DayXp>>
    @Query("SELECT date, SUM(amount) AS total FROM xp_transaction WHERE date BETWEEN :a AND :b GROUP BY date") fun xpByDay(a: String, b: String): Flow<List<DayXp>>
}

@Entity(tableName = "owned_item")
data class OwnedItemEntity(@PrimaryKey val itemId: String, val active: Boolean = false)

@Dao interface OwnedDao {
    @Query("SELECT * FROM owned_item") fun all(): Flow<List<OwnedItemEntity>>
    @Query("SELECT COUNT(*) FROM owned_item WHERE itemId=:id") suspend fun has(id: String): Int
    @Insert suspend fun insert(o: OwnedItemEntity)
    @Query("UPDATE owned_item SET active = NOT active WHERE itemId=:id") suspend fun toggle(id: String)
    @Query("UPDATE owned_item SET active=:on WHERE itemId=:id") suspend fun setActive(id: String, on: Boolean)
    @Query("UPDATE owned_item SET active=0 WHERE itemId LIKE :prefix || '%' AND itemId!=:id") suspend fun deactivateOthers(prefix: String, id: String)
}

data class CatXp(val category: String, val total: Int)

@Dao interface RpgDao {
    @Query("SELECT category, SUM(amount) AS total FROM xp_transaction WHERE amount>0 GROUP BY category") fun catXp(): Flow<List<CatXp>>
    @Query("SELECT DISTINCT date FROM xp_transaction WHERE amount>0") fun activeDays(): Flow<List<String>>
    @Query("SELECT COUNT(*) FROM xp_transaction WHERE amount>0") fun actions(): Flow<Int>
    @Query("SELECT questKey FROM quest_claim") fun claims(): Flow<List<String>>
    @Insert(onConflict = OnConflictStrategy.IGNORE) suspend fun claim(c: QuestClaimEntity): Long   // -1 = already claimed
}

@Dao interface BackupDao {
    @Query("SELECT * FROM task") suspend fun tasks(): List<TaskEntity>
    @Query("SELECT * FROM task_completion") suspend fun completions(): List<TaskCompletionEntity>
    @Query("SELECT * FROM xp_transaction") suspend fun xp(): List<XpTransactionEntity>
    @Query("SELECT * FROM goal") suspend fun goals(): List<GoalEntity>
    @Query("SELECT * FROM sub_goal") suspend fun subs(): List<SubGoalEntity>
    @Query("SELECT * FROM owned_item") suspend fun owned(): List<OwnedItemEntity>
    @Query("SELECT questKey FROM quest_claim") suspend fun claims(): List<String>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putClaims(l: List<QuestClaimEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putTasks(l: List<TaskEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putCompletions(l: List<TaskCompletionEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putXp(l: List<XpTransactionEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putGoals(l: List<GoalEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putSubs(l: List<SubGoalEntity>)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun putOwned(l: List<OwnedItemEntity>)
}

@Entity(tableName = "quest_claim")
data class QuestClaimEntity(@PrimaryKey val questKey: String)

package com.lifeplanner.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import com.lifeplanner.theme.ThemeConfig

val LocalIsDark = staticCompositionLocalOf { true }

fun ThemeConfig.resolveDark(systemDark: Boolean) = when (mode) { "LIGHT" -> false; "SYSTEM" -> systemDark; else -> true }
fun ThemeConfig.pageColor(dark: Boolean) = if (dark) Color(background) else Color(0xFFF6F3FF)

@Composable
fun LifePlannerTheme(cfg: ThemeConfig, content: @Composable () -> Unit) {
    val dark = cfg.resolveDark(isSystemInDarkTheme())
    val accent = Color(cfg.accent); val page = cfg.pageColor(dark)
    val card = if (cfg.card != 0L) Color(cfg.card) else if (dark) Color.White.copy(alpha = 0.08f).compositeOver(page) else Color.White
    val scheme = if (dark) darkColorScheme(primary = accent, background = page, surface = page, surfaceVariant = card, surfaceContainer = card)
                 else lightColorScheme(primary = accent, background = page, surface = page, surfaceVariant = card, surfaceContainer = card)
    val fam = when (cfg.font) { "SERIF" -> FontFamily.Serif; "MONO" -> FontFamily.Monospace; "SANS" -> FontFamily.SansSerif; else -> FontFamily.Default }
    val b = Typography(); val k = cfg.fontScale
    fun TextStyle.s() = copy(fontFamily = fam, fontSize = fontSize * k, lineHeight = lineHeight * k)
    val typo = Typography(b.displayLarge.s(), b.displayMedium.s(), b.displaySmall.s(), b.headlineLarge.s(), b.headlineMedium.s(), b.headlineSmall.s(),
        b.titleLarge.s(), b.titleMedium.s(), b.titleSmall.s(), b.bodyLarge.s(), b.bodyMedium.s(), b.bodySmall.s(), b.labelLarge.s(), b.labelMedium.s(), b.labelSmall.s())
    val view = androidx.compose.ui.platform.LocalView.current
    if (!view.isInEditMode) androidx.compose.runtime.SideEffect {
        (view.context as? android.app.Activity)?.window?.let { w ->
            androidx.core.view.WindowCompat.getInsetsController(w, view).apply { isAppearanceLightStatusBars = !dark; isAppearanceLightNavigationBars = !dark }
        }
    }
    CompositionLocalProvider(LocalIsDark provides dark) {
        MaterialTheme(colorScheme = scheme, typography = typo, shapes = Shapes(small = RoundedCornerShape(cfg.inputRadius.dp),
            medium = RoundedCornerShape(cfg.cardRadius.dp), large = RoundedCornerShape(cfg.dialogRadius.dp), extraLarge = RoundedCornerShape(cfg.dialogRadius.dp)), content = content)
    }
}

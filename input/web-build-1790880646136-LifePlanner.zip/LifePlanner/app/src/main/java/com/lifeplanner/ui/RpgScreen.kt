package com.lifeplanner.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lifeplanner.data.*
import com.lifeplanner.domain.*
import com.lifeplanner.theme.ThemeConfig
import com.lifeplanner.theme.ThemePresets
import androidx.room.withTransaction
import kotlinx.coroutines.launch
import java.time.LocalDate

@Composable
fun RpgScreen(db: AppDatabase, onBack: () -> Unit) {
    var shop by remember { mutableStateOf(false) }
    if (shop) { ShopScreen(db) { shop = false }; return }
    val g = LocalGlass.current
    val today = LocalDate.now()
    val stats = rememberRpgStats(db)
    val days = stats.activeDays; val earned = stats.earnedTotal
    val lv = XpEngine.levelFor(earned)
    val scope = rememberCoroutineScope()
    val haptic = rememberHaptic()
    val claimed by remember { db.rpg().claims() }.collectAsState(emptyList())
    val owned by remember { db.owned().all() }.collectAsState(emptyList())
    val ctl = LocalThemeCtl.current
    fun active(prefix: String) = owned.firstOrNull { it.active && it.itemId.startsWith(prefix) }?.itemId

    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(g.spacing.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { LIcon(LpIcon.Back) }
            Text("Life RPG", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
            LpButton({ shop = true }) { LIcon(LpIcon.Shop, size = 18.dp); Spacer(Modifier.width(6.dp)); Text("Shop") }
        }
        Row(Modifier.fillMaxWidth().glassSurface().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            LIcon(LpIcon.Person, tint = MaterialTheme.colorScheme.primary, size = 44.dp)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Character - Level ${lv.level}", style = MaterialTheme.typography.titleMedium)
                Text("${lv.xpIntoLevel}/${lv.xpForNext} XP   |   Streak ${RpgEngine.streak(days)} days", style = MaterialTheme.typography.labelMedium)
                LinearProgressIndicator(progress = { lv.xpIntoLevel / lv.xpForNext.toFloat() }, Modifier.fillMaxWidth())
            }
            active("player_")?.let { ItemArt(it, 48.dp) }; active("car_")?.let { ItemArt(it, 48.dp) }
        }
        SectionTitle("Quests", LpIcon.Trophy)
        RpgEngine.quests(stats, today).forEach { q ->
            Column(Modifier.fillMaxWidth().glassSurface().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("${q.kind}: ${q.title}  (${q.progress.coerceAtMost(q.target)}/${q.target})  +${q.rewardXp} XP")
                LinearProgressIndicator(progress = { (q.progress / q.target.toFloat()).coerceAtMost(1f) }, Modifier.fillMaxWidth())
                if (q.key in claimed) Text("Claimed", color = MaterialTheme.colorScheme.primary)
                else if (q.progress >= q.target) LpButton({ scope.launch {
                    val ok = db.withTransaction { if (db.rpg().claim(QuestClaimEntity(q.key)) != -1L) { db.xp().insert(XpTransactionEntity(date = today.toString(), source = q.title, category = "Quest", amount = q.rewardXp)); true } else false }
                    if (ok) haptic() } }) { Text("Claim: +${q.rewardXp} XP") }
            }
        }
        SectionTitle("Skills", LpIcon.Level)
        RpgEngine.skillTree(stats).forEach { n ->
            val ic = when (n.group) { "Learning" -> LpIcon.Study; "Coding" -> LpIcon.Code; "Language" -> LpIcon.English; else -> LpIcon.Exercise }
            Column(Modifier.fillMaxWidth().glassSurface().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) { LIcon(ic, tint = MaterialTheme.colorScheme.primary, size = 20.dp)
                    Text("${n.group}: Lv ${n.level.level}  (${n.level.xpIntoLevel}/${n.level.xpForNext})", style = MaterialTheme.typography.titleSmall) }
                n.subs.forEach { (name, xp) -> Text("   |- $name: $xp XP", style = MaterialTheme.typography.labelMedium) }
            }
        }
        SectionTitle("Achievements", LpIcon.Trophy)
        RpgEngine.achievements(stats).forEach { a ->
            Row(Modifier.fillMaxWidth().glassSurface().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                LIcon(if (a.unlocked) LpIcon.Trophy else LpIcon.Lock, tint = if (a.unlocked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                Text(a.title) }
        }
        SectionTitle("Inventory", LpIcon.Gift)
        if (owned.isEmpty()) Text("Nothing owned yet")
        owned.forEach { o ->
            val item = ShopCatalog.items.firstOrNull { it.id == o.itemId } ?: return@forEach
            Row(Modifier.fillMaxWidth().glassSurface().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (item.type != ItemType.THEME) ItemArt(item.id, 44.dp) else LIcon(LpIcon.Palette, tint = MaterialTheme.colorScheme.primary, size = 28.dp)
                Text("${item.name} (${item.type.name.lowercase()})", Modifier.weight(1f))
                LpOutlinedButton({ scope.launch { db.owned().equip(item, !o.active) }
                    if (item.type == ItemType.THEME) ctl.set(if (!o.active) ThemePresets.of(item.id) else ThemeConfig("Default")) }) { Text(if (o.active) "Active" else "Activate") }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

/** One place that gathers every number the RPG layer derives from (used by RPG, Profile and the achievement toast). */
@Composable
fun rememberRpgStats(db: AppDatabase): RpgStats {
    val today = LocalDate.now(); val t = today.toString(); val mon = today.with(java.time.DayOfWeek.MONDAY).toString()
    val cat by remember { db.rpg().catXp() }.collectAsState(emptyList())
    val days by remember { db.rpg().activeDays() }.collectAsState(emptyList())
    val actions by remember { db.rpg().actions() }.collectAsState(0)
    val earned by remember { db.xp().earned() }.collectAsState(0)
    val goals by remember { db.goals().goals() }.collectAsState(emptyList())
    val week by remember(mon, t) { db.stats().earnedByDay(mon, t) }.collectAsState(emptyList())
    val hard by remember(mon, t) { db.stats().hardGoalTasks(mon, t) }.collectAsState(0)
    val study by remember(mon, t) { db.stats().studyDone(mon, t) }.collectAsState(0)
    return RpgStats(cat.associate { it.category to it.total }, days, earned, actions,
        week.firstOrNull { it.date == t }?.total ?: 0, week.sumOf { it.total }, goals.size, hard, study)
}

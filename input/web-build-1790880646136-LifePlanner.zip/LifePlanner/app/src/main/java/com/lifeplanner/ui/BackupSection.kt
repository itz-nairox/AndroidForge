package com.lifeplanner.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.lifeplanner.App
import com.lifeplanner.data.BackupManager
import kotlinx.coroutines.launch

@Composable
fun BackupSection() {
    val ctx = LocalContext.current; val db = (ctx.applicationContext as App).db; val sec = (ctx.applicationContext as App).secure
    val scope = rememberCoroutineScope(); var msg by remember { mutableStateOf("") }
    val out = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { u -> u?.let { scope.launch {
        runCatching { val t = BackupManager.export(db, BackupManager.Profile(sec.name, sec.birth)); ctx.contentResolver.openOutputStream(u)!!.use { it.write(t.toByteArray()) } }
            .onSuccess { msg = "Backup saved" }.onFailure { msg = it.message ?: "Failed" } } } }
    val inp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> u?.let { scope.launch {
        runCatching { BackupManager.import(db, ctx.contentResolver.openInputStream(u)!!.bufferedReader().readText())?.let { pr -> if (pr.name.isNotBlank()) sec.name = pr.name; if (pr.birth.isNotBlank()) sec.birth = pr.birth } }
            .onSuccess { msg = "Backup restored" }.onFailure { msg = it.message ?: "Invalid backup" } } } }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Data", style = MaterialTheme.typography.titleLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ out.launch("lifeplanner-backup.json") }) { Text("Export JSON") }
            OutlinedButton({ inp.launch(arrayOf("*/*")) }) { Text("Import JSON") }
        }
        if (msg.isNotEmpty()) Text(msg)
    }
}

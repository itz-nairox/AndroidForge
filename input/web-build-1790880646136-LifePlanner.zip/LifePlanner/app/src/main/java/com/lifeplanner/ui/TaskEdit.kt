package com.lifeplanner.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lifeplanner.data.TaskEntity
import com.lifeplanner.domain.Difficulty

val priorityNames = listOf("Low", "Normal", "High")

/** Edit title, time, duration, difficulty and priority of an existing task. */
@Composable
fun EditTaskDialog(t: TaskEntity, onSave: (TaskEntity) -> Unit, onDismiss: () -> Unit) {
    var title by remember(t.id) { mutableStateOf(t.title) }
    var time by remember(t.id) { mutableStateOf(t.startTime ?: "") }
    var dur by remember(t.id) { mutableStateOf(t.durationMin.toString()) }
    var prio by remember(t.id) { mutableIntStateOf(t.priority.coerceIn(0, 2)) }
    var diff by remember(t.id) { mutableStateOf(t.difficulty) }
    val timeOk = time.isBlank() || Regex("^([01]\\d|2[0-3]):[0-5]\\d$").matches(time)
    AlertDialog(onDismissRequest = onDismiss, shape = RoundedCornerShape(LocalGlass.current.dialogRadius.dp),
        title = { Text("Edit task") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Name") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(time, { time = it.take(5) }, Modifier.weight(1f), label = { Text("Start (HH:mm)") }, singleLine = true, isError = !timeOk)
                    OutlinedTextField(dur, { dur = it.filter(Char::isDigit).take(3) }, Modifier.weight(1f), label = { Text("Minutes") }, singleLine = true)
                }
                Text("Priority", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    priorityNames.forEachIndexed { i, n -> FilterChip(prio == i, { prio = i }, label = { Text(n) }) } }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Difficulty.values().forEach { d -> FilterChip(diff == d.name, { diff = d.name }, label = { Text(d.name.lowercase().replaceFirstChar { it.uppercase() }) }) } }
            }
        },
        confirmButton = {
            TextButton(enabled = title.isNotBlank() && timeOk, onClick = {
                onSave(t.copy(title = title.trim(), startTime = time.ifBlank { null }, durationMin = dur.toIntOrNull()?.coerceIn(5, 720) ?: t.durationMin,
                    priority = prio, difficulty = diff, xpReward = if (diff != t.difficulty) Difficulty.valueOf(diff).defaultXp else t.xpReward))
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } })
}

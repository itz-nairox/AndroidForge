package com.lifeplanner.domain

import com.lifeplanner.data.TaskEntity

data class Block(val time: String, val min: Int, val title: String, val cat: String, val diff: Difficulty = Difficulty.EASY, val xp: Int = 0)

/** Non-productive blocks (school, sleep, meals) give 0 XP so templates can't be farmed. */
object ScheduleTemplates {
    val all: Map<String, List<Block>> = mapOf(
        "School Day" to listOf(
            Block("07:00", 30, "Wake Up", "Routine"), Block("07:30", 420, "School", "School"),
            Block("14:30", 60, "Food + Shower", "Routine"), Block("15:30", 45, "Rest / Movie / Short Sleep", "Rest"),
            Block("16:15", 120, "Study", "Study", Difficulty.MEDIUM, 20), Block("18:15", 45, "English", "English", Difficulty.EASY, 10),
            Block("19:00", 60, "Programming", "Programming", Difficulty.HARD, 30), Block("20:00", 60, "Dinner / Rest", "Rest"),
            Block("22:00", 150, "Football / Exercise", "Exercise", Difficulty.MEDIUM, 20), Block("01:00", 360, "Sleep (after midnight)", "Health")),
        "Free Day" to listOf(
            Block("09:00", 30, "Wake Up", "Routine"), Block("10:00", 120, "Study", "Study", Difficulty.MEDIUM, 20),
            Block("13:00", 60, "English", "English", Difficulty.EASY, 10), Block("15:00", 120, "Programming", "Programming", Difficulty.HARD, 30),
            Block("18:00", 90, "Exercise", "Exercise", Difficulty.MEDIUM, 20)),
        "Exam Day" to listOf(
            Block("06:30", 30, "Wake Up", "Routine"), Block("07:00", 60, "Final Review", "Study", Difficulty.MEDIUM, 20),
            Block("08:00", 180, "Exam", "School", Difficulty.HARD, 30), Block("14:00", 60, "Rest", "Rest")),
        "Holiday" to listOf(Block("10:00", 30, "Light Study", "Study", Difficulty.EASY, 10), Block("17:00", 60, "Exercise", "Exercise", Difficulty.MEDIUM, 20)),
        "Custom Day" to emptyList())

    fun toTasks(template: String, date: String) = (all[template] ?: emptyList()).map {
        TaskEntity(title = it.title, date = date, startTime = it.time, durationMin = it.min, category = it.cat,
            difficulty = it.diff.name, xpReward = it.xp) }
}

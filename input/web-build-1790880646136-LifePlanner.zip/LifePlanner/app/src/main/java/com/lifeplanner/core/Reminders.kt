package com.lifeplanner.core

import android.app.*
import android.content.*
import com.lifeplanner.MainActivity
import com.lifeplanner.R
import java.util.Calendar

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("daily", "Daily reminder", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        nm.notify(1, Notification.Builder(c, "daily").setSmallIcon(R.drawable.ic_launcher_monochrome).setContentTitle("Life Planner")
            .setContentText("Review today's plan and earn XP.").setContentIntent(open).setAutoCancel(true).build())
    }
}

/** Inexact daily alarm = battery friendly. Note: alarms are cleared by a device reboot until the app is opened again. */
object Reminders {
    private fun pi(c: Context) = PendingIntent.getBroadcast(c, 7, Intent(c, ReminderReceiver::class.java), PendingIntent.FLAG_IMMUTABLE)
    fun schedule(c: Context, hour: Int) {
        val t = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, hour); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1) }
        c.getSystemService(AlarmManager::class.java).setInexactRepeating(AlarmManager.RTC, t.timeInMillis, AlarmManager.INTERVAL_DAY, pi(c))
    }
    fun cancel(c: Context) = c.getSystemService(AlarmManager::class.java).cancel(pi(c))
}

/** Re-arms the daily reminder after a reboot. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val s = SecureStore(c); if (s.notifOn) Reminders.schedule(c, s.notifHour)
    }
}

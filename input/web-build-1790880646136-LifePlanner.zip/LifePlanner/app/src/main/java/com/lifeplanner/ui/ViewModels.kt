package com.lifeplanner.ui

import androidx.compose.runtime.Composable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.lifeplanner.data.*
import com.lifeplanner.domain.Difficulty
import kotlinx.coroutines.launch

/** Screens only render state and forward intents; rules live in the repositories. Survives rotation/config changes. */
class TaskViewModel(private val repo: TaskRepository) : ViewModel() {
    fun tasks(date: String) = repo.tasks(date)
    fun completions(date: String) = repo.completions(date)
    fun toggle(t: TaskEntity, date: String, checked: Boolean, onGain: (Int) -> Unit = {}) {
        viewModelScope.launch { if (checked) onGain(repo.complete(t, date)) else repo.undo(t, date) }
    }
    fun add(title: String, date: String, time: String?, dur: Int, cat: String, diff: Difficulty, xp: Int?, repeat: String, priority: Int, goalId: Long?) {
        viewModelScope.launch { repo.add(title, date, time, dur, cat, diff, xp, repeat, priority, goalId) }
    }
    fun update(t: TaskEntity) { viewModelScope.launch { repo.update(t) } }
    fun delete(t: TaskEntity) { viewModelScope.launch { repo.delete(t) } }
    fun applyTemplate(name: String, date: String, existing: List<TaskEntity>) { viewModelScope.launch { repo.applyTemplate(name, date, existing) } }
}

class GoalViewModel(private val repo: GoalRepository) : ViewModel() {
    fun addGoal(title: String, deadline: String?) { viewModelScope.launch { repo.addGoal(title, deadline) } }
    fun deleteGoal(id: Long) { viewModelScope.launch { repo.deleteGoal(id) } }
    fun addSub(goalId: Long, parentId: Long?, title: String) { viewModelScope.launch { repo.addSub(goalId, parentId, title) } }
    fun updateSub(s: SubGoalEntity) { viewModelScope.launch { repo.updateSub(s) } }
    fun deleteSubTree(all: List<SubGoalEntity>, id: Long) { viewModelScope.launch { repo.deleteSubTree(all, id) } }
    fun addSession(g: GoalEntity) { viewModelScope.launch { repo.addSession(g) } }
}

@Composable
fun rememberTaskVm(db: AppDatabase): TaskViewModel = viewModel(factory = viewModelFactory { initializer { TaskViewModel(TaskRepository(db)) } })
@Composable
fun rememberGoalVm(db: AppDatabase): GoalViewModel = viewModel(factory = viewModelFactory { initializer { GoalViewModel(GoalRepository(db)) } })

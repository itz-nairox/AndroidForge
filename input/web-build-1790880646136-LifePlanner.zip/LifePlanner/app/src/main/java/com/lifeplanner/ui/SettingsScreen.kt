package com.lifeplanner.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.lifeplanner.core.SecureStore
import com.lifeplanner.data.AppDatabase
import com.lifeplanner.domain.AgeCalc
import com.lifeplanner.theme.ThemeConfig
import java.time.LocalDate

@Composable
fun SettingsScreen(db: AppDatabase, s: SecureStore, theme: ThemeConfig, onTheme: (ThemeConfig) -> Unit, perf: com.lifeplanner.core.Perf, onPerf: (com.lifeplanner.core.Perf) -> Unit) {
    var name by remember { mutableStateOf(s.name) }
    var birth by remember { mutableStateOf(s.birth) }
    var pin by remember { mutableStateOf("") }
    var hasPin by remember { mutableStateOf(s.hasPin()) }
    var recovery by remember { mutableStateOf("") }
    val owned by remember { db.owned().all() }.collectAsState(emptyList())
    val studio = owned.any { it.itemId == "theme_glass_studio" }
    val b = com.lifeplanner.core.parseFlexibleDate(birth)
    val today = LocalDate.now()
    val g = LocalGlass.current
    @Composable fun Card(content: @Composable ColumnScope.() -> Unit) = Column(Modifier.fillMaxWidth().glassSurface().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp), content = content)
    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(g.spacing.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall)

        Card {
            SectionTitle("Profile", LpIcon.Person)
            OutlinedTextField(name, { name = it; s.name = it }, label = { Text("Name") }, singleLine = true)
            OutlinedTextField(birth, { birth = it; com.lifeplanner.core.parseFlexibleDate(it)?.let { d -> s.birth = d.toString() } }, label = { Text("Birth date (yyyy-MM-dd)") }, singleLine = true)
            val earned by remember { db.xp().earned() }.collectAsState(0)
            val actDays by remember { db.rpg().activeDays() }.collectAsState(emptyList())
            val goalsN by remember { db.goals().goals() }.collectAsState(emptyList())
            val lvl = com.lifeplanner.domain.XpEngine.levelFor(earned)
            Text("Level ${lvl.level}  |  $earned XP  |  Streak ${com.lifeplanner.domain.RpgEngine.streak(actDays)}  |  Goals ${goalsN.size}")
            if (b != null) {
                Text("${AgeCalc.age(b, today)} years old  -  ${AgeCalc.daysLived(b, today)} days lived")
                Text(if (AgeCalc.isBirthday(b, today)) "Happy birthday, $name" else "${AgeCalc.daysUntilNext(b, today)} days until your next birthday")
            }
        }

        Card {
            SectionTitle("Appearance", LpIcon.Palette)
            Text("Theme"); Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("LIGHT", "DARK", "SYSTEM").forEach { m -> FilterChip(theme.mode == m, { onTheme(theme.copy(mode = m)) }, label = { Text(m) }) } }
            Text("Accent"); Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                listOf(0xFF7C4DFF, 0xFF00B8D4, 0xFFFF6D00, 0xFF00C853, 0xFFE91E63, 0xFFFFC107).forEach { c ->
                    Box(Modifier.size(36.dp).clip(CircleShape).background(Color(c)).clickable { onTheme(theme.copy(accent = c)) }) } }
            Tog("Liquid Glass", theme.glass) { onTheme(theme.copy(glass = it)) }
            if (theme.glass) {
                Sld("Glass intensity", theme.glassIntensity) { onTheme(theme.copy(glassIntensity = it)) }
                Tog("Blur", theme.blur > 0) { onTheme(theme.copy(blur = if (it) 60 else 0)) }
                if (theme.blur > 0) Sld("Blur", theme.blur) { onTheme(theme.copy(blur = it.coerceAtLeast(1))) }
                Sld("Transparency", theme.transparency) { onTheme(theme.copy(transparency = it)) }
                Tog("Reflection", theme.reflection) { onTheme(theme.copy(reflection = it)) }
                Tog("Glow", theme.glow) { onTheme(theme.copy(glow = it)) }
                Tog("Shadows", theme.shadow) { onTheme(theme.copy(shadow = it)) }
                Tog("Motion", theme.motion) { onTheme(theme.copy(motion = it)) }
            }
            Tog("Animations", theme.animations) { onTheme(theme.copy(animations = it)) }
            Text("Icons"); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("MINIMAL", "BOLD").forEach { i -> FilterChip(theme.iconStyle == i, { onTheme(theme.copy(iconStyle = i)) }, label = { Text(i) }) } }
            Text("Font"); Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("DEFAULT", "SANS", "SERIF", "MONO").forEach { f -> FilterChip(theme.font == f, { onTheme(theme.copy(font = f)) }, label = { Text(f) }) } }
            LpOutlinedButton({ onTheme(ThemeConfig("Default")) }) { Text("Reset appearance") }
        }

        Card {
            SectionTitle("Performance", LpIcon.Xp)
            Tog("Battery Saver", perf.saver) { onPerf(perf.copy(saver = it)) }
            Tog("Smart Performance (auto-lighten on low battery)", perf.smart) { onPerf(perf.copy(smart = it)) }
            Text("Refresh Rate"); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { listOf("AUTO", "HIGH", "STANDARD").forEach { r -> FilterChip(perf.refresh == r, { onPerf(perf.copy(refresh = r)) }, label = { Text(r) }) } }
        }

        Card { PrefsSection(s) }
        Card { AiSettings(s) }

        Card {
            SectionTitle("Security", LpIcon.Lock)
            if (!hasPin) {
                OutlinedTextField(pin, { pin = it.filter(Char::isDigit).take(8) }, label = { Text("New PIN (4-8 digits)") }, singleLine = true)
                LpButton(onClick = { recovery = s.setPin(pin); hasPin = true; pin = "" }, enabled = pin.length >= 4) { Text("Enable App Lock") }
            } else {
                if (recovery.isNotEmpty()) Column(Modifier.fillMaxWidth().glassSurface().padding(12.dp)) {
                    Text("Recovery code (shown once, keep it safe)"); Text(recovery, style = MaterialTheme.typography.titleLarge)
                    TextButton({ recovery = "" }) { Text("Done") } }
                LpOutlinedButton({ s.clearPin(); hasPin = false; recovery = "" }) { Text("Disable App Lock") }
            }
        }

        Card { ThemeCreator(db, theme, studio, onTheme) }
        Card { BackupSection() }
        Card {
            SectionTitle("Advanced", LpIcon.Settings)
            Text("Life Planner 1.0  -  ONE LIFE", style = MaterialTheme.typography.labelMedium)
            Text("Dates are stored as ISO (yyyy-MM-dd) and never change when you switch language or calendar.", style = MaterialTheme.typography.labelSmall)
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Tog(label: String, v: Boolean, on: (Boolean) -> Unit) =
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f)); Switch(v, on) }
@Composable
private fun Sld(label: String, v: Int, set: (Int) -> Unit) { Text("$label: $v"); Slider(v.toFloat(), { set(it.toInt()) }, valueRange = 0f..100f) }

@Composable
fun LockScreen(s: SecureStore, onUnlock: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var bad by remember { mutableStateOf(false) }
    var rec by remember { mutableStateOf(false) }
    var code by remember { mutableStateOf("") }
    var wait by remember { mutableIntStateOf(s.lockRemainingSec()) }
    LaunchedEffect(wait) { if (wait > 0) { kotlinx.coroutines.delay(1000); wait = s.lockRemainingSec() } }
    Column(Modifier.fillMaxSize().safeDrawingPadding().padding(32.dp), verticalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterVertically), horizontalAlignment = Alignment.CenterHorizontally) {
        LpLogo(72.dp)
        if (!rec) {
            OutlinedTextField(pin, { pin = it.filter(Char::isDigit).take(8); bad = false }, label = { Text("PIN") }, singleLine = true, isError = bad)
            LpButton(onClick = { if (s.verify(pin)) onUnlock() else { bad = true; pin = ""; wait = s.lockRemainingSec() } }, enabled = wait == 0) { Text("Unlock") }
            if (wait > 0) Text("Try again in $wait s", color = MaterialTheme.colorScheme.error)
            TextButton({ rec = true }) { Text("Forgot PIN") }
        } else {
            OutlinedTextField(code, { code = it.uppercase().take(12); bad = false }, label = { Text("Recovery code") }, singleLine = true, isError = bad)
            LpButton(onClick = { if (s.recover(code)) onUnlock() else { bad = true; wait = s.lockRemainingSec() } }, enabled = wait == 0) { Text("Unlock") }
            TextButton({ rec = false }) { Text("Back") }
        }
    }
}

package com.lifeplanner.core

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** No SDK: plain HTTPS. Providers: OPENAI (any OpenAI-compatible base URL) and ANTHROPIC. Key is never logged or hardcoded. */
object AiClient {
    suspend fun chat(s: SecureStore, system: String, user: String, maxTokens: Int = 800): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val anth = s.aiProvider == "ANTHROPIC"
            val base = s.aiBase.trimEnd('/')
            fun msg(role: String, c: String) = JSONObject().put("role", role).put("content", c)
            val official = base.contains("api.openai.com")
            val body = JSONObject().put("model", s.aiModel).put(if (official) "max_completion_tokens" else "max_tokens", maxTokens).also {
                if (anth) it.put("system", system).put("messages", JSONArray().put(msg("user", user)))
                else it.put("messages", JSONArray().put(msg("system", system)).put(msg("user", user)))
            }
            val con = (URL(if (anth) "$base/v1/messages" else "$base/chat/completions").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"; connectTimeout = 15000; readTimeout = 60000; doOutput = true
                setRequestProperty("Content-Type", "application/json")
                if (anth) { setRequestProperty("x-api-key", s.aiKey); setRequestProperty("anthropic-version", "2023-06-01") }
                else setRequestProperty("Authorization", "Bearer ${s.aiKey}")
            }
            con.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = con.responseCode
            if (code !in 200..299) { val why = runCatching { con.errorStream?.bufferedReader()?.readText()?.take(160) }.getOrNull().orEmpty(); error("HTTP $code - check key, model and base URL. $why") }
            val j = JSONObject(con.inputStream.bufferedReader().readText())
            if (anth) j.getJSONArray("content").getJSONObject(0).getString("text")
            else j.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        }
    }
}

package com.lifeplanner.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.lifeplanner.data.AppDatabase
import com.lifeplanner.data.ThemePresetEntity
import com.lifeplanner.theme.ThemeConfig
import kotlinx.coroutines.launch

private val swatches = listOf(0xFF7C4DFF, 0xFF00B8D4, 0xFFFF6D00, 0xFF00C853, 0xFFE91E63, 0xFFFFC107, 0xFF5C6BC0, 0xFFF48FB1, 0xFF00E5FF, 0xFFEF5350)
private val darkBgs = listOf(0xFF0E0E14, 0xFF0A0F24, 0xFF04202B, 0xFF0B1A10, 0xFF24110D, 0xFF2A1520, 0xFF000000, 0xFF17130A)

@Composable
fun ColorField(label: String, value: Long, choices: List<Long>, allowAuto: Boolean, onChange: (Long) -> Unit) {
    var hex by remember(value) { mutableStateOf(if (value == 0L) "" else "%06X".format(value and 0xFFFFFF)) }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(label, style = MaterialTheme.typography.labelLarge)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            if (allowAuto) FilterChip(value == 0L, { onChange(0L) }, label = { Text("Auto") })
            choices.forEach { c -> Box(Modifier.size(34.dp).clip(CircleShape).background(Color(c)).clickable { onChange(c) }) }
            OutlinedTextField(hex, { h -> hex = h.uppercase().filter { it in "0123456789ABCDEF" }.take(6)
                if (hex.length == 6) onChange(0xFF000000L or hex.toLong(16)) }, Modifier.width(120.dp), label = { Text("HEX") }, singleLine = true)
        }
    }
}

@Composable
private fun Sl(label: String, v: Int, max: Int, set: (Int) -> Unit) { Text("$label: $v"); Slider(v.toFloat(), { set(it.toInt()) }, valueRange = 0f..max.toFloat()) }
@Composable
private fun Sw(label: String, v: Boolean, set: (Boolean) -> Unit) = Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(label, Modifier.weight(1f)); Switch(v, set) }
@Composable
private fun Chips(label: String, cur: String, opts: List<String>, set: (String) -> Unit) {
    Text(label, style = MaterialTheme.typography.labelLarge)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) { opts.forEach { o -> FilterChip(cur == o, { set(o) }, label = { Text(o) }) } }
}

/** Personal UI Creator. Editing is unlocked by buying "Liquid Glass Studio"; Export/Import (.lptheme) is always available. */
@Composable
fun ThemeCreator(db: AppDatabase, t: ThemeConfig, unlocked: Boolean, onTheme: (ThemeConfig) -> Unit) {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var err by remember { mutableStateOf("") }
    val presets by remember { db.presets().all() }.collectAsState(emptyList())
    val export = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        uri?.let { ctx.contentResolver.openOutputStream(it)?.use { o -> o.write(t.toJson().toByteArray()) } } }
    val import = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { runCatching { onTheme(ThemeConfig.fromJson(ctx.contentResolver.openInputStream(it)!!.bufferedReader().readText())); err = "" }
            .onFailure { e -> err = e.message ?: "Invalid theme file" } } }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        SectionTitle("Theme Creator", LpIcon.Palette)
        if (!unlocked) {
            Column(Modifier.fillMaxWidth().glassSurface().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) { LIcon(LpIcon.Lock); Text("Advanced Customization", style = MaterialTheme.typography.titleSmall) }
                Text("Unlock Liquid Glass Studio (500 XP) in the Shop to build your own look: colors, radii, progress style, navigation, density and saved themes.")
            }
        } else {
            OutlinedTextField(t.name, { onTheme(t.copy(name = it)) }, label = { Text("Theme name") }, singleLine = true)
            ColorField("Background", t.background, darkBgs, false) { onTheme(t.copy(background = it)) }
            ColorField("Card", t.card, listOf(0xFF1B1B26, 0xFF232336, 0xFF2A1F3D, 0xFFFFFFFF), true) { onTheme(t.copy(card = it)) }
            ColorField("Button", t.button, swatches, true) { onTheme(t.copy(button = it)) }
            Sw("Decorative elements", t.decor) { onTheme(t.copy(decor = it)) }
            Sl("Card radius", t.cardRadius, 48) { onTheme(t.copy(cardRadius = it)) }
            Sl("Button radius", t.buttonRadius, 48) { onTheme(t.copy(buttonRadius = it)) }
            Sl("Input radius", t.inputRadius, 48) { onTheme(t.copy(inputRadius = it)) }
            Sl("Progress radius", t.progressRadius, 48) { onTheme(t.copy(progressRadius = it)) }
            Sl("Navigation radius", t.navRadius, 48) { onTheme(t.copy(navRadius = it)) }
            Sl("Dialog radius", t.dialogRadius, 48) { onTheme(t.copy(dialogRadius = it)) }
            Chips("Progress style", t.progressStyle, listOf("RING", "BAR", "SEGMENTS")) { onTheme(t.copy(progressStyle = it)) }
            Chips("Navigation style", t.navStyle, listOf("BAR", "FLOATING")) { onTheme(t.copy(navStyle = it)) }
            Chips("Density", t.density, listOf("COMPACT", "COMFORT", "SPACIOUS")) { onTheme(t.copy(density = it)) }
            Sl("Font size %", (t.fontScale * 100).toInt().coerceIn(80, 140), 140) { onTheme(t.copy(fontScale = it.coerceIn(80, 140) / 100f)) }
            Column(Modifier.fillMaxWidth().glassSurface().padding(14.dp)) { Text("Preview"); LpProgress(0.6f); LpButton({}) { Text("Button") } }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                LpButton({ scope.launch { db.presets().insert(ThemePresetEntity(name = t.name.ifBlank { "MyTheme" }, json = t.toJson())) } }) { Text("Save") } }
            presets.forEach { p -> Row(Modifier.fillMaxWidth().glassSurface().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(p.name, Modifier.weight(1f))
                TextButton({ runCatching { onTheme(ThemeConfig.fromJson(p.json)) } }) { Text("Activate") }
                IconButton({ scope.launch { db.presets().delete(p.id) } }) { LIcon(LpIcon.Delete, size = 20.dp) } } }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LpButton({ export.launch("${t.name.ifBlank { "MyTheme" }}.lptheme") }) { Text("Export") }
            LpOutlinedButton({ import.launch(arrayOf("*/*")) }) { Text("Import") }
        }
        if (err.isNotEmpty()) Text(err, color = MaterialTheme.colorScheme.error)
    }
}

package com.lifeplanner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import com.lifeplanner.core.effective
import com.lifeplanner.domain.AgeCalc
import com.lifeplanner.theme.ThemeConfig
import com.lifeplanner.ui.*
import java.time.LocalDate

class MainActivity : ComponentActivity() {
    private var stoppedAt = 0L
    private var relock by mutableIntStateOf(0)
    private var resumed by mutableStateOf(true)      // sensors sleep while the app is in the background
    override fun onResume() { super.onResume(); resumed = true }
    override fun onPause() { super.onPause(); resumed = false }
    override fun onStop() { super.onStop(); stoppedAt = android.os.SystemClock.elapsedRealtime() }
    override fun onStart() {
        super.onStart(); val s = (application as App).secure
        if (stoppedAt > 0 && s.hasPin() && android.os.SystemClock.elapsedRealtime() - stoppedAt >= s.autoLockMin * 60_000L) relock++
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()      // full screen: app draws behind the status and navigation bars
        val app = application as App
        val db = app.db; val secure = app.secure
        setContent {
            var theme by remember { mutableStateOf(secure.themeJson?.let { runCatching { ThemeConfig.fromJson(it) }.getOrNull() } ?: ThemeConfig("Default")) }
            LaunchedEffect(theme) { kotlinx.coroutines.delay(400); secure.themeJson = theme.toJson() }   // debounced: sliders do not hit encrypted storage on every move
            var unlocked by remember { mutableStateOf(!secure.hasPin()) }
            LaunchedEffect(relock) { if (relock > 0) unlocked = false }
            var langPref by remember { mutableStateOf(secure.lang) }
            val lang = if (langPref == "SYSTEM") java.util.Locale.getDefault().language else langPref
            var perf by remember { mutableStateOf(secure.perf) }
            var onboarded by remember { mutableStateOf(secure.name.isNotBlank() && secure.birth.isNotBlank()) }
            var bdOpen by remember { mutableStateOf(true) }
            val low = com.lifeplanner.core.rememberBatteryLow()
            val light = perf.saver || (perf.smart && low)
            val eff = theme.effective(light)
            val rate = if (light) "STANDARD" else perf.refresh     // Battery Saver / low battery also lowers the refresh rate
            LaunchedEffect(rate) { com.lifeplanner.core.applyRefresh(this@MainActivity, rate) }
            val par = rememberParallax(eff.glass && eff.motion && resumed)     // auto-off when the device has no accelerometer
            CompositionLocalProvider(LocalGlass provides eff, LocalParallax provides par,
                LocalThemeCtl provides ThemeCtl(theme, { theme = it }, langPref) { langPref = it; secure.lang = it },
                LocalLang provides lang,
                androidx.compose.ui.platform.LocalLayoutDirection provides if (lang == "fa") androidx.compose.ui.unit.LayoutDirection.Rtl else androidx.compose.ui.unit.LayoutDirection.Ltr) {
                LifePlannerTheme(eff) {
                    PageBackground {
                        val today = LocalDate.now()
                        val bd = runCatching { LocalDate.parse(secure.birth) }.getOrNull()
                        when {
                            !unlocked -> LockScreen(secure) { unlocked = true }
                            !onboarded -> Onboarding(secure) { onboarded = true }
                            bd != null && bdOpen && AgeCalc.isBirthday(bd, today) && secure.bdShown != today.toString() ->
                                BirthdayScreen(secure.name, bd) { secure.bdShown = today.toString(); bdOpen = false }
                            else -> Root(db, secure, theme, perf, { perf = it; secure.perf = it }) { theme = it }
                        }
                    }
                }
            }
        }
    }
}

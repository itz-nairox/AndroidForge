package com.lifeplanner.ui

import androidx.compose.material3.LocalTextStyle
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import com.lifeplanner.core.toPersianDigits
import java.util.Locale

val LocalLang = staticCompositionLocalOf { Locale.getDefault().language }

private val fa = mapOf(
    "Home" to "خانه", "Calendar" to "تقویم", "Goals" to "اهداف", "Statistics" to "آمار", "Settings" to "تنظیمات",
    "Quick add" to "افزودن سریع", "Add" to "افزودن", "My Goals" to "اهداف من", "New goal" to "هدف جدید", "Sub-goal" to "زیرهدف",
    "Save" to "ذخیره", "Back" to "بازگشت", "Shop" to "فروشگاه", "Preview" to "پیش‌نمایش", "Revert preview" to "بازگشت از پیش‌نمایش",
    "Active" to "فعال", "Activate" to "فعال‌سازی", "Not enough XP" to "امتیاز کافی نیست", "Life RPG" to "RPG زندگی",
    "Life RPG - Shop" to "RPG زندگی - فروشگاه", "AI Assistant" to "دستیار هوشمند", "Quests" to "ماموریت‌ها", "Skills" to "مهارت‌ها",
    "Achievements" to "دستاوردها", "Profile" to "پروفایل", "Name" to "نام", "Birth date (yyyy-MM-dd)" to "تاریخ تولد (yyyy-MM-dd)",
    "Appearance" to "ظاهر", "Dark theme" to "تم تیره", "Liquid Glass" to "شیشه مایع", "Motion" to "حرکت", "Performance" to "عملکرد",
    "Battery Saver" to "صرفه‌جویی باتری", "Smart Performance (auto-lighten on low battery)" to "عملکرد هوشمند (سبک‌شدن خودکار در باتری کم)",
    "Security" to "امنیت", "Enable App Lock" to "فعال‌سازی قفل برنامه", "Disable App Lock" to "غیرفعال‌سازی قفل برنامه",
    "New PIN (4-8 digits)" to "رمز جدید (۴ تا ۸ رقم)", "PIN" to "رمز", "Unlock" to "باز کردن", "Theme Creator" to "سازنده تم",
    "Theme name" to "نام تم", "Export" to "خروجی", "Import" to "ورودی", "Data" to "داده‌ها", "Export JSON" to "خروجی JSON",
    "Import JSON" to "ورودی JSON", "Haptics" to "لرزش", "Animations" to "انیمیشن‌ها", "Daily reminder" to "یادآور روزانه",
    "Feedback & Notifications" to "بازخورد و اعلان‌ها", "AI Configuration" to "پیکربندی هوش مصنوعی", "AI enabled" to "هوش مصنوعی فعال",
    "Let AI see my app data" to "دسترسی هوش مصنوعی به داده‌های برنامه", "Base URL" to "آدرس پایه", "Model" to "مدل", "API Key" to "کلید API",
    "Test Connection" to "آزمایش اتصال", "Start" to "شروع", "Your name" to "نام شما", "Plan - Focus - Level Up" to "برنامه‌ریزی - تمرکز - ارتقا",
    "Ask anything" to "هر چیزی بپرس", "Send" to "ارسال", "Thinking..." to "در حال فکر...", "Apply day template" to "اعمال قالب روز",
    "School Day" to "روز مدرسه", "Free Day" to "روز آزاد", "Exam Day" to "روز امتحان", "Holiday" to "تعطیلات", "Custom Day" to "روز سفارشی",
    "Auto Lock" to "قفل خودکار", "Immediately" to "فوری", "1 Minute" to "۱ دقیقه", "5 Minutes" to "۵ دقیقه", "15 Minutes" to "۱۵ دقیقه",
    "Language" to "زبان", "System" to "سیستم", "THEME" to "تم‌ها", "PLAYER" to "بازیکنان", "CAR" to "ماشین‌ها", "Claim" to "دریافت",
    "Claimed" to "دریافت شد", "Days left" to "روز باقی‌مانده", "On track" to "در مسیر", "Behind schedule" to "عقب از برنامه", "Inventory" to "انبار",
    "Nothing owned yet" to "هنوز چیزی نخریده‌اید", "No repeat" to "بدون تکرار", "Daily" to "روزانه", "Weekly" to "هفتگی", "No goal" to "بدون هدف",
    "Deadline (yyyy-MM-dd, optional)" to "مهلت (yyyy-MM-dd، اختیاری)", "Study" to "مطالعه", "Exercise" to "ورزش", "Sleep" to "خواب", "Add today's task" to "افزودن کار امروز", "Consistency" to "ثبات", "SubGoals" to "زیرهدف‌ها",
    "Good morning" to "صبح بخیر", "Good afternoon" to "ظهر بخیر", "Good evening" to "عصر بخیر", "Today's Progress" to "پیشرفت امروز", "Today's Schedule" to "برنامه امروز",
    "Goal Progress" to "پیشرفت اهداف", "Level progress" to "پیشرفت سطح", "Happy birthday" to "تولدت مبارک", "Continue" to "ادامه", "Time spent" to "زمان صرف‌شده",
    "Overall Progress" to "پیشرفت کلی", "Areas" to "حوزه‌ها", "Weekly" to "هفتگی", "Monthly" to "ماهانه", "Yearly" to "سالانه", "Daily" to "روزانه", "Preview" to "پیش‌نمایش",
    "Sounds" to "صداها", "Blur" to "محو", "Reflection" to "بازتاب", "Glow" to "درخشش", "Shadows" to "سایه‌ها", "Glass intensity" to "شدت شیشه", "Transparency" to "شفافیت",
    "Icons" to "آیکون‌ها", "Font" to "فونت", "Theme" to "تم", "Accent" to "رنگ اصلی", "Reset appearance" to "بازنشانی ظاهر", "Advanced" to "پیشرفته", "Refresh Rate" to "نرخ نوسازی",
    "Forgot PIN" to "فراموشی رمز", "Recovery code" to "کد بازیابی", "Advanced Customization" to "شخصی‌سازی پیشرفته", "Card radius" to "پخی کارت", "Button radius" to "پخی دکمه",
    "Input radius" to "پخی ورودی", "Progress radius" to "پخی نوار پیشرفت", "Navigation radius" to "پخی ناوبری", "Dialog radius" to "پخی دیالوگ", "Progress style" to "سبک پیشرفت",
    "Navigation style" to "سبک ناوبری", "Density" to "تراکم", "Decorative elements" to "عناصر تزئینی", "Background" to "پس‌زمینه", "Card" to "کارت", "Button" to "دکمه",
    "Quick add" to "افزودن سریع", "More" to "بیشتر", "Less" to "کمتر", "Minutes" to "دقیقه", "Start (HH:mm)" to "شروع (HH:mm)", "Notes" to "یادداشت‌ها", "Try again" to "بعداً تلاش کنید",
    "Statistics" to "آمار", "Tasks" to "کارها", "XP" to "امتیاز", "Level" to "سطح", "Unlock for" to "باز کردن با", "Activity" to "فعالیت",
    "LIGHT" to "روشن", "DARK" to "تیره", "AUTO" to "خودکار", "HIGH" to "بالا", "STANDARD" to "استاندارد", "MINIMAL" to "مینیمال", "BOLD" to "پررنگ",
    "DEFAULT" to "پیش‌فرض", "SANS" to "بدون سریف", "SERIF" to "سریف", "MONO" to "تک‌فاصله", "RING" to "حلقه", "BAR" to "نوار", "SEGMENTS" to "قطعه‌ای",
    "FLOATING" to "شناور", "COMPACT" to "فشرده", "COMFORT" to "معمولی", "SPACIOUS" to "باز", "Done" to "تمام", "Auto" to "خودکار", "Delete" to "حذف",
    "Rare" to "نادر", "Common" to "معمولی", "Epic" to "حماسی", "Legendary" to "افسانه‌ای", "Character" to "شخصیت", "Backup saved" to "پشتیبان ذخیره شد",
    "Backup restored" to "پشتیبان بازیابی شد", "Testing..." to "در حال آزمایش...", "Connected" to "متصل شد", "Unlocked" to "باز شد",
    "Data" to "داده‌ها", "Text size" to "اندازه متن", "Font size %" to "اندازه فونت %", "Save" to "ذخیره", "Cancel" to "لغو", "Tasks: " to "کارها: ",
    "Edit task" to "ویرایش کار", "Priority" to "اولویت", "Low" to "کم", "Normal" to "معمولی", "High" to "زیاد", "Age" to "سن", "Days lived" to "روزهای زندگی",
    "Days until birthday" to "روز تا تولد بعدی", "Birth date" to "تاریخ تولد", "This week" to "این هفته", "Achievement unlocked" to "دستاورد باز شد", "Complete 5 study sessions" to "۵ جلسه مطالعه را کامل کن",
    "Finish 3 hard goal tasks" to "۳ کار سخت مرتبط با هدف را تمام کن", "Earn 30 XP today" to "امروز ۳۰ امتیاز بگیر", "Earn 100 XP today" to "امروز ۱۰۰ امتیاز بگیر", "Earn 200 XP this week" to "این هفته ۲۰۰ امتیاز بگیر",
    "Strong area" to "نقطه قوت", "Weak area" to "نقطه ضعف", "Tasks" to "کارها", "Level" to "سطح", "Streak" to "روز پیاپی")

/** Translate a label, or a "Label: value" string. Unknown text is returned unchanged. */
fun tr(s: String, lang: String): String {
    if (lang != "fa") return s
    fa[s]?.let { return it }
    val i = s.indexOf(": ")
    if (i > 0) fa[s.substring(0, i)]?.let { return it + ": " + s.substring(i + 2) }
    return s
}

/** Same-package Text shadows material3.Text for every screen in this package: automatic translation + Persian digits. */
@Composable
fun Text(text: String, modifier: Modifier = Modifier, color: Color = Color.Unspecified, textAlign: TextAlign? = null, style: TextStyle = LocalTextStyle.current) {
    val lang = LocalLang.current
    val t = tr(text, lang)
    androidx.compose.material3.Text(if (lang == "fa") t.toPersianDigits() else t, modifier, color = color, textAlign = textAlign, style = style)
}

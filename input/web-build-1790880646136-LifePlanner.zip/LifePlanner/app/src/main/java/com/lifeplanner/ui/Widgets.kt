package com.lifeplanner.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Button that honours the theme's button radius/color and takes part in the sensor parallax. */
@Composable
fun LpButton(onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, content: @Composable RowScope.() -> Unit) {
    val g = LocalGlass.current
    Button(onClick, modifier.parallax(), enabled, shape = RoundedCornerShape(g.buttonRadius.dp),
        colors = ButtonDefaults.buttonColors(containerColor = if (g.button != 0L) Color(g.button) else MaterialTheme.colorScheme.primary), content = content)
}

@Composable
fun LpOutlinedButton(onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, content: @Composable RowScope.() -> Unit) =
    OutlinedButton(onClick, modifier.parallax(), enabled, shape = RoundedCornerShape(LocalGlass.current.buttonRadius.dp), content = content)

/** Progress in the theme's style: RING, BAR or SEGMENTS. */
@Composable
fun LpProgress(p: Float, modifier: Modifier = Modifier, ring: Dp = 56.dp, label: Boolean = true) {
    val g = LocalGlass.current
    val a by animateFloatAsState(p.coerceIn(0f, 1f), if (g.animations) tween(600, easing = FastOutSlowInEasing) else snap(), label = "lp")
    when (g.progressStyle) {
        "RING" -> Box(modifier.size(ring), Alignment.Center) {
            CircularProgressIndicator(progress = { a }, Modifier.fillMaxSize(), strokeWidth = 5.dp, trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f))
            if (label) Text("${(a * 100).toInt()}%", style = MaterialTheme.typography.labelMedium)
        }
        "SEGMENTS" -> Row(modifier.fillMaxWidth().height(8.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            for (i in 0 until 10) Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(g.progressRadius.coerceAtMost(4).dp))
                .background(if (a * 10 > i) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)))
        }
        else -> LinearProgressIndicator(progress = { a }, modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(g.progressRadius.dp)),
            trackColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f))
    }
}

/** Ring for stat tiles that must stay a ring regardless of theme. */
@Composable
fun LpTile(icon: LpIcon, value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier.glassSurface().padding(LocalGlass.current.spacing.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        LIcon(icon, tint = MaterialTheme.colorScheme.primary)
        Text(value, style = MaterialTheme.typography.titleMedium, textAlign = TextAlign.Center)
        Text(label, style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center)
    }
}

@Composable
fun SectionTitle(t: String, icon: LpIcon? = null) = Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
    if (icon != null) LIcon(icon, tint = MaterialTheme.colorScheme.primary, size = 20.dp)
    Text(t, style = MaterialTheme.typography.titleMedium)
}

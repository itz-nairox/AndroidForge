package com.lifeplanner.core

import java.time.LocalDate

/** DB stores ISO LocalDate; Jalali is presentation only. */
data class JalaliDate(val year: Int, val month: Int, val day: Int)

object PersianCalendar {
    private val gdm = intArrayOf(0,31,59,90,120,151,181,212,243,273,304,334)
    val months = listOf("فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند")

    fun fromGregorian(d: LocalDate): JalaliDate {
        val gy = d.year; val gm = d.monthValue; val gd = d.dayOfMonth
        val gy2 = if (gm > 2) gy + 1 else gy
        var days = 355666 + 365 * gy + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400 + gd + gdm[gm - 1]
        var jy = -1595 + 33 * (days / 12053); days %= 12053
        jy += 4 * (days / 1461); days %= 1461
        if (days > 365) { jy += (days - 1) / 365; days = (days - 1) % 365 }
        val jm: Int; val jd: Int
        if (days < 186) { jm = 1 + days / 31; jd = 1 + days % 31 }
        else { jm = 7 + (days - 186) / 30; jd = 1 + (days - 186) % 30 }
        return JalaliDate(jy, jm, jd)
    }

    /** Solar Hijri -> Gregorian (inverse of fromGregorian). */
    fun toGregorian(jy0: Int, jm: Int, jd: Int): LocalDate {
        val jy = jy0 + 1595
        var days = -355668 + 365 * jy + (jy / 33) * 8 + ((jy % 33) + 3) / 4 + jd + (if (jm < 7) (jm - 1) * 31 else (jm - 7) * 30 + 186)
        var gy = 400 * (days / 146097); days %= 146097
        if (days > 36524) { days--; gy += 100 * (days / 36524); days %= 36524; if (days >= 365) days++ }
        gy += 4 * (days / 1461); days %= 1461
        if (days > 365) { gy += (days - 1) / 365; days = (days - 1) % 365 }
        var gd = days + 1
        val leap = (gy % 4 == 0 && gy % 100 != 0) || gy % 400 == 0
        val sal = intArrayOf(0, 31, if (leap) 29 else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        var gm = 0
        while (gm < 13 && gd > sal[gm]) { gd -= sal[gm]; gm++ }
        return LocalDate.of(gy, gm, gd)
    }

    fun monthLength(jy: Int, jm: Int): Int {
        val first = toGregorian(jy, jm, 1)
        val next = if (jm == 12) toGregorian(jy + 1, 1, 1) else toGregorian(jy, jm + 1, 1)
        return java.time.temporal.ChronoUnit.DAYS.between(first, next).toInt()
    }

    fun format(d: LocalDate): String {
        val j = fromGregorian(d)
        return "${j.day} ${months[j.month - 1]} ${j.year}".toPersianDigits()
    }
}

fun String.toPersianDigits() = map { if (it in '0'..'9') '۰' + (it - '0') else it }.joinToString("")

/** Accepts 2009-10-15, 2009/10/15 or Jalali 1388/07/23, with Persian/Arabic digits. Returns null when invalid. */
fun parseFlexibleDate(raw: String): LocalDate? {
    val s = raw.trim().map { when (it) { in '\u06F0'..'\u06F9' -> '0' + (it - '\u06F0'); in '\u0660'..'\u0669' -> '0' + (it - '\u0660'); '/' -> '-'; else -> it } }.joinToString("")
    val p = s.split("-"); if (p.size != 3) return null
    val y = p[0].toIntOrNull() ?: return null; val m = p[1].toIntOrNull() ?: return null; val d = p[2].toIntOrNull() ?: return null
    return runCatching {
        if (y < 1700) { require(m in 1..12 && d in 1..31); PersianCalendar.toGregorian(y, m, d).takeIf { PersianCalendar.fromGregorian(it) == JalaliDate(y, m, d) } }
        else LocalDate.of(y, m, d)
    }.getOrNull()
}

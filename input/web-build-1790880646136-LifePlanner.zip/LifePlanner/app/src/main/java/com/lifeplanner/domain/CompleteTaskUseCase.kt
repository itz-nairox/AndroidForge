package com.lifeplanner.domain

import com.lifeplanner.data.*

class CompleteTaskUseCase(private val c: CompletionDao, private val xp: XpDao) {
    /** Returns XP gained now. Pays once per task+date, never twice for the same title on one date, and obeys the daily cap. */
    suspend operator fun invoke(t: TaskEntity, date: String, today: String = java.time.LocalDate.now().toString()): Int {
        val prev = c.get(t.id, date)
        val already = (prev?.xpGranted ?: 0) > 0 || xp.countSource(date, t.title) > 0   // uncomplete -> complete never pays twice
        val gained = if (date != today) 0   // XP only for the real current day: no farming past/future days
            else XpEngine.grant(Difficulty.valueOf(t.difficulty), t.xpReward, already, xp.earnedOn(date))
        c.upsert(TaskCompletionEntity(prev?.id ?: 0, t.id, date, true, (prev?.xpGranted ?: 0) + gained))
        if (gained > 0) xp.insert(XpTransactionEntity(date = date, source = t.title, category = t.category, amount = gained))
        return gained
    }

    /** Unchecking keeps xpGranted, so checking again pays nothing. */
    suspend fun undo(t: TaskEntity, date: String) {
        c.get(t.id, date)?.let { c.upsert(it.copy(completed = false)) }
    }
}

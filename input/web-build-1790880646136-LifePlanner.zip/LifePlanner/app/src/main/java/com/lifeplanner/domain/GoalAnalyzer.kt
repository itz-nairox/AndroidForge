package com.lifeplanner.domain

data class AreaStat(val name: String, val tasksTotal: Int, val tasksDone: Int, val subGoalsTotal: Int, val subGoalsDone: Int)
data class GoalAnalysis(val progress: Int, val consistency: Int, val subGoals: Int, val strongArea: String?, val weakArea: String?, val onTrack: Boolean?, val weekly: Int = 0)

/** Offline analyzer: works only on real user data, no AI/network. */
object GoalAnalyzer {
    fun analyze(areas: List<AreaStat>, activeDays: Int, periodDays: Int, daysLeft: Int? = null, goalTasksTotal: Int = 0, goalTasksDone: Int = 0, weeklyActiveDays: Int = 0): GoalAnalysis {
        fun pct(d: Int, t: Int) = if (t == 0) 0.0 else d * 100.0 / t
        val tTot = areas.sumOf { it.tasksTotal } + goalTasksTotal; val sTot = areas.sumOf { it.subGoalsTotal }
        val taskPct = pct(areas.sumOf { it.tasksDone } + goalTasksDone, tTot)
        val subPct = pct(areas.sumOf { it.subGoalsDone }, sTot)
        val consistency = pct(activeDays, periodDays.coerceAtLeast(1)).coerceAtMost(100.0)
        val progress = when { tTot > 0 && sTot > 0 -> taskPct * 0.6 + subPct * 0.4; tTot > 0 -> taskPct; sTot > 0 -> subPct; else -> 0.0 }   // only count what exists
        val scored = areas.filter { it.tasksTotal + it.subGoalsTotal > 0 }
            .map { it to (pct(it.tasksDone, it.tasksTotal) + pct(it.subGoalsDone, it.subGoalsTotal)) / 2 }
        val onTrack = daysLeft?.let { daysLeft > 0 && (progress >= 100.0 - daysLeft * 1.0 || consistency >= 60) }
        return GoalAnalysis(progress.toInt(), consistency.toInt(), subPct.toInt(),
            scored.maxByOrNull { it.second }?.first?.name, scored.minByOrNull { it.second }?.first?.name, onTrack, pct(weeklyActiveDays, 7).coerceAtMost(100.0).toInt())
    }
}

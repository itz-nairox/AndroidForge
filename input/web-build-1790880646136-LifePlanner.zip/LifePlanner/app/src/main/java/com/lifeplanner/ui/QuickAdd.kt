package com.lifeplanner.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lifeplanner.data.*
import com.lifeplanner.domain.Difficulty
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime

private val categories = listOf("Study", "Study/Math", "Study/Science", "Programming/Python", "Programming/Web", "Programming/Projects",
    "English/Vocabulary", "English/Grammar", "English/Listening", "Exercise", "Sleep")

/** Fast add on the first row; time / duration / custom XP / repeat / goal are optional extras. */
@Composable
fun QuickAdd(db: AppDatabase, iso: String) {
    val vm = rememberTaskVm(db)
    var prio by remember { mutableIntStateOf(1) }
    var title by remember { mutableStateOf("") }; var cat by remember { mutableStateOf("Study") }
    var diff by remember { mutableStateOf(Difficulty.EASY) }; var rep by remember { mutableStateOf("NONE") }
    var time by remember { mutableStateOf("") }; var dur by remember { mutableStateOf("30") }; var xp by remember { mutableStateOf("") }
    var more by remember { mutableStateOf(false) }
    var goal by remember { mutableStateOf<GoalEntity?>(null) }
    val goals by remember { db.goals().goals() }.collectAsState(emptyList())
    var catOpen by remember { mutableStateOf(false) }; var goalOpen by remember { mutableStateOf(false) }
    val timeOk = time.isBlank() || Regex("^([01]\\d|2[0-3]):[0-5]\\d$").matches(time)
    Column(Modifier.fillMaxWidth().glassSurface().padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(title, { title = it }, Modifier.weight(1f), label = { Text("Quick add") }, singleLine = true)
            LpButton(enabled = timeOk, onClick = { if (title.isNotBlank()) {
                vm.add(title.trim(), iso, time.ifBlank { null }, dur.toIntOrNull() ?: 30, cat, diff, xp.toIntOrNull(), rep, prio, goal?.id)
                title = ""; time = ""; xp = "" } }) { LIcon(LpIcon.Add, size = 18.dp) }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box { AssistChip({ catOpen = true }, label = { Text(cat) }, leadingIcon = { LIcon(iconForCategory(cat), size = 16.dp) })
                DropdownMenu(catOpen, { catOpen = false }) { categories.forEach { c -> DropdownMenuItem(text = { Text(c) }, onClick = { cat = c; catOpen = false }) } } }
            Difficulty.values().forEach { d -> FilterChip(diff == d, { diff = d }, label = { Text("${d.name.lowercase().replaceFirstChar { it.uppercase() }} +${d.defaultXp}") }) }
            AssistChip({ more = !more }, label = { Text(if (more) "Less" else "More") })
        }
        if (more) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(time, { time = it.take(5) }, Modifier.weight(1f), label = { Text("Start (HH:mm)") }, singleLine = true, isError = !timeOk)
                OutlinedTextField(dur, { dur = it.filter(Char::isDigit).take(3) }, Modifier.weight(1f), label = { Text("Minutes") }, singleLine = true)
                OutlinedTextField(xp, { xp = it.filter(Char::isDigit).take(3) }, Modifier.weight(1f), label = { Text("XP (auto)") }, singleLine = true)
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                priorityNames.forEachIndexed { i, n -> FilterChip(prio == i, { prio = i }, label = { Text(n) }) }
            }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("NONE" to "No repeat", "DAILY" to "Daily", "WEEKLY" to "Weekly").forEach { (k, l) -> FilterChip(rep == k, { rep = k }, label = { Text(l) }) }
                Box { AssistChip({ goalOpen = true }, label = { Text(goal?.title ?: "No goal") })
                    DropdownMenu(goalOpen, { goalOpen = false }) {
                        DropdownMenuItem(text = { Text("No goal") }, onClick = { goal = null; goalOpen = false })
                        goals.forEach { g -> DropdownMenuItem(text = { Text(g.title) }, onClick = { goal = g; goalOpen = false }) } } }
            }
        }
    }
}

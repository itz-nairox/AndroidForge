package com.lifeplanner.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

private fun rarityColor(id: String) = when {
    id.endsWith("legend") -> Color(0xFFFFB300); id.endsWith("epic") -> Color(0xFFAB47BC)
    id.endsWith("rare") -> Color(0xFF29B6F6); else -> Color(0xFF9E9E9E) }

/** Original lightweight 2D vector art for cosmetic Shop items (no real people, no 3D, no bitmaps). */
@Composable
fun ItemArt(id: String, size: Dp = 56.dp) = Canvas(Modifier.size(size)) {
    val w = this.size.width; val h = this.size.height; val c = rarityColor(id)
    drawRoundRect(c.copy(alpha = 0.16f), cornerRadius = CornerRadius(w * 0.22f))
    if (id.startsWith("player")) {
        val kit = c; val skin = Color(0xFFD7A77B)
        drawCircle(skin, w * 0.11f, Offset(w * 0.50f, h * 0.25f))                                     // head
        drawRoundRect(kit, Offset(w * 0.36f, h * 0.36f), Size(w * 0.28f, h * 0.30f), CornerRadius(w * 0.06f)) // shirt
        drawRoundRect(kit, Offset(w * 0.24f, h * 0.38f), Size(w * 0.12f, h * 0.06f), CornerRadius(w * 0.03f)) // arms
        drawRoundRect(kit, Offset(w * 0.64f, h * 0.38f), Size(w * 0.12f, h * 0.06f), CornerRadius(w * 0.03f))
        drawRect(Color(0xFF263238), Offset(w * 0.38f, h * 0.66f), Size(w * 0.10f, h * 0.20f))         // legs
        drawRect(Color(0xFF263238), Offset(w * 0.52f, h * 0.66f), Size(w * 0.10f, h * 0.20f))
        drawCircle(Color.White, w * 0.06f, Offset(w * 0.74f, h * 0.84f)); drawCircle(Color(0xFF263238), w * 0.06f, Offset(w * 0.74f, h * 0.84f), style = androidx.compose.ui.graphics.drawscope.Stroke(2f))
    } else if (id.startsWith("car")) {
        val body = Path().apply { moveTo(w * 0.12f, h * 0.62f); lineTo(w * 0.16f, h * 0.48f); lineTo(w * 0.34f, h * 0.44f); lineTo(w * 0.44f, h * 0.32f)
            lineTo(w * 0.68f, h * 0.32f); lineTo(w * 0.80f, h * 0.46f); lineTo(w * 0.90f, h * 0.50f); lineTo(w * 0.90f, h * 0.62f); close() }
        drawPath(body, c); drawPath(Path().apply { moveTo(w * 0.46f, h * 0.36f); lineTo(w * 0.66f, h * 0.36f); lineTo(w * 0.74f, h * 0.46f); lineTo(w * 0.40f, h * 0.46f); close() }, Color.White.copy(alpha = 0.7f))
        listOf(0.30f, 0.72f).forEach { x -> drawCircle(Color(0xFF263238), w * 0.09f, Offset(w * x, h * 0.64f)); drawCircle(Color.LightGray, w * 0.04f, Offset(w * x, h * 0.64f)) }
    } else {
        drawCircle(c, w * 0.30f, Offset(w / 2, h / 2)); drawCircle(Color.White.copy(alpha = 0.5f), w * 0.14f, Offset(w * 0.42f, h * 0.42f))
    }
}

package com.lifeplanner.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lifeplanner.core.SecureStore
import com.lifeplanner.core.parseFlexibleDate
import com.lifeplanner.data.AppDatabase
import com.lifeplanner.domain.*
import java.time.LocalDate

/** Name, birth date, age, days lived / until birthday, level, XP, streak, goals and achievements. */
@Composable
fun ProfileScreen(db: AppDatabase, s: SecureStore, onBack: () -> Unit) {
    val g = LocalGlass.current; val fa = LocalLang.current == "fa"
    val st = rememberRpgStats(db); val lv = XpEngine.levelFor(st.earnedTotal)
    val today = LocalDate.now(); val b = parseFlexibleDate(s.birth)
    val ach = RpgEngine.achievements(st)
    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(g.spacing.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { LIcon(LpIcon.Back) }
            Text("Profile", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge)
        }
        Row(Modifier.fillMaxWidth().glassSurface().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            LIcon(LpIcon.Person, tint = MaterialTheme.colorScheme.primary, size = 48.dp)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(s.name, style = MaterialTheme.typography.titleLarge)
                if (b != null) Text("Birth date: " + formatDate(b, fa))
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(g.spacing.dp)) {
            LpTile(LpIcon.Level, "${lv.level}", "Level", Modifier.weight(1f))
            LpTile(LpIcon.Xp, "${st.earnedTotal}", "XP", Modifier.weight(1f))
            LpTile(LpIcon.Fire, "${RpgEngine.streak(st.activeDays)}", "Streak", Modifier.weight(1f))
            LpTile(LpIcon.Goals, "${st.goals}", "Goals", Modifier.weight(1f))
        }
        if (b != null) Column(Modifier.fillMaxWidth().glassSurface().padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Age: ${AgeCalc.age(b, today)}")
            Text("Days lived: ${AgeCalc.daysLived(b, today)}")
            Text(if (AgeCalc.isBirthday(b, today)) "Happy birthday" else "Days until birthday: ${AgeCalc.daysUntilNext(b, today)}")
        }
        SectionTitle("Achievements: ${ach.count { it.unlocked }}/${ach.size}", LpIcon.Trophy)
        ach.forEach { a ->
            Row(Modifier.fillMaxWidth().glassSurface().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                LIcon(if (a.unlocked) LpIcon.Trophy else LpIcon.Lock, tint = if (a.unlocked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f))
                Text(a.title)
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

package com.lifeplanner.ui

import androidx.compose.ui.graphics.graphicsLayer

import androidx.compose.material3.Icon
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.PathBuilder
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.size

/** Original line-icon pack (24x24 grid, one stroke style). Stroke weight follows the theme's iconStyle. No emoji anywhere. */
enum class LpIcon(val draw: PathBuilder.() -> Unit) {
    Home({ moveTo(4f, 11f); lineTo(12f, 4f); lineTo(20f, 11f); moveTo(6f, 10f); verticalLineTo(20f); horizontalLineTo(18f); verticalLineTo(10f); moveTo(10f, 20f); verticalLineTo(14f); horizontalLineTo(14f); verticalLineTo(20f) }),
    Calendar({ moveTo(5f, 6f); horizontalLineTo(19f); verticalLineTo(20f); horizontalLineTo(5f); close(); moveTo(5f, 10f); horizontalLineTo(19f); moveTo(9f, 3f); verticalLineTo(7f); moveTo(15f, 3f); verticalLineTo(7f) }),
    Goals({ circle(12f, 12f, 9f); circle(12f, 12f, 5f); circle(12f, 12f, 1f) }),
    Stats({ moveTo(5f, 20f); verticalLineTo(12f); moveTo(12f, 20f); verticalLineTo(5f); moveTo(19f, 20f); verticalLineTo(9f) }),
    Settings({ moveTo(4f, 7f); horizontalLineTo(20f); moveTo(4f, 12f); horizontalLineTo(20f); moveTo(4f, 17f); horizontalLineTo(20f); circle(9f, 7f, 2f); circle(15f, 12f, 2f); circle(8f, 17f, 2f) }),
    Study({ moveTo(4f, 5f); horizontalLineTo(10f); quadTo(12f, 5f, 12f, 7f); verticalLineTo(20f); quadTo(12f, 18f, 10f, 18f); horizontalLineTo(4f); close(); moveTo(20f, 5f); horizontalLineTo(14f); quadTo(12f, 5f, 12f, 7f); moveTo(20f, 5f); verticalLineTo(18f); horizontalLineTo(14f); quadTo(12f, 18f, 12f, 20f) }),
    Code({ moveTo(8f, 8f); lineTo(4f, 12f); lineTo(8f, 16f); moveTo(16f, 8f); lineTo(20f, 12f); lineTo(16f, 16f); moveTo(13.5f, 6f); lineTo(10.5f, 18f) }),
    English({ moveTo(4f, 5f); horizontalLineTo(20f); verticalLineTo(16f); horizontalLineTo(10f); lineTo(6f, 20f); verticalLineTo(16f); horizontalLineTo(4f); close(); moveTo(9f, 13f); lineTo(12f, 8f); lineTo(15f, 13f); moveTo(10f, 11.5f); horizontalLineTo(14f) }),
    Exercise({ moveTo(6f, 8f); verticalLineTo(16f); moveTo(3f, 10f); verticalLineTo(14f); moveTo(18f, 8f); verticalLineTo(16f); moveTo(21f, 10f); verticalLineTo(14f); moveTo(6f, 12f); horizontalLineTo(18f) }),
    Sleep({ moveTo(20f, 14f); arcTo(8f, 8f, 0f, true, true, 10f, 4f); arcTo(6f, 6f, 0f, false, false, 20f, 14f); close() }),
    Xp({ moveTo(13f, 3f); lineTo(5f, 13f); horizontalLineTo(11f); lineTo(10f, 21f); lineTo(19f, 10f); horizontalLineTo(13f); close() }),
    Level({ moveTo(6f, 11f); lineTo(12f, 5f); lineTo(18f, 11f); moveTo(6f, 18f); lineTo(12f, 12f); lineTo(18f, 18f) }),
    Shop({ moveTo(5f, 8f); horizontalLineTo(19f); lineTo(18f, 20f); horizontalLineTo(6f); close(); moveTo(9f, 8f); verticalLineTo(6f); arcTo(3f, 3f, 0f, false, true, 15f, 6f); verticalLineTo(8f) }),
    Trophy({ moveTo(8f, 4f); horizontalLineTo(16f); verticalLineTo(10f); arcTo(4f, 4f, 0f, false, true, 8f, 10f); close(); moveTo(12f, 14f); verticalLineTo(18f); moveTo(8f, 20f); horizontalLineTo(16f); moveTo(8f, 6f); horizontalLineTo(4f); quadTo(4f, 11f, 8f, 11f); moveTo(16f, 6f); horizontalLineTo(20f); quadTo(20f, 11f, 16f, 11f) }),
    Ai({ moveTo(12f, 3f); lineTo(14f, 10f); lineTo(21f, 12f); lineTo(14f, 14f); lineTo(12f, 21f); lineTo(10f, 14f); lineTo(3f, 12f); lineTo(10f, 10f); close() }),
    Lock({ moveTo(6f, 11f); horizontalLineTo(18f); verticalLineTo(20f); horizontalLineTo(6f); close(); moveTo(8f, 11f); verticalLineTo(8f); arcTo(4f, 4f, 0f, false, true, 16f, 8f); verticalLineTo(11f) }),
    Rpg({ moveTo(12f, 3f); lineTo(19f, 6f); verticalLineTo(12f); quadTo(19f, 18f, 12f, 21f); quadTo(5f, 18f, 5f, 12f); verticalLineTo(6f); close() }),
    Football({ circle(12f, 12f, 9f); moveTo(12f, 8f); lineTo(15f, 10f); lineTo(14f, 14f); horizontalLineTo(10f); lineTo(9f, 10f); close(); moveTo(12f, 8f); verticalLineTo(3f); moveTo(15f, 10f); lineTo(20f, 8.5f); moveTo(14f, 14f); lineTo(17f, 19f); moveTo(10f, 14f); lineTo(7f, 19f); moveTo(9f, 10f); lineTo(4f, 8.5f) }),
    Car({ moveTo(3f, 15f); verticalLineTo(12f); lineTo(6f, 8f); horizontalLineTo(15f); lineTo(19f, 12f); horizontalLineTo(21f); verticalLineTo(15f); horizontalLineTo(3f); close(); circle(7f, 16f, 2f); circle(17f, 16f, 2f) }),
    Add({ moveTo(12f, 5f); verticalLineTo(19f); moveTo(5f, 12f); horizontalLineTo(19f) }),
    Check({ moveTo(5f, 12f); lineTo(10f, 17f); lineTo(19f, 7f) }),
    Delete({ moveTo(5f, 7f); horizontalLineTo(19f); moveTo(9f, 7f); verticalLineTo(4f); horizontalLineTo(15f); verticalLineTo(7f); moveTo(7f, 7f); lineTo(8f, 20f); horizontalLineTo(16f); lineTo(17f, 7f) }),
    Back({ moveTo(15f, 5f); lineTo(8f, 12f); lineTo(15f, 19f) }),
    Clock({ circle(12f, 12f, 9f); moveTo(12f, 7f); verticalLineTo(12f); lineTo(15.5f, 14f) }),
    Fire({ moveTo(12f, 3f); quadTo(18f, 9f, 17f, 15f); arcTo(5f, 5f, 0f, false, true, 7f, 15f); quadTo(7f, 11f, 10f, 9f); quadTo(10f, 12f, 12f, 12f); quadTo(13f, 8f, 12f, 3f); close() }),
    Person({ circle(12f, 8f, 4f); moveTo(4f, 21f); quadTo(4f, 14f, 12f, 14f); quadTo(20f, 14f, 20f, 21f) }),
    Gift({ moveTo(5f, 11f); horizontalLineTo(19f); verticalLineTo(20f); horizontalLineTo(5f); close(); moveTo(4f, 8f); horizontalLineTo(20f); verticalLineTo(11f); horizontalLineTo(4f); close(); moveTo(12f, 8f); verticalLineTo(20f); moveTo(12f, 8f); quadTo(8f, 8f, 8f, 5.5f); quadTo(11f, 4f, 12f, 8f); quadTo(13f, 4f, 16f, 5.5f); quadTo(16f, 8f, 12f, 8f) }),
    Palette({ moveTo(12f, 3f); arcTo(9f, 9f, 0f, true, false, 12f, 21f); quadTo(14f, 21f, 14f, 19f); quadTo(14f, 17f, 16f, 17f); horizontalLineTo(18f); quadTo(21f, 17f, 21f, 12f); arcTo(9f, 9f, 0f, false, false, 12f, 3f); circle(8f, 11f, 1f); circle(12f, 7.5f, 1f); circle(16f, 11f, 1f) });

    fun vector(w: Float): ImageVector = ImageVector.Builder(name, 24.dp, 24.dp, 24f, 24f).path(
        fill = null, stroke = SolidColor(Color.Black), strokeLineWidth = w,
        strokeLineCap = StrokeCap.Round, strokeLineJoin = StrokeJoin.Round, pathBuilder = draw).build()
}

private fun PathBuilder.circle(cx: Float, cy: Float, r: Float) {
    moveTo(cx - r, cy); arcTo(r, r, 0f, true, true, cx + r, cy); arcTo(r, r, 0f, true, true, cx - r, cy); close()
}

/** Maps a task category ("Programming/Python", "English", ...) to its icon. */
fun iconForCategory(cat: String): LpIcon = when (cat.substringBefore("/")) {
    "Study", "School" -> LpIcon.Study
    "Programming" -> LpIcon.Code
    "English" -> LpIcon.English
    "Exercise" -> LpIcon.Exercise
    "Sleep", "Health" -> LpIcon.Sleep
    else -> LpIcon.Clock
}

@Composable
fun LIcon(i: LpIcon, modifier: Modifier = Modifier, tint: Color = LocalContentColor.current, size: Dp = 24.dp) {
    val w = if (LocalGlass.current.iconStyle == "BOLD") 2.5f else 1.6f
    val v = remember(i, w) { i.vector(w) }
    val rtl = androidx.compose.ui.platform.LocalLayoutDirection.current == androidx.compose.ui.unit.LayoutDirection.Rtl
    val m = if (rtl && i == LpIcon.Back) modifier.graphicsLayer { scaleX = -1f } else modifier
    Icon(v, null, m.size(size), tint)
}

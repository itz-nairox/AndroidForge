package com.lifeplanner.data

import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** JSON backup of user data only (no PIN, no AI key). */
object BackupManager {
    private fun JSONObject.l(k: String) = if (has(k) && !isNull(k)) getLong(k) else null
    private fun JSONObject.s(k: String) = if (has(k) && !isNull(k)) getString(k) else null
    private fun <T> arr(l: List<T>, f: (T) -> JSONObject) = JSONArray().also { a -> l.forEach { a.put(f(it)) } }
    private fun <T> JSONArray.map(f: (JSONObject) -> T) = (0 until length()).map { f(getJSONObject(it)) }

    data class Profile(val name: String, val birth: String)

    suspend fun export(db: AppDatabase, profile: Profile? = null): String { val b = db.backup(); return JSONObject().apply {
        put("app", "lifeplanner"); put("version", 3)
        if (profile != null) put("profile", JSONObject().put("name", profile.name).put("birth", profile.birth))
        put("claims", JSONArray(b.claims()))
        put("tasks", arr(b.tasks()) { JSONObject().put("id", it.id).put("title", it.title).put("description", it.description).put("date", it.date)
            .put("startTime", it.startTime).put("durationMin", it.durationMin).put("category", it.category).put("difficulty", it.difficulty)
            .put("xpReward", it.xpReward).put("repeat", it.repeat).put("priority", it.priority).put("goalId", it.goalId).put("subGoalId", it.subGoalId) })
        put("completions", arr(b.completions()) { JSONObject().put("id", it.id).put("taskId", it.taskId).put("date", it.date).put("completed", it.completed).put("xpGranted", it.xpGranted) })
        put("xp", arr(b.xp()) { JSONObject().put("id", it.id).put("date", it.date).put("source", it.source).put("category", it.category).put("amount", it.amount) })
        put("goals", arr(b.goals()) { JSONObject().put("id", it.id).put("title", it.title).put("deadline", it.deadline).put("notes", it.notes) })
        put("subs", arr(b.subs()) { JSONObject().put("id", it.id).put("goalId", it.goalId).put("parentId", it.parentId).put("title", it.title)
            .put("deadline", it.deadline).put("notes", it.notes).put("done", it.done) })
        put("presets", arr(db.presets().snapshot()) { JSONObject().put("id", it.id).put("name", it.name).put("json", it.json) })
        put("owned", arr(b.owned()) { JSONObject().put("itemId", it.itemId).put("active", it.active) })
    }.toString(2) }

    /** Parses everything first (a bad file never touches your data), then replaces the current data. Returns the saved profile if present. */
    suspend fun import(db: AppDatabase, text: String): Profile? {
        val j = JSONObject(text); require(j.optString("app") == "lifeplanner") { "Not a Life Planner backup" }
        require(j.optInt("version", 1) <= 3) { "Backup is from a newer app version" }
        val tasks = j.getJSONArray("tasks").map { TaskEntity(it.getLong("id"), it.getString("title"), it.getString("description"), it.getString("date"),
            it.s("startTime"), it.getInt("durationMin"), it.getString("category"), it.getString("difficulty"), it.getInt("xpReward"),
            it.getString("repeat"), it.getInt("priority"), it.l("goalId"), it.l("subGoalId")) }
        val comps = j.getJSONArray("completions").map { TaskCompletionEntity(it.getLong("id"), it.getLong("taskId"), it.getString("date"), it.getBoolean("completed"), it.getInt("xpGranted")) }
        val xp = j.getJSONArray("xp").map { XpTransactionEntity(it.getLong("id"), it.getString("date"), it.getString("source"), it.getString("category"), it.getInt("amount")) }
        val goals = j.getJSONArray("goals").map { GoalEntity(it.getLong("id"), it.getString("title"), it.s("deadline"), it.getString("notes")) }
        val subs = j.getJSONArray("subs").map { SubGoalEntity(it.getLong("id"), it.getLong("goalId"), it.l("parentId"), it.getString("title"), it.s("deadline"), it.getString("notes"), it.getBoolean("done")) }
        val presets = if (j.has("presets")) j.getJSONArray("presets").map { ThemePresetEntity(it.getLong("id"), it.getString("name"), it.getString("json")) } else emptyList()
        val owned = j.getJSONArray("owned").map { OwnedItemEntity(it.getString("itemId"), it.getBoolean("active")) }
        val claims = if (j.has("claims")) (0 until j.getJSONArray("claims").length()).map { QuestClaimEntity(j.getJSONArray("claims").getString(it)) } else emptyList()
        val profile = j.optJSONObject("profile")?.let { Profile(it.optString("name"), it.optString("birth")) }
        withContext(Dispatchers.IO) { db.clearAllTables() }
        val b = db.backup()
        db.withTransaction {
            b.putTasks(tasks); b.putCompletions(comps); b.putXp(xp); b.putGoals(goals); b.putSubs(subs)
            db.presets().putAll(presets); b.putOwned(owned); b.putClaims(claims)
        }
        return profile
    }
}

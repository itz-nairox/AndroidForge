package com.lifeplanner.domain

import androidx.room.withTransaction
import com.lifeplanner.data.*
import java.time.LocalDate

/** Spending is a negative XpTransaction; Level uses earned XP only so buying never de-levels. */
class PurchaseUseCase(private val db: AppDatabase) {
    suspend operator fun invoke(item: ShopItem, balance: Int): Boolean = db.withTransaction {
        if (db.owned().has(item.id) > 0 || db.xp().totalNow() < item.price) return@withTransaction false
        db.xp().insert(XpTransactionEntity(date = LocalDate.now().toString(), source = item.name, category = "Shop", amount = -item.price))
        db.owned().insert(OwnedItemEntity(item.id)); true
    }
}

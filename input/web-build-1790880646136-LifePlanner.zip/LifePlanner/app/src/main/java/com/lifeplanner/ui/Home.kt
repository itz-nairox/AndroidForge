package com.lifeplanner.ui

import androidx.compose.animation.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lifeplanner.App
import com.lifeplanner.core.PersianCalendar
import com.lifeplanner.data.AppDatabase
import com.lifeplanner.data.TaskEntity
import com.lifeplanner.domain.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

fun formatDate(d: LocalDate, fa: Boolean) = if (fa) PersianCalendar.format(d) else d.format(DateTimeFormatter.ofPattern("MMMM d, yyyy", Locale.ENGLISH))

@Composable
fun Home(db: AppDatabase, onRpg: () -> Unit, onAi: () -> Unit, onProfile: () -> Unit) {
    val vm = rememberTaskVm(db)
    var editing by remember { mutableStateOf<TaskEntity?>(null) }
    val g = LocalGlass.current
    val fa = LocalLang.current == "fa"
    val sec = (androidx.compose.ui.platform.LocalContext.current.applicationContext as App).secure
    val today = LocalDate.now()                       // always the real device date
    val iso = today.toString()
    val tasks by remember(iso) { vm.tasks(iso) }.collectAsState(emptyList())
    val comps by remember(iso) { vm.completions(iso) }.collectAsState(emptyList())
    val doneIds = comps.filter { it.completed }.map { it.taskId }.toSet()
    val totalXpN by remember { db.xp().earned() }.collectAsState(null)
    val balance by remember { db.xp().total() }.collectAsState(0)
    val days by remember { db.rpg().activeDays() }.collectAsState(emptyList())
    val goals by remember { db.goals().goals() }.collectAsState(emptyList())
    val totalXp = totalXpN ?: 0
    val lv = XpEngine.levelFor(totalXp)
    val haptic = rememberHaptic()
    editing?.let { EditTaskDialog(it, { t -> vm.update(t); editing = null }, { editing = null }) }

    var gain by remember { mutableIntStateOf(0) }
    var showUp by remember { mutableStateOf(false) }
    var lastLevel by remember { mutableIntStateOf(-1) }
    LaunchedEffect(lv.level, totalXpN != null) {
        if (totalXpN != null) {
            if (lastLevel != -1 && lv.level > lastLevel) { showUp = true; haptic(); delay(2600); showUp = false }
            lastLevel = lv.level
        }
    }
    LaunchedEffect(gain) { if (gain > 0) { delay(1500); gain = 0 } }

    val hour = LocalTime.now().hour
    val greet = when { hour < 12 -> "Good morning"; hour < 18 -> "Good afternoon"; else -> "Good evening" }
    val timed = tasks.filter { it.startTime != null }
    val now = LocalTime.now().let { it.hour * 60 + it.minute }
    fun mins(t: String) = t.substringBefore(":").toInt() * 60 + t.substringAfter(":").toInt()

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(g.spacing.dp + 4.dp), verticalArrangement = Arrangement.spacedBy(g.spacing.dp)) {
        item {
            Row(Modifier.fillMaxWidth().glassSurface().clickable { onProfile() }.padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                LpLogo(48.dp)
                Column(Modifier.weight(1f)) {
                    Text(tr(greet, LocalLang.current) + (if (fa) "، " else ", ") + sec.name, style = MaterialTheme.typography.titleMedium)
                    Text(formatDate(today, fa), style = MaterialTheme.typography.bodyMedium)
                }
                Column(horizontalAlignment = Alignment.End) { Text("Level ${lv.level}", style = MaterialTheme.typography.titleMedium); Text("${lv.xpIntoLevel}/${lv.xpForNext} XP", style = MaterialTheme.typography.labelSmall) }
            }
        }
        item { AnimatedVisibility(showUp && g.animations, enter = scaleIn() + fadeIn(), exit = fadeOut()) {
            Row(Modifier.fillMaxWidth().glassSurface().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                LIcon(LpIcon.Level, tint = MaterialTheme.colorScheme.primary, size = 32.dp); Text("LEVEL UP  -  ${lv.level}", style = MaterialTheme.typography.headlineSmall) } } }
        item { HeroSection() }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(g.spacing.dp)) {
                LpTile(LpIcon.Level, "${lv.level}", "Level", Modifier.weight(1f))
                LpTile(LpIcon.Xp, "$balance", "XP", Modifier.weight(1f))
                LpTile(LpIcon.Fire, "${RpgEngine.streak(days)}", "Streak", Modifier.weight(1f))
            }
        }
        item {
            Column(Modifier.fillMaxWidth().glassSurface().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Level progress", style = MaterialTheme.typography.titleSmall)
                LpProgress(lv.xpIntoLevel / lv.xpForNext.toFloat(), ring = 64.dp)
                AnimatedVisibility(gain > 0 && g.animations, enter = slideInVertically { it / 2 } + fadeIn(), exit = fadeOut()) {
                    Text("+$gain XP", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary) }
            }
        }
        item {
            val done = tasks.count { it.id in doneIds }
            val frac = if (tasks.isEmpty()) 0f else done / tasks.size.toFloat()
            if (g.progressStyle == "RING") Row(Modifier.fillMaxWidth().glassSurface().padding(14.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                LpProgress(frac, ring = 64.dp)
                Column { Text("Today's Progress", style = MaterialTheme.typography.titleSmall); Text("$done / ${tasks.size}  Tasks") }
            } else Column(Modifier.fillMaxWidth().glassSurface().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Today's Progress", style = MaterialTheme.typography.titleSmall); LpProgress(frac); Text("$done / ${tasks.size}  Tasks")
            }
        }
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LpOutlinedButton(onRpg) { LIcon(LpIcon.Rpg, size = 18.dp); Spacer(Modifier.width(6.dp)); Text("Life RPG - Shop") }
            LpOutlinedButton(onAi) { LIcon(LpIcon.Ai, size = 18.dp); Spacer(Modifier.width(6.dp)); Text("AI Assistant") } } }
        if (goals.isNotEmpty()) {
            item { SectionTitle("Goal Progress", LpIcon.Goals) }
            items(goals.take(3), key = { "g${it.id}" }) { gl -> GoalMini(db, gl) }
        }
        item { QuickAdd(db, iso) }
        if (timed.isNotEmpty()) {
            item { SectionTitle("Today's Schedule", LpIcon.Clock) }
            item {
                Column(Modifier.fillMaxWidth().glassSurface().padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    timed.forEach { t ->
                        val s = mins(t.startTime!!); val active = now in s until (s + t.durationMin)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(t.startTime!!, style = MaterialTheme.typography.labelLarge, color = if (active) MaterialTheme.colorScheme.primary else androidx.compose.ui.graphics.Color.Unspecified)
                            LIcon(iconForCategory(t.category), size = 18.dp, tint = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                            Text(t.title, Modifier.weight(1f)); Text("${t.durationMin} min", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
        item { SectionTitle("Tasks", LpIcon.Check) }
        items(tasks, key = { it.id }) { t -> TaskRow(t, t.id in doneIds,
            onToggle = { checked -> vm.toggle(t, iso, checked) { x -> if (x > 0) gain = x }; if (checked) haptic() },
            onDelete = { vm.delete(t) }, onEdit = { editing = t }) }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
fun TaskRow(t: TaskEntity, done: Boolean, onToggle: (Boolean) -> Unit, onDelete: () -> Unit, onEdit: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().glassSurface().padding(horizontal = 8.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(done, onToggle)
        LIcon(iconForCategory(t.category), size = 20.dp, tint = MaterialTheme.colorScheme.primary)
        Column(Modifier.weight(1f).clickable { onEdit() }.padding(start = 8.dp)) {
            Text(t.title, style = MaterialTheme.typography.bodyLarge)
            Text(listOfNotNull(t.startTime, "${t.durationMin} min", "+${t.xpReward} XP", if (t.priority == 2) "High" else null).joinToString("  |  "), style = MaterialTheme.typography.labelSmall)
        }
        IconButton(onDelete) { LIcon(LpIcon.Delete, size = 20.dp) }
    }
}

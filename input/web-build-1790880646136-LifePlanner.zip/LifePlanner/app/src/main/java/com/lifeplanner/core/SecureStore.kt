package com.lifeplanner.core

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Encrypted prefs: PIN is stored only as salted PBKDF2 hash. Also holds profile fields. */
class SecureStore(ctx: Context) {
    private val p = openStore(ctx)
    private companion object {
        fun make(ctx: Context) = EncryptedSharedPreferences.create(ctx, "secure",
            MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
        /** If the Keystore key is gone (new phone, restored backup) the old file is unreadable: start clean instead of crashing. */
        fun openStore(ctx: Context) = try { make(ctx) } catch (e: Exception) { ctx.deleteSharedPreferences("secure"); make(ctx) }
    }
    var name: String get() = p.getString("name", "") ?: ""; set(v) = p.edit().putString("name", v).apply()
    var birth: String get() = p.getString("birth", "") ?: ""; set(v) = p.edit().putString("birth", v).apply()
    var perf: Perf
        get() = Perf(p.getBoolean("saver", false), p.getBoolean("smart", true), p.getString("refresh", "AUTO") ?: "AUTO")
        set(v) = p.edit().putBoolean("saver", v.saver).putBoolean("smart", v.smart).putString("refresh", v.refresh).apply()
    var aiEnabled: Boolean get() = p.getBoolean("ai_on", false); set(v) = p.edit().putBoolean("ai_on", v).apply()
    var aiShare: Boolean get() = p.getBoolean("ai_share", false); set(v) = p.edit().putBoolean("ai_share", v).apply()
    var aiProvider: String get() = p.getString("ai_prov", "OPENAI") ?: "OPENAI"; set(v) = p.edit().putString("ai_prov", v).apply()
    var aiBase: String get() = p.getString("ai_base", "https://api.openai.com/v1") ?: ""; set(v) = p.edit().putString("ai_base", v).apply()
    var aiModel: String get() = p.getString("ai_model", "") ?: ""; set(v) = p.edit().putString("ai_model", v).apply()
    var aiKey: String get() = p.getString("ai_key", "") ?: ""; set(v) = p.edit().putString("ai_key", v).apply()   // encrypted at rest
    var themeJson: String? get() = p.getString("theme", null); set(v) = p.edit().putString("theme", v).apply()
    var haptics: Boolean get() = p.getBoolean("haptics", true); set(v) = p.edit().putBoolean("haptics", v).apply()
    var animations: Boolean get() = p.getBoolean("anim", true); set(v) = p.edit().putBoolean("anim", v).apply()
    var notifOn: Boolean get() = p.getBoolean("notif", false); set(v) = p.edit().putBoolean("notif", v).apply()
    var notifHour: Int get() = p.getInt("notif_h", 18); set(v) = p.edit().putInt("notif_h", v).apply()
    var lang: String get() = p.getString("lang", "SYSTEM") ?: "SYSTEM"; set(v) = p.edit().putString("lang", v).apply()
    var autoLockMin: Int get() = p.getInt("autolock", 1); set(v) = p.edit().putInt("autolock", v).apply()
    var sounds: Boolean get() = p.getBoolean("sounds", false); set(v) = p.edit().putBoolean("sounds", v).apply()
    var bdShown: String get() = p.getString("bd_shown", "") ?: ""; set(v) = p.edit().putString("bd_shown", v).apply()
    var seenAch: Set<String> get() = p.getStringSet("seen_ach", emptySet()) ?: emptySet(); set(v) = p.edit().putStringSet("seen_ach", v.toSet()).apply()
    fun hasPin() = p.contains("pin_hash")
    private fun hash(pin: String, salt: ByteArray) =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(PBEKeySpec(pin.toCharArray(), salt, 60_000, 256)).encoded
    /** Sets the PIN and returns a one-time recovery code (only its salted hash is stored). */
    fun setPin(pin: String): String {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; val rnd = SecureRandom()
        val code = (1..12).map { alphabet[rnd.nextInt(alphabet.length)] }.joinToString("")
        val rsalt = ByteArray(16).also { rnd.nextBytes(it) }
        p.edit().putString("pin_salt", salt.toHex()).putString("pin_hash", hash(pin, salt).toHex())
            .putString("rec_salt", rsalt.toHex()).putString("rec_hash", hash(code, rsalt).toHex()).putInt("fails", 0).apply()
        return code
    }
    /** Seconds the lock screen must wait after repeated wrong attempts (0 = may try now). */
    fun lockRemainingSec(): Int = ((p.getLong("locked_until", 0) - System.currentTimeMillis()) / 1000).toInt().coerceAtLeast(0)
    private fun fail() {
        val n = p.getInt("fails", 0) + 1
        p.edit().putInt("fails", n).apply { if (n >= 5) putLong("locked_until", System.currentTimeMillis() + 30_000L * (n - 4)) }.apply()
    }
    fun verify(pin: String): Boolean {
        if (lockRemainingSec() > 0) return false
        val s = p.getString("pin_salt", null) ?: return false
        val ok = MessageDigestEq(hash(pin, s.fromHex()).toHex(), p.getString("pin_hash", "")!!)
        if (ok) p.edit().putInt("fails", 0).apply() else fail()
        return ok
    }
    /** Correct recovery code removes the PIN (the user then sets a new one). */
    fun recover(code: String): Boolean {
        if (lockRemainingSec() > 0) return false
        val s = p.getString("rec_salt", null) ?: return false
        val ok = MessageDigestEq(hash(code.trim().uppercase(), s.fromHex()).toHex(), p.getString("rec_hash", "")!!)
        if (ok) { clearPin() } else fail()
        return ok
    }
    fun clearPin() = p.edit().remove("pin_hash").remove("pin_salt").remove("rec_hash").remove("rec_salt").putInt("fails", 0).apply()
    private fun ByteArray.toHex() = joinToString("") { "%02x".format(it) }
    private fun String.fromHex() = chunked(2).map { it.toInt(16).toByte() }.toByteArray()
    private fun MessageDigestEq(a: String, b: String) = java.security.MessageDigest.isEqual(a.toByteArray(), b.toByteArray())
}

package com.lifeplanner.theme

/** Whole-app looks unlocked from the Shop (ids match ShopCatalog). Each changes radii, progress, icons, font and navigation, not just color. */
object ThemePresets {
    private val m = mapOf(
        "theme_glass_studio" to ThemeConfig("Liquid Glass Studio", accent = 0xFF7C4DFF, background = 0xFF0E0E14),
        "theme_midnight" to ThemeConfig("Midnight Galaxy", accent = 0xFF5C6BC0, background = 0xFF0A0F24, glassIntensity = 90, navStyle = "FLOATING"),
        "theme_ocean" to ThemeConfig("Ocean Depth", accent = 0xFF00B8D4, background = 0xFF04202B, progressStyle = "BAR", cardRadius = 22, blur = 80),
        "theme_forest" to ThemeConfig("Forest", accent = 0xFF43A047, background = 0xFF0B1A10, cardRadius = 16, progressStyle = "BAR", font = "SERIF", glow = false),
        "theme_sunset" to ThemeConfig("Sunset", accent = 0xFFFF7043, background = 0xFF24110D, cardRadius = 26, progressStyle = "SEGMENTS", navStyle = "FLOATING"),
        "theme_sakura" to ThemeConfig("Sakura", accent = 0xFFF48FB1, background = 0xFF2A1520, cardRadius = 32, buttonRadius = 32, navStyle = "FLOATING", iconStyle = "MINIMAL"),
        "theme_neon" to ThemeConfig("Cyber Neon", accent = 0xFF00E5FF, background = 0xFF0A0A12, cardRadius = 8, buttonRadius = 8, inputRadius = 8, progressStyle = "SEGMENTS", iconStyle = "BOLD", font = "MONO", glow = true),
        "theme_gold" to ThemeConfig("Legendary Gold", accent = 0xFFFFC107, background = 0xFF17130A, cardRadius = 20, iconStyle = "BOLD", font = "SERIF", progressStyle = "RING"))
    fun of(id: String) = m[id] ?: ThemeConfig("Default")
}

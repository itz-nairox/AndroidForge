package com.lifeplanner.theme

import org.json.JSONObject

/** Pure appearance data (no user data). Serialized to *.lptheme (JSON). Colors of 0 mean "derive automatically". */
data class ThemeConfig(
    val name: String, val accent: Long = 0xFF7C4DFF, val background: Long = 0xFF0E0E14,
    val card: Long = 0, val button: Long = 0,
    val mode: String = "DARK",                       // LIGHT | DARK | SYSTEM
    val glass: Boolean = true,
    val glassIntensity: Int = 80, val blur: Int = 60, val transparency: Int = 70,
    val reflection: Boolean = true, val glow: Boolean = true, val shadow: Boolean = true, val motion: Boolean = true,
    val animations: Boolean = true, val decor: Boolean = true,
    val cardRadius: Int = 28, val buttonRadius: Int = 24, val inputRadius: Int = 16,
    val progressRadius: Int = 8, val navRadius: Int = 24, val dialogRadius: Int = 28,
    val progressStyle: String = "RING",              // RING | BAR | SEGMENTS
    val iconStyle: String = "MINIMAL",               // MINIMAL | BOLD
    val navStyle: String = "BAR",                    // BAR | FLOATING
    val density: String = "COMFORT",                 // COMPACT | COMFORT | SPACIOUS
    val font: String = "DEFAULT", val fontScale: Float = 1f, val version: Int = 2
) {
    val spacing: Int get() = when (density) { "COMPACT" -> 8; "SPACIOUS" -> 18; else -> 12 }

    fun toJson(): String = JSONObject().apply {
        put("format", "lptheme"); put("version", version); put("name", name)
        put("accent", accent); put("background", background); put("card", card); put("button", button); put("mode", mode)
        put("glass", glass); put("glassIntensity", glassIntensity); put("blur", blur); put("transparency", transparency)
        put("reflection", reflection); put("glow", glow); put("shadow", shadow); put("motion", motion)
        put("animations", animations); put("decor", decor)
        put("cardRadius", cardRadius); put("buttonRadius", buttonRadius); put("inputRadius", inputRadius)
        put("progressRadius", progressRadius); put("navRadius", navRadius); put("dialogRadius", dialogRadius)
        put("progressStyle", progressStyle); put("iconStyle", iconStyle); put("navStyle", navStyle); put("density", density)
        put("font", font); put("fontScale", fontScale.toDouble())
    }.toString(2)

    companion object {
        /** Lenient: unknown/missing keys fall back to defaults; old v1 files ("dark": bool) still load. */
        fun fromJson(s: String): ThemeConfig {
            val j = JSONObject(s); require(j.optString("format") == "lptheme") { "Not an .lptheme file" }
            val d = ThemeConfig(j.getString("name"))
            fun r(k: String, def: Int) = j.optInt(k, def).coerceIn(0, 48)
            return d.copy(
                accent = j.optLong("accent", d.accent), background = j.optLong("background", d.background),
                card = j.optLong("card", 0), button = j.optLong("button", 0),
                mode = if (j.has("mode")) j.getString("mode") else if (j.optBoolean("dark", true)) "DARK" else "LIGHT",
                glass = j.optBoolean("glass", d.glass),
                glassIntensity = j.optInt("glassIntensity", d.glassIntensity).coerceIn(0, 100),
                blur = j.optInt("blur", d.blur).coerceIn(0, 100), transparency = j.optInt("transparency", d.transparency).coerceIn(0, 100),
                reflection = j.optBoolean("reflection", true), glow = j.optBoolean("glow", true),
                shadow = j.optBoolean("shadow", true), motion = j.optBoolean("motion", true),
                animations = j.optBoolean("animations", true), decor = j.optBoolean("decor", true),
                cardRadius = r("cardRadius", d.cardRadius), buttonRadius = r("buttonRadius", d.buttonRadius), inputRadius = r("inputRadius", d.inputRadius),
                progressRadius = r("progressRadius", d.progressRadius), navRadius = r("navRadius", d.navRadius), dialogRadius = r("dialogRadius", d.dialogRadius),
                progressStyle = j.optString("progressStyle", d.progressStyle), iconStyle = j.optString("iconStyle", d.iconStyle),
                navStyle = j.optString("navStyle", d.navStyle), density = j.optString("density", d.density),
                font = j.optString("font", d.font), fontScale = j.optDouble("fontScale", 1.0).toFloat().coerceIn(0.8f, 1.4f))
        }
    }
}

package com.lifeplanner.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.lifeplanner.core.Perf
import com.lifeplanner.core.SecureStore
import com.lifeplanner.data.AppDatabase
import com.lifeplanner.theme.ThemeConfig

private val nav = listOf("Home" to LpIcon.Home, "Calendar" to LpIcon.Calendar, "Goals" to LpIcon.Goals, "Statistics" to LpIcon.Stats, "Settings" to LpIcon.Settings)

@Composable
fun Root(db: AppDatabase, secure: SecureStore, theme: ThemeConfig, perf: Perf, onPerf: (Perf) -> Unit, onTheme: (ThemeConfig) -> Unit) {
    val g = LocalGlass.current
    var overlay by remember { mutableIntStateOf(-1) }   // -1 none, 0 Life RPG (entered from Home), 1 AI assistant
    var tab by remember { mutableIntStateOf(0) }
    BackHandler(overlay != -1) { overlay = -1 }
    Box(Modifier.fillMaxSize()) {
    Scaffold(containerColor = Color.Transparent, bottomBar = { NavBar(tab) { tab = it; overlay = -1 } }) { pad ->
        AnimatedContent(if (overlay != -1) 100 + overlay else tab, Modifier.padding(pad).consumeWindowInsets(pad).imePadding().fillMaxSize(), transitionSpec = {
            if (!g.animations) EnterTransition.None togetherWith ExitTransition.None
            else (fadeIn(tween(240)) + slideInVertically(tween(240)) { it / 24 }) togetherWith fadeOut(tween(120)) }, label = "page") { v ->
            when (v) {
                100 -> RpgScreen(db) { overlay = -1 }
                101 -> AiScreen(db, secure) { overlay = -1 }
                102 -> ProfileScreen(db, secure) { overlay = -1 }
                0 -> Home(db, { overlay = 0 }, { overlay = 1 }) { overlay = 2 }
                1 -> CalendarScreen(db)
                2 -> GoalsScreen(db)
                3 -> StatsScreen(db)
                else -> SettingsScreen(db, secure, theme, onTheme, perf, onPerf)
            }
        }
    }
    AchievementWatcher(db, secure, Modifier.align(Alignment.TopCenter))
    }
}

@Composable
private fun NavBar(sel: Int, onSel: (Int) -> Unit) {
    val g = LocalGlass.current
    val floating = g.navStyle == "FLOATING"
    val r = g.navRadius.dp
    val shape = if (floating) RoundedCornerShape(r) else RoundedCornerShape(topStart = r, topEnd = r)
    Row(Modifier.fillMaxWidth().then(if (floating) Modifier.padding(horizontal = 14.dp, vertical = 8.dp) else Modifier)
        .parallax().clip(shape).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = if (g.glass) 0.88f else 1f)).navigationBarsPadding().padding(vertical = 8.dp)) {
        nav.forEachIndexed { i, (n, ic) ->
            val on = i == sel
            Column(Modifier.weight(1f).clickable { onSel(i) }.padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                LIcon(ic, tint = if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                Text(n, style = MaterialTheme.typography.labelSmall, color = if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            }
        }
    }
}

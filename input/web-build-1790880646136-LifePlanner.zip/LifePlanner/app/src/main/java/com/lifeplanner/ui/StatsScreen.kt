package com.lifeplanner.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lifeplanner.data.AppDatabase
import com.lifeplanner.domain.XpEngine
import java.time.DayOfWeek
import java.time.LocalDate

private enum class Period(val label: String) { DAILY("Daily"), WEEKLY("Weekly"), MONTHLY("Monthly"), YEARLY("Yearly") }

@Composable
fun StatsScreen(db: AppDatabase) {
    val g = LocalGlass.current
    val today = LocalDate.now()
    var period by remember { mutableStateOf(Period.WEEKLY) }
    // sum range = what the tiles describe; chart range = what the bars show
    val (sumA, sumB) = when (period) {
        Period.DAILY -> today to today
        Period.WEEKLY -> today.with(DayOfWeek.MONDAY) to today
        Period.MONTHLY -> today.withDayOfMonth(1) to today
        Period.YEARLY -> today.withDayOfYear(1) to today }
    val chartA = if (period == Period.DAILY) today.minusDays(6) else sumA
    val xp by remember(chartA.toString(), today.toString()) { db.stats().gainedByDay(chartA.toString(), today.toString()) }.collectAsState(emptyList())
    val done by remember(sumA.toString(), sumB.toString()) { db.stats().doneByDay(sumA.toString(), sumB.toString()) }.collectAsState(emptyList())
    val planned by remember(sumA.toString(), sumB.toString()) { db.stats().taskCounts(sumA.toString(), sumB.toString()) }.collectAsState(emptyList())
    val cats by remember(sumA.toString(), sumB.toString()) { db.stats().catXpBetween(sumA.toString(), sumB.toString()) }.collectAsState(emptyList())
    val earnedAll by remember { db.xp().earned() }.collectAsState(0)
    val goals by remember { db.goals().goals() }.collectAsState(emptyList())

    // buckets for the chart
    val buckets: List<Pair<String, Int>> = if (period == Period.YEARLY)
        (1..today.monthValue).map { m -> "$m" to xp.filter { it.date.substring(5, 7).toInt() == m }.sumOf { it.total } }
    else generateSequence(chartA) { it.plusDays(1) }.takeWhile { !it.isAfter(today) }.map { d -> "${d.dayOfMonth}" to (xp.firstOrNull { it.date == d.toString() }?.total ?: 0) }.toList()
    val max = (buckets.maxOfOrNull { it.second } ?: 0).coerceAtLeast(1)

    val xpSum = xp.filter { it.date >= sumA.toString() }.sumOf { it.total }
    val doneN = done.sumOf { it.c }; val plannedN = planned.sumOf { it.c }
    val mins = done.sumOf { it.m }
    val pct = if (plannedN == 0) 0 else (doneN * 100 / plannedN).coerceAtMost(100)
    val lv = XpEngine.levelFor(earnedAll)

    Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(g.spacing.dp)) {
        Text("Statistics", style = MaterialTheme.typography.titleLarge)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Period.values().forEach { p -> FilterChip(period == p, { period = p }, label = { Text(p.label) }) } }
        Row(horizontalArrangement = Arrangement.spacedBy(g.spacing.dp)) {
            LpTile(LpIcon.Xp, "$xpSum", "XP", Modifier.weight(1f))
            LpTile(LpIcon.Check, "$doneN/$plannedN", "Tasks", Modifier.weight(1f))
            LpTile(LpIcon.Clock, "${mins / 60}h ${mins % 60}m", "Time spent", Modifier.weight(1f))
            LpTile(LpIcon.Level, "${lv.level}", "Level", Modifier.weight(1f))
        }
        Column(Modifier.fillMaxWidth().glassSurface().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Overall Progress", style = MaterialTheme.typography.titleSmall); LpProgress(pct / 100f); Text("Task completion: $pct%")
        }
        Column(Modifier.fillMaxWidth().glassSurface().padding(14.dp)) {
            Text("XP", style = MaterialTheme.typography.titleSmall)
            Row(Modifier.fillMaxWidth().height(170.dp).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(if (buckets.size > 12) 2.dp else 6.dp), verticalAlignment = Alignment.Bottom) {
                buckets.forEach { (label, v) ->
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        if (buckets.size <= 8) Text("$v", style = MaterialTheme.typography.labelSmall)
                        Box(Modifier.fillMaxWidth().height((120 * v / max.toFloat()).dp.coerceAtLeast(2.dp)).background(MaterialTheme.colorScheme.primary, RoundedCornerShape(g.progressRadius.coerceAtMost(8).dp)))
                        if (buckets.size <= 16) Text(label, style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        // Study / English / Programming / Exercise, from real XP transactions
        Column(Modifier.fillMaxWidth().glassSurface().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Areas", style = MaterialTheme.typography.titleSmall)
            val roots = listOf("Study" to LpIcon.Study, "English" to LpIcon.English, "Programming" to LpIcon.Code, "Exercise" to LpIcon.Exercise)
            val tot = roots.map { (r, _) -> cats.filter { it.category == r || it.category.startsWith("$r/") }.sumOf { it.total } }
            val mx = (tot.maxOrNull() ?: 0).coerceAtLeast(1)
            roots.forEachIndexed { i, (r, ic) -> Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                LIcon(ic, size = 20.dp, tint = MaterialTheme.colorScheme.primary); Text(r, Modifier.width(96.dp))
                LinearProgressIndicator(progress = { tot[i] / mx.toFloat() }, Modifier.weight(1f).height(8.dp)); Text("${tot[i]}") } }
        }
        if (goals.isNotEmpty()) { SectionTitle("Goal Progress", LpIcon.Goals); goals.take(5).forEach { GoalMini(db, it) } }
    }
}

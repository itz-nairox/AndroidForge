package com.lifeplanner.domain

import java.time.LocalDate

data class RpgStats(val categoryXp: Map<String, Int>, val activeDays: List<String>, val earnedTotal: Int,
                    val actions: Int, val todayXp: Int, val weekXp: Int, val goals: Int,
                    val hardGoalWeek: Int = 0, val studyWeek: Int = 0)
data class SkillLevel(val group: String, val skill: String, val level: LevelState)
data class SkillNode(val group: String, val level: LevelState, val subs: List<Pair<String, Int>>)
data class Achievement(val id: String, val title: String, val unlocked: Boolean)
data class Quest(val title: String, val kind: String, val progress: Int, val target: Int, val rewardXp: Int, val key: String = "")

/** Everything is derived from real XP transactions: no separate state to get out of sync. */
object RpgEngine {
    private val groups = listOf("Learning" to listOf("Study"), "Coding" to listOf("Programming"), "Language" to listOf("English"), "Health" to listOf("Exercise", "Sleep"))
    private fun rootXp(s: RpgStats, root: String) = s.categoryXp.filter { (k, _) -> k == root || k.startsWith("$root/") }.values.sum()

    /** Category "Programming/Python" feeds the Coding group and its Python sub-skill. */
    fun skillTree(s: RpgStats) = groups.map { (g, roots) ->
        val e = s.categoryXp.filter { (k, _) -> roots.any { k == it || k.startsWith("$it/") } }
        SkillNode(g, XpEngine.levelFor(e.values.sum()), e.map { (k, v) -> k.substringAfter("/", k) to v }.sortedByDescending { it.second })
    }

    fun streak(days: List<String>, today: LocalDate = LocalDate.now()): Int {
        val set = days.toSet(); var d = if (today.toString() in set) today else today.minusDays(1); var n = 0
        while (d.toString() in set) { n++; d = d.minusDays(1) }
        return n
    }

    fun achievements(s: RpgStats): List<Achievement> {
        val st = streak(s.activeDays)
        return listOf(
            Achievement("first", "First Step", s.actions >= 1),
            Achievement("s3", "Consistency (3 days)", st >= 3),
            Achievement("s7", "7 Day Streak", st >= 7),
            Achievement("s30", "30 Day Streak", st >= 30),
            Achievement("code", "Code Beginner", rootXp(s, "Programming") >= 100),
            Achievement("eng", "English Learner", rootXp(s, "English") >= 100),
            Achievement("goal", "Goal Setter", s.goals >= 1),
            Achievement("proj", "First Project", rootXp(s, "Programming") >= 30 && s.actions >= 5))
    }

    fun quests(s: RpgStats, today: LocalDate = LocalDate.now()): List<Quest> {
        val wk = today.get(java.time.temporal.IsoFields.WEEK_BASED_YEAR).toString() + "-" + today.get(java.time.temporal.IsoFields.WEEK_OF_WEEK_BASED_YEAR)
        return listOf(
            Quest("Earn 30 XP today", "Daily", s.todayXp, 30, 10, "d:$today:30"),
            Quest("Earn 100 XP today", "Daily", s.todayXp, 100, 20, "d:$today:100"),
            Quest("Complete 5 study sessions", "Weekly", s.studyWeek, 5, 50, "w:$wk:study5"),
            Quest("Earn 200 XP this week", "Weekly", s.weekXp, 200, 50, "w:$wk:200"),
            Quest("Finish 3 hard goal tasks", "Rare", s.hardGoalWeek, 3, 150, "w:$wk:hard3"))
    }
}

package com.lifeplanner.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.clickable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lifeplanner.core.parseFlexibleDate
import com.lifeplanner.data.*
import com.lifeplanner.domain.*
import kotlinx.coroutines.launch
import java.time.LocalDate

@Composable
fun GoalsScreen(db: AppDatabase) {
    val vm = rememberGoalVm(db)
    val goals by remember { db.goals().goals() }.collectAsState(emptyList())
    var newGoal by remember { mutableStateOf("") }
    var newDeadline by remember { mutableStateOf("") }
    val g = LocalGlass.current
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("My Goals", style = MaterialTheme.typography.titleLarge)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(newGoal, { newGoal = it }, Modifier.weight(1f), label = { Text("New goal") }, singleLine = true)
            LpButton(onClick = { if (newGoal.isNotBlank()) { vm.addGoal(newGoal.trim(), parseFlexibleDate(newDeadline)?.toString()); newGoal = ""; newDeadline = "" } }) { LIcon(LpIcon.Add, size = 18.dp) }
        }
        OutlinedTextField(newDeadline, { newDeadline = it }, label = { Text("Deadline (yyyy-MM-dd, optional)") }, singleLine = true)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(g.spacing.dp)) { items(goals, key = { it.id }) { GoalCard(db, it) } }
    }
}

/** Real-data analysis for one goal (tasks, sub-goals, consistency, deadline). Shared by Goals and Home. */
@Composable
fun rememberGoalAnalysis(db: AppDatabase, g: GoalEntity, subs: List<SubGoalEntity>): GoalAnalysis {
    val since = LocalDate.now().minusDays(29).toString()
    val days by remember(g.id, since) { db.goals().goalDays(g.id, since) }.collectAsState(emptyList())
    val tTotal by remember(g.id) { db.goals().taskCount(g.id) }.collectAsState(0)
    val tDone by remember(g.id) { db.goals().taskDone(g.id) }.collectAsState(0)
    fun desc(id: Long): List<SubGoalEntity> = subs.filter { it.parentId == id }.flatMap { listOf(it) + desc(it.id) }
    val areas = subs.filter { it.parentId == null }.map { r -> val all = listOf(r) + desc(r.id); AreaStat(r.title, 0, 0, all.size, all.count { it.done }) }
    val daysLeft = g.deadline?.let { runCatching { java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(it)).toInt() }.getOrNull() }
    val wk = LocalDate.now().minusDays(6).toString()
    return GoalAnalyzer.analyze(areas, days.size, 30, daysLeft, tTotal, tDone, days.count { it >= wk })
}

@Composable
fun GoalMini(db: AppDatabase, g: GoalEntity) {
    val subs by remember(g.id) { db.goals().subs(g.id) }.collectAsState(emptyList())
    val a = rememberGoalAnalysis(db, g, subs)
    Row(Modifier.fillMaxWidth().glassSurface().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        LIcon(LpIcon.Goals, tint = MaterialTheme.colorScheme.primary)
        Column(Modifier.weight(1f)) { Text(g.title, style = MaterialTheme.typography.titleSmall); LinearProgressIndicator(progress = { a.progress / 100f }, Modifier.fillMaxWidth().padding(top = 6.dp)) }
        Text("${a.progress}%")
    }
}

@Composable
private fun GoalCard(db: AppDatabase, g: GoalEntity) {
    val vm = rememberGoalVm(db)
    val subs by remember(g.id) { db.goals().subs(g.id) }.collectAsState(emptyList())
    var addingTo by remember { mutableStateOf<Long?>(-1L) }   // -1 none, 0 root, else parentId
    var text by remember { mutableStateOf("") }
    val a = rememberGoalAnalysis(db, g, subs)
    val daysLeft = g.deadline?.let { runCatching { java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), LocalDate.parse(it)).toInt() }.getOrNull() }
    Column(Modifier.fillMaxWidth().glassSurface().padding(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            LIcon(LpIcon.Goals, tint = MaterialTheme.colorScheme.primary); Spacer(Modifier.width(8.dp))
            Text(g.title, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
            Text("${a.progress}%"); IconButton({ addingTo = 0L }) { LIcon(LpIcon.Add, size = 20.dp) }
            IconButton({ vm.deleteGoal(g.id) }) { LIcon(LpIcon.Delete, size = 20.dp) }
        }
        LinearProgressIndicator(progress = { a.progress / 100f }, Modifier.fillMaxWidth())
        Text("Consistency: ${a.consistency}%"); Text("This week: ${a.weekly}%"); Text("SubGoals: ${a.subGoals}%")
        val mins by remember(g.id) { db.goals().goalMinutes(g.id) }.collectAsState(0)
        if (mins > 0) Text("Time spent: ${mins / 60}h ${mins % 60}m")
        if (daysLeft != null) Text("Days left: $daysLeft")
        a.onTrack?.let { Text(if (it) "On track" else "Behind schedule") }
        a.strongArea?.let { Text("Strong area: $it") }
        a.weakArea?.let { if (it != a.strongArea) Text("Weak area: $it") }
        TextButton({ vm.addSession(g) }) { Text("Add today's task") }
        Tree(vm, subs, null, 0) { addingTo = it }
        if (addingTo != -1L) Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(text, { text = it }, Modifier.weight(1f), label = { Text("Sub-goal") }, singleLine = true)
            LpButton(onClick = { if (text.isNotBlank()) {
                vm.addSub(g.id, addingTo.takeIf { it != 0L }, text.trim())
                text = ""; addingTo = -1L } }) { Text("Save") }
        }
    }
}

@Composable
private fun Tree(vm: GoalViewModel, all: List<SubGoalEntity>, parent: Long?, depth: Int, onAdd: (Long) -> Unit) {
    all.filter { it.parentId == parent }.forEach { s ->
        var open by remember(s.id) { mutableStateOf(false) }
        var notes by remember(s.id) { mutableStateOf(s.notes) }
        var dl by remember(s.id) { mutableStateOf(s.deadline ?: "") }
        Row(Modifier.padding(start = (depth * 20).dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(s.done, { vm.updateSub(s.copy(done = !s.done)) })
            Text(s.title, Modifier.weight(1f).clickable { open = !open })
            IconButton({ onAdd(s.id) }) { LIcon(LpIcon.Add, size = 18.dp) }
            IconButton({ vm.deleteSubTree(all, s.id) }) { LIcon(LpIcon.Delete, size = 18.dp) }
        }
        if (open) Column(Modifier.padding(start = (depth * 20 + 40).dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            OutlinedTextField(dl, { dl = it }, label = { Text("Deadline (yyyy-MM-dd, optional)") }, singleLine = true)
            OutlinedTextField(notes, { notes = it }, label = { Text("Notes") })
            TextButton({ vm.updateSub(s.copy(notes = notes, deadline = parseFlexibleDate(dl)?.toString())); open = false }) { Text("Save") }
        }
        Tree(vm, all, s.id, depth + 1, onAdd)
    }
}

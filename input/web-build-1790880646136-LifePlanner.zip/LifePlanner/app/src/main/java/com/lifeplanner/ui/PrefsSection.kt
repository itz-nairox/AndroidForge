package com.lifeplanner.ui

import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.lifeplanner.core.Reminders
import com.lifeplanner.core.SecureStore

@Composable
fun PrefsSection(s: SecureStore) {
    val ctx = LocalContext.current
    var hap by remember { mutableStateOf(s.haptics) }; var snd by remember { mutableStateOf(s.sounds) }
    var on by remember { mutableStateOf(s.notifOn) }; var hour by remember { mutableIntStateOf(s.notifHour) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    @Composable fun T(l: String, v: Boolean, f: (Boolean) -> Unit) =
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) { Text(l, Modifier.weight(1f)); Switch(v, f) }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        SectionTitle("Feedback & Notifications", LpIcon.Settings)
        T("Haptics", hap) { hap = it; s.haptics = it }
        T("Sounds", snd) { snd = it; s.sounds = it }
        val ctl = LocalThemeCtl.current
        Text("Language", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("fa" to "فارسی", "en" to "English", "SYSTEM" to "System").forEach { (k, l) -> FilterChip(ctl.lang == k, { ctl.setLang(k) }, label = { Text(l) }) }
        }
        var al by remember { mutableIntStateOf(s.autoLockMin) }
        Text("Auto Lock", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0 to "Immediately", 1 to "1 Minute", 5 to "5 Minutes", 15 to "15 Minutes").forEach { (m, l) -> FilterChip(al == m, { al = m; s.autoLockMin = m }, label = { Text(l) }) }
        }
        T("Daily reminder", on) { v -> on = v; s.notifOn = v
            if (v) { if (Build.VERSION.SDK_INT >= 33) perm.launch(android.Manifest.permission.POST_NOTIFICATIONS); Reminders.schedule(ctx, hour) } else Reminders.cancel(ctx) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(8, 12, 18, 21).forEach { h -> FilterChip(hour == h, { hour = h; s.notifHour = h; if (on) Reminders.schedule(ctx, h) }, label = { Text("%02d:00".format(h)) }) }
        }
    }
}

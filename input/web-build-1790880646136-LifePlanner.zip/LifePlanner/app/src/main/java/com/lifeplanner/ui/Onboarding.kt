package com.lifeplanner.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lifeplanner.core.SecureStore
import java.time.LocalDate

@Composable
fun Onboarding(s: SecureStore, onDone: () -> Unit) {
    var name by remember { mutableStateOf("") }; var birth by remember { mutableStateOf("") }
    val parsed = com.lifeplanner.core.parseFlexibleDate(birth)
    val ok = name.isNotBlank() && parsed != null && parsed.isBefore(LocalDate.now())
    Column(Modifier.fillMaxSize().safeDrawingPadding().padding(32.dp), verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically), horizontalAlignment = Alignment.CenterHorizontally) {
        LpLogo(88.dp); Text("ONE LIFE", style = MaterialTheme.typography.headlineMedium); Text("Plan - Focus - Level Up")
        Text("Plan it. Build it. Live it.", style = MaterialTheme.typography.labelMedium)
        OutlinedTextField(name, { name = it }, label = { Text("Your name") }, singleLine = true)
        OutlinedTextField(birth, { birth = it }, label = { Text("Birth date (yyyy-MM-dd)") }, singleLine = true, isError = birth.isNotEmpty() && !ok)
        LpButton(onClick = { s.name = name.trim(); s.birth = parsed.toString(); onDone() }, enabled = ok) { Text("Start") }
    }
}

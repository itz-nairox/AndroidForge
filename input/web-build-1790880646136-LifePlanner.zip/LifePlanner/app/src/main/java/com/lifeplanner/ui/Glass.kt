package com.lifeplanner.ui

import android.content.Context
import android.hardware.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.draw.blur
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.lifeplanner.theme.ThemeConfig

val LocalGlass = staticCompositionLocalOf { ThemeConfig("Default") }
val LocalParallax = staticCompositionLocalOf<State<Offset>> { mutableStateOf(Offset.Zero) }

/** Subtle parallax (max ~8dp = about 1.3mm). Auto-disabled when the device has no accelerometer. */
@Composable
fun rememberParallax(enabled: Boolean): State<Offset> {
    val ctx = LocalContext.current
    val st = remember { mutableStateOf(Offset.Zero) }
    DisposableEffect(enabled) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val s = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (!enabled || s == null) { st.value = Offset.Zero; return@DisposableEffect onDispose {} }
        var fx = 0f; var fy = 0f; var bx = 0f; var by = 0f; var init = false
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                if (!init) { bx = e.values[0]; by = e.values[1]; fx = bx; fy = by; init = true }
                fx += (e.values[0] - fx) * 0.06f; fy += (e.values[1] - fy) * 0.06f   // smooth
                bx += (e.values[0] - bx) * 0.004f; by += (e.values[1] - by) * 0.004f // slow baseline
                val max = 8f
                st.value = Offset((-(fx - bx) / 9.8f * max * 4).coerceIn(-max, max), ((fy - by) / 9.8f * max * 4).coerceIn(-max, max))
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        sm.registerListener(l, s, SensorManager.SENSOR_DELAY_UI)
        onDispose { sm.unregisterListener(l) }
    }
    return st
}

/** Glass look: translucent fill, soft shadow/glow, edge reflection, parallax. (No real backdrop blur: Compose lacks one.) */
@Composable
fun Modifier.parallax(): Modifier {
    val g = LocalGlass.current; val par = LocalParallax.current
    return if (g.glass && g.motion) this.graphicsLayer { translationX = par.value.x * density; translationY = par.value.y * density } else this
}

@Composable
fun Modifier.glassSurface(): Modifier {
    val g = LocalGlass.current; val dark = LocalIsDark.current
    val tint = if (dark) Color.White else Color(g.accent)
    if (!g.glass) return this.clip(RoundedCornerShape(g.cardRadius.dp)).background(MaterialTheme.colorScheme.surfaceVariant)
    val shape = RoundedCornerShape(g.cardRadius.dp)
    val i = g.glassIntensity / 100f
    val a = g.transparency / 100f * 0.25f + 0.05f
    return this
        .parallax()
        .then(if (g.shadow) Modifier.shadow((12 * i).dp, shape, spotColor = if (g.glow) Color(g.accent) else Color.Black) else Modifier)
        .clip(shape)
        .background(Brush.verticalGradient(listOf(tint.copy(alpha = a + 0.10f * i), tint.copy(alpha = a))))
        .then(if (g.reflection) Modifier.border(1.dp, Brush.linearGradient(listOf(Color.White.copy(0.6f * i), Color.Transparent, Color.White.copy(0.2f * i))), shape) else Modifier)
}

/** Page background: gradient plus soft blurred accent orbs. The Blur setting drives orb softness (Modifier.blur is a no-op below Android 12). */
@Composable
fun PageBackground(modifier: Modifier = Modifier.fillMaxSize(), content: @Composable () -> Unit) {
    val g = LocalGlass.current; val dark = LocalIsDark.current
    val page = g.pageColor(dark); val acc = Color(g.accent)
    androidx.compose.foundation.layout.Box(modifier.background(
        if (g.glass) Brush.linearGradient(listOf(acc.copy(alpha = if (dark) 0.35f else 0.18f), page)) else SolidColor(page))) {
        if (g.glass && g.decor && g.blur > 0) androidx.compose.foundation.Canvas(Modifier.matchParentSize().blur((g.blur * 0.5f).dp)) {
            drawCircle(acc.copy(alpha = 0.30f), size.minDimension * 0.35f, Offset(size.width * 0.85f, size.height * 0.15f))
            drawCircle(acc.copy(alpha = 0.22f), size.minDimension * 0.30f, Offset(size.width * 0.10f, size.height * 0.70f))
        }
        content()
    }
}

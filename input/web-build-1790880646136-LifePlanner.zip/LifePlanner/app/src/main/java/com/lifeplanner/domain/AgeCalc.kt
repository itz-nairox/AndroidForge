package com.lifeplanner.domain

import java.time.LocalDate
import java.time.Period
import java.time.temporal.ChronoUnit

object AgeCalc {
    fun age(b: LocalDate, t: LocalDate) = Period.between(b, t).years
    fun daysLived(b: LocalDate, t: LocalDate) = ChronoUnit.DAYS.between(b, t)
    fun daysUntilNext(b: LocalDate, t: LocalDate): Long {
        var n = b.withYear(t.year); if (n.isBefore(t)) n = b.withYear(t.year + 1)
        return ChronoUnit.DAYS.between(t, n)
    }
    fun isBirthday(b: LocalDate, t: LocalDate) = daysUntilNext(b, t) == 0L
}

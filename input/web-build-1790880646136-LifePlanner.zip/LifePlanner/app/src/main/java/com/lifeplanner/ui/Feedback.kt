package com.lifeplanner.ui

import androidx.compose.runtime.*
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import com.lifeplanner.App
import com.lifeplanner.theme.ThemeConfig

class ThemeCtl(val current: ThemeConfig, val set: (ThemeConfig) -> Unit, val lang: String = "SYSTEM", val setLang: (String) -> Unit = {})
val LocalThemeCtl = staticCompositionLocalOf { ThemeCtl(ThemeConfig("Default")) {} }

/** Respects the Haptics toggle in Settings. */
@Composable
fun rememberHaptic(): () -> Unit {
    val h = LocalHapticFeedback.current
    val s = (LocalContext.current.applicationContext as App).secure
    val v = androidx.compose.ui.platform.LocalView.current
    return { if (s.haptics) h.performHapticFeedback(HapticFeedbackType.LongPress); if (s.sounds) v.playSoundEffect(android.view.SoundEffectConstants.CLICK) }
}

package com.lifeplanner

import com.lifeplanner.core.JalaliDate
import com.lifeplanner.core.PersianCalendar
import com.lifeplanner.domain.*
import org.junit.Assert.assertEquals
import org.junit.Test
import java.time.LocalDate

class CoreTest {
    @Test fun levelThresholdsMatchSpec() {
        val c = LevelConfig()
        assertEquals(listOf(100, 250, 450, 700, 1000), (2..6).map { c.xpToReach(it) })
        assertEquals(1, XpEngine.levelFor(99).level); assertEquals(2, XpEngine.levelFor(100).level); assertEquals(6, XpEngine.levelFor(1000).level)
    }
    @Test fun xpPaysOncePerDateAndRespectsDailyCap() {
        assertEquals(0, XpEngine.grant(Difficulty.HARD, null, alreadyGrantedForDate = true, earnedToday = 0))
        assertEquals(30, XpEngine.grant(Difficulty.HARD, null, false, 0))
        assertEquals(10, XpEngine.grant(Difficulty.HARD, null, false, 390))   // cap 400
        assertEquals(0, XpEngine.grant(Difficulty.EASY, null, false, 400))
    }
    @Test fun jalaliConversion() {
        assertEquals(JalaliDate(1405, 7, 8), PersianCalendar.fromGregorian(LocalDate.of(2026, 9, 30)))
        assertEquals(JalaliDate(1405, 1, 1), PersianCalendar.fromGregorian(LocalDate.of(2026, 3, 21)))
    }
    @Test fun ageAndBirthday() {
        val b = LocalDate.of(2009, 10, 15); val t = LocalDate.of(2026, 9, 29)
        assertEquals(16, AgeCalc.age(b, t)); assertEquals(16L, AgeCalc.daysUntilNext(b, t))
    }
    @Test fun skillSubcategoriesFeedGroup() {
        val s = RpgStats(mapOf("Programming/Python" to 60, "Programming" to 40), emptyList(), 100, 2, 0, 0, 0)
        assertEquals(100, RpgEngine.skillTree(s).first { it.group == "Coding" }.subs.sumOf { it.second })
    }
    @Test fun jalaliRoundTrip() {
        var d = LocalDate.of(2020, 1, 1)
        repeat(3000) { val j = PersianCalendar.fromGregorian(d); assertEquals(d, PersianCalendar.toGregorian(j.year, j.month, j.day)); d = d.plusDays(1) }
        assertEquals(31, PersianCalendar.monthLength(1405, 1)); assertEquals(30, PersianCalendar.monthLength(1405, 7))
    }
    @Test fun themeJsonRoundTripAndLegacy() {
        val t = com.lifeplanner.theme.ThemeConfig("X", accent = 0xFF112233, cardRadius = 12, progressStyle = "BAR", fontScale = 1.2f)
        assertEquals(t.copy(version = 2), com.lifeplanner.theme.ThemeConfig.fromJson(t.toJson()))
        val legacy = """{"format":"lptheme","version":1,"name":"Old","dark":false}"""
        assertEquals("LIGHT", com.lifeplanner.theme.ThemeConfig.fromJson(legacy).mode)
    }
    @Test fun analyzerUsesOnlyWhatExists() {
        assertEquals(50, GoalAnalyzer.analyze(emptyList(), 3, 30, null, 10, 5).progress)          // tasks only
        assertEquals(50, GoalAnalyzer.analyze(listOf(AreaStat("A", 0, 0, 2, 1)), 3, 30).progress)   // sub-goals only
        assertEquals(0, GoalAnalyzer.analyze(emptyList(), 0, 30).progress)
    }
    @Test fun flexibleDates() {
        assertEquals(LocalDate.of(2026, 9, 30), com.lifeplanner.core.parseFlexibleDate("1405/07/08"))
        assertEquals(LocalDate.of(2026, 9, 30), com.lifeplanner.core.parseFlexibleDate("\u06F1\u06F4\u06F0\u06F5-\u06F0\u06F7-\u06F0\u06F8"))
        assertEquals(LocalDate.of(2009, 10, 15), com.lifeplanner.core.parseFlexibleDate("2009-10-15"))
        assertEquals(null, com.lifeplanner.core.parseFlexibleDate("1405/13/40"))
    }
    @Test fun rareAndWeeklyQuestsAreReal() {
        val s = RpgStats(emptyMap(), emptyList(), 0, 0, 0, 0, 0, hardGoalWeek = 3, studyWeek = 5)
        val q = RpgEngine.quests(s)
        assertEquals(true, q.first { it.kind == "Rare" }.let { it.progress >= it.target })
        assertEquals(true, q.first { it.title.startsWith("Complete 5 study") }.let { it.progress >= it.target })
    }
}

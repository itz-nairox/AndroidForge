# Nairox Code (Android)
Native Kotlin + Jetpack Compose agent app. Agent loop -> permission check -> sandboxed tool -> result -> AI.
- Provider: `PuterProvider` (AIProvider interface) calling Puter's AI driver API with a DeepSeek model.
- Tools: fs.list/read/search/write/delete/rename, confined to the app-private `workspace/` (path-traversal blocked).
- Permission modes: SAFE, ASK, AUTO, STRICT. Writes show an approval dialog with diff stats + proposed content.
- Attach files in chat with `@path`.
## Build
Open this folder in Android Studio (Koala+, JDK 17) -> Sync -> Run. Or `gradle wrapper && ./gradlew assembleDebug`.
APK: app/build/outputs/apk/debug/. Then Settings: paste your Puter auth token, model `deepseek-chat`.
## Notes
Token is stored in app-private SharedPreferences (not in source). Verify the Puter endpoint/model id against current Puter docs.
Not included: shell/terminal, git, Monaco, plugins (Android sandbox has no shell/project dir).

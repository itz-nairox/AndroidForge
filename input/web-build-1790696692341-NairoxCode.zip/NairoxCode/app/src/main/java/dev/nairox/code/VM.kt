package dev.nairox.code
import android.app.Application
import android.content.Context
import androidx.compose.runtime.*
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*

data class Msg(val role: String, val text: String)
data class Approval(val title: String, val detail: String, val done: CompletableDeferred<Boolean>)

class VM(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("nairox", Context.MODE_PRIVATE)
    val sandbox = Sandbox(java.io.File(app.filesDir, "workspace"))
    private val provider: AIProvider = PuterProvider()
    val msgs = mutableStateListOf<Msg>()
    val files = mutableStateListOf<String>()
    var busy by mutableStateOf(false)
    var pending by mutableStateOf<Approval?>(null)
    var error by mutableStateOf<String?>(null)
    var cfg by mutableStateOf(load())
    private var job: Job? = null

    private fun load() = Cfg(prefs.getString("token", "")!!, prefs.getString("model", "deepseek-chat")!!,
        prefs.getFloat("temp", 0.2f).toDouble(), prefs.getInt("max", 4096), prefs.getString("sys", "")!!,
        prefs.getInt("timeout", 60), prefs.getInt("iter", 8), prefs.getString("mode", "ASK")!!)
    fun save(c: Cfg) { cfg = c; prefs.edit().putString("token", c.token).putString("model", c.model)
        .putFloat("temp", c.temp.toFloat()).putInt("max", c.maxTokens).putString("sys", c.system)
        .putInt("timeout", c.timeoutS).putInt("iter", c.maxIter).putString("mode", c.mode).apply() }
    fun refresh() { files.clear(); files.addAll(sandbox.tree()) }
    init { refresh() }

    fun cancel() { provider.cancel(); job?.cancel(); busy = false }
    fun newChat() { cancel(); msgs.clear() }

    private suspend fun approve(t: String, d: String): Boolean {
        val a = Approval(t, d, CompletableDeferred()); pending = a
        return a.done.await().also { pending = null }
    }

    fun send(text: String) {
        if (busy || text.isBlank()) return
        // @file attachments
        val att = Regex("@([\\w./-]+)").findAll(text).mapNotNull { m ->
            runCatching { "File ${m.groupValues[1]}:\n" + sandbox.read(m.groupValues[1]).take(8000) }.getOrNull() }.joinToString("\n\n")
        msgs += Msg("user", text); busy = true; error = null
        val hist = msgs.filter { it.role == "user" || it.role == "assistant" }.map { it.role to it.text }.toMutableList()
        if (att.isNotEmpty()) hist[hist.lastIndex] = "user" to (text + "\n\n" + att)
        job = viewModelScope.launch(Dispatchers.IO) {
            try {
                val c = cfg.copy(system = TOOL_PROMPT + "\n" + cfg.system)
                repeat(c.maxIter) { i ->
                    val reply = provider.chat(hist, c)
                    val call = parseTool(reply)
                    if (call == null) { msgs += Msg("assistant", reply); return@launch }
                    msgs += Msg("tool", activity(call))
                    hist += "assistant" to reply
                    var result: String
                    if (isWrite(call.name) && c.mode != "AUTO") {
                        val p = call.args.optString("path", call.args.optString("from"))
                        val detail = if (call.name == "fs.write") {
                            val old = runCatching { sandbox.read(p) }.getOrDefault("")
                            val (a, r) = diffStats(old, call.args.optString("content"))
                            "+$a / -$r lines\n\n--- proposed ---\n" + call.args.optString("content").take(2500)
                        } else call.args.toString()
                        result = if (approve("AI wants to run ${call.name} on $p", detail)) runTool(sandbox, call) else "DENIED by user"
                    } else if (isWrite(call.name) && c.mode == "STRICT") result = "DENIED"
                    else result = runTool(sandbox, call)
                    msgs += Msg("result", result.take(400))
                    hist += "user" to "TOOL_RESULT:\n$result"
                    withContext(Dispatchers.Main) { refresh() }
                    if (i == c.maxIter - 1) msgs += Msg("assistant", "Stopped: reached max tool iterations (${c.maxIter}).")
                }
            } catch (e: CancellationException) { throw e
            } catch (e: Exception) { error = e.message ?: "Unknown error" }
            finally { busy = false; withContext(NonCancellable + Dispatchers.Main) { refresh() } }
        }
    }
}

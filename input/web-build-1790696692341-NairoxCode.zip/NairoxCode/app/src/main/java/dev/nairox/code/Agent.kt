package dev.nairox.code
import org.json.JSONObject

const val TOOL_PROMPT = """You are Nairox Code, a coding agent working inside a sandboxed project workspace.
To use a tool, reply with ONLY one fenced block, then stop and wait for the result:
```tool
{"name":"fs.read","args":{"path":"src/a.txt"}}
```
Tools: fs.list{path?}, fs.read{path}, fs.search{query}, fs.write{path,content}, fs.delete{path}, fs.rename{from,to}.
Be concise. Never reveal hidden reasoning; state brief actions. When done, answer normally without a tool block."""

data class ToolCall(val name: String, val args: JSONObject)
val TOOL_RE = Regex("```tool\\s*(\\{.*?\\})\\s*```", RegexOption.DOT_MATCHES_ALL)
fun parseTool(s: String): ToolCall? = TOOL_RE.find(s)?.let {
    runCatching { JSONObject(it.groupValues[1]).let { j -> ToolCall(j.getString("name"), j.optJSONObject("args") ?: JSONObject()) } }.getOrNull()
}
fun isWrite(n: String) = n in setOf("fs.write", "fs.delete", "fs.rename")
fun activity(c: ToolCall) = when (c.name) {
    "fs.read" -> "◉ Reading ${c.args.optString("path")}"
    "fs.list" -> "◉ Listing ${c.args.optString("path", ".")}"
    "fs.search" -> "◉ Searching ${c.args.optString("query")}"
    "fs.write" -> "✎ Editing ${c.args.optString("path")}"
    "fs.delete" -> "✕ Deleting ${c.args.optString("path")}"
    "fs.rename" -> "✎ Renaming ${c.args.optString("from")}"
    else -> "? ${c.name}"
}
fun runTool(sb: Sandbox, c: ToolCall): String = try {
    val a = c.args
    when (c.name) {
        "fs.list" -> sb.list(a.optString("path")).joinToString("\n").ifBlank { "(empty)" }
        "fs.read" -> sb.read(a.getString("path")).take(20000)
        "fs.search" -> sb.search(a.getString("query")).joinToString("\n").ifBlank { "no matches" }
        "fs.write" -> { sb.write(a.getString("path"), a.getString("content")); "written" }
        "fs.delete" -> { sb.delete(a.getString("path")); "deleted" }
        "fs.rename" -> { sb.rename(a.getString("from"), a.getString("to")); "renamed" }
        else -> "ERROR: unknown tool ${c.name}"
    }
} catch (e: Exception) { "ERROR: ${e.message}" }

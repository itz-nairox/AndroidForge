package dev.nairox.code
import org.json.*
import java.net.HttpURLConnection
import java.net.URL

data class Cfg(val token: String, val model: String, val temp: Double, val maxTokens: Int,
               val system: String, val timeoutS: Int, val maxIter: Int, val mode: String)

interface AIProvider { fun chat(history: List<Pair<String, String>>, cfg: Cfg): String; fun cancel() }

/** Puter AI driver over HTTPS. Token is entered in Settings, never hardcoded. */
class PuterProvider : AIProvider {
    @Volatile private var conn: HttpURLConnection? = null
    override fun cancel() { conn?.disconnect() }
    override fun chat(history: List<Pair<String, String>>, cfg: Cfg): String {
        if (cfg.token.isBlank()) error("No Puter token. Add it in Settings.")
        val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", cfg.system))
        history.forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        val body = JSONObject().put("interface", "puter-chat-completion").put("driver", "deepseek")
            .put("method", "complete").put("args", JSONObject().put("messages", msgs)
                .put("model", cfg.model).put("temperature", cfg.temp).put("max_tokens", cfg.maxTokens))
        val c = (URL("https://api.puter.com/drivers/call").openConnection() as HttpURLConnection).also { conn = it }
        try {
            c.requestMethod = "POST"; c.doOutput = true
            c.connectTimeout = cfg.timeoutS * 1000; c.readTimeout = cfg.timeoutS * 1000
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Authorization", "Bearer ${cfg.token}")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val txt = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
            if (code !in 200..299) error("API error $code: ${txt.take(300)}")
            val j = JSONObject(txt)
            if (!j.optBoolean("success", true)) error("Puter: ${j.optJSONObject("error")?.optString("message") ?: txt.take(200)}")
            val r = j.opt("result")
            val m = (r as? JSONObject)?.optJSONObject("message")
            val content = m?.opt("content")
            return when (content) {
                is JSONArray -> (0 until content.length()).joinToString("") { content.getJSONObject(it).optString("text") }
                null -> (r as? JSONObject)?.optString("text") ?: error("Unexpected response")
                else -> content.toString()
            }
        } finally { c.disconnect() }
    }
}

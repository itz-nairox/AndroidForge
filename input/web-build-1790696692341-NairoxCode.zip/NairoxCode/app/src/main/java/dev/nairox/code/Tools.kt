package dev.nairox.code
import java.io.File

class Sandbox(val root: File) {
    init { root.mkdirs() }
    fun resolve(rel: String): File {
        val f = File(root, rel.trimStart('/')).canonicalFile
        require(f.path == root.canonicalPath || f.path.startsWith(root.canonicalPath + File.separator)) { "Path escapes workspace: $rel" }
        return f
    }
    fun list(rel: String = ""): List<String> = resolve(rel).listFiles()?.sortedWith(compareBy({ !it.isDirectory }, { it.name }))
        ?.map { (if (it.isDirectory) "[d] " else "    ") + it.relativeTo(root).path } ?: emptyList()
    fun tree(): List<String> = root.walkTopDown().filter { it.isFile }.map { it.relativeTo(root).path }.sorted().toList()
    fun read(rel: String) = resolve(rel).also { require(it.isFile) { "Not a file: $rel" } }.readText()
    fun write(rel: String, text: String) { val f = resolve(rel); f.parentFile?.mkdirs(); f.writeText(text) }
    fun delete(rel: String) { require(resolve(rel).deleteRecursively()) { "Delete failed" } }
    fun rename(a: String, b: String) { val t = resolve(b); t.parentFile?.mkdirs(); require(resolve(a).renameTo(t)) { "Rename failed" } }
    fun search(q: String): List<String> = root.walkTopDown().filter { it.isFile && it.length() < 500_000 }.flatMap { f ->
        val rel = f.relativeTo(root).path
        val hits = mutableListOf<String>()
        if (rel.contains(q, true)) hits += rel
        runCatching { f.readLines().forEachIndexed { i, l -> if (l.contains(q, true)) hits += "$rel:${i + 1}: ${l.trim().take(120)}" } }
        hits.asSequence()
    }.take(50).toList()
}

/** Naive line diff summary: (added, removed). */
fun diffStats(a: String, b: String): Pair<Int, Int> {
    val x = a.lines().groupingBy { it }.eachCount().toMutableMap(); var add = 0
    for (l in b.lines()) { val n = x[l] ?: 0; if (n > 0) x[l] = n - 1 else add++ }
    return add to x.values.sum()
}

package dev.nairox.code
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel

val Accent = Color(0xFFFFA726); val Cyan = Color(0xFF4DD0E1)
val Glass = Color(0x0AFFFFFF); val Edge = Color(0x14FFFFFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) { super.onCreate(s); setContent { App() } }
}

@Composable fun App(vm: VM = viewModel()) {
    MaterialTheme(darkColorScheme(primary = Accent, background = Color(0xFF070707), surface = Color(0xFF101010))) {
        var tab by remember { mutableIntStateOf(0) }
        Surface(Modifier.fillMaxSize(), color = Color(0xFF070707)) {
            Column(Modifier.statusBarsPadding().navigationBarsPadding().imePadding()) {
                TabRow(tab, containerColor = Color.Transparent, contentColor = Accent) {
                    listOf("Agent", "Files", "Settings").forEachIndexed { i, t -> Tab(tab == i, { tab = i }, text = { Text(t) }) }
                }
                Box(Modifier.weight(1f)) { when (tab) { 0 -> Chat(vm); 1 -> Files(vm); else -> SettingsUI(vm) } }
                Text("Puter · ${vm.cfg.model} · ${vm.cfg.mode}", Modifier.fillMaxWidth().background(Glass).padding(6.dp),
                    fontSize = 11.sp, color = Color.Gray)
            }
        }
        vm.pending?.let { a ->
            AlertDialog(onDismissRequest = {}, title = { Text(a.title, fontSize = 15.sp) },
                text = { Text(a.detail, Modifier.verticalScroll(rememberScrollState()), fontFamily = FontFamily.Monospace, fontSize = 11.sp) },
                confirmButton = { TextButton({ a.done.complete(true) }) { Text("Accept") } },
                dismissButton = { TextButton({ a.done.complete(false) }) { Text("Reject") } })
        }
    }
}

@Composable fun Chat(vm: VM) {
    var input by remember { mutableStateOf("") }
    val st = rememberLazyListState()
    LaunchedEffect(vm.msgs.size) { if (vm.msgs.isNotEmpty()) st.animateScrollToItem(vm.msgs.lastIndex) }
    Column {
        LazyColumn(Modifier.weight(1f).padding(8.dp), st, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            if (vm.msgs.isEmpty()) item { Text("Ask the agent to work on your workspace. Use @path to attach a file.", color = Color.Gray) }
            items(vm.msgs) { m ->
                val (bg, fg, mono) = when (m.role) {
                    "user" -> Triple(Accent.copy(0.15f), Color.White, false)
                    "tool" -> Triple(Glass, Cyan, true)
                    "result" -> Triple(Glass, Color.Gray, true)
                    else -> Triple(Color.Transparent, Color(0xFFEEEEEE), false)
                }
                Text(m.text, Modifier.fillMaxWidth().background(bg, RoundedCornerShape(4.dp)).border(0.5.dp, if (bg == Color.Transparent) bg else Edge, RoundedCornerShape(4.dp)).padding(8.dp),
                    color = fg, fontSize = if (mono) 12.sp else 14.sp, fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default)
            }
            if (vm.busy) item { Text("▌ working…", color = Accent) }
            vm.error?.let { e -> item { Text("Error: $e", color = Color(0xFFFF6B6B)) } }
        }
        Row(Modifier.padding(8.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            OutlinedTextField(input, { input = it }, Modifier.weight(1f), maxLines = 4, placeholder = { Text("Message the agent") })
            Spacer(Modifier.width(6.dp))
            if (vm.busy) Button({ vm.cancel() }) { Text("Stop") } else Button({ vm.send(input); input = "" }) { Text("Send") }
        }
        TextButton({ vm.newChat() }, Modifier.padding(horizontal = 8.dp)) { Text("New chat", fontSize = 12.sp) }
    }
}

@Composable fun Files(vm: VM) {
    var open by remember { mutableStateOf<String?>(null) }
    var text by remember { mutableStateOf("") }
    var newName by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    fun guard(f: () -> Unit) { try { f(); err = null; vm.refresh() } catch (e: Exception) { err = e.message } }
    Column(Modifier.padding(8.dp)) {
        if (open == null) {
            Row { OutlinedTextField(newName, { newName = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text("new/file.txt") })
                Button({ guard { vm.sandbox.write(newName, ""); newName = "" } }, Modifier.padding(start = 6.dp)) { Text("Create") } }
            err?.let { Text(it, color = Color(0xFFFF6B6B)) }
            LazyColumn { items(vm.files) { f -> Row(Modifier.fillMaxWidth().clickable { open = f; text = vm.sandbox.read(f) }.padding(8.dp)) {
                Text(f, Modifier.weight(1f), fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                Text("✕", Modifier.clickable { guard { vm.sandbox.delete(f) } }.padding(horizontal = 8.dp), color = Color.Gray) } } }
            if (vm.files.isEmpty()) Text("Workspace is empty. Create a file or ask the agent.", color = Color.Gray)
        } else {
            Row { TextButton({ open = null }) { Text("← Back") }
                Button({ guard { vm.sandbox.write(open!!, text) } }) { Text("Save") } }
            err?.let { Text(it, color = Color(0xFFFF6B6B)) }
            OutlinedTextField(text, { text = it }, Modifier.fillMaxSize(), textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp))
        }
    }
}

@Composable fun SettingsUI(vm: VM) {
    var c by remember { mutableStateOf(vm.cfg) }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutlinedTextField(c.token, { c = c.copy(token = it) }, Modifier.fillMaxWidth(), label = { Text("Puter auth token") }, singleLine = true,
            visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
        OutlinedTextField(c.model, { c = c.copy(model = it) }, Modifier.fillMaxWidth(), label = { Text("Model (e.g. deepseek-chat)") }, singleLine = true)
        OutlinedTextField(c.temp.toString(), { c = c.copy(temp = it.toDoubleOrNull() ?: c.temp) }, Modifier.fillMaxWidth(), label = { Text("Temperature") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
        OutlinedTextField(c.maxTokens.toString(), { c = c.copy(maxTokens = it.toIntOrNull() ?: c.maxTokens) }, Modifier.fillMaxWidth(), label = { Text("Max tokens") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
        OutlinedTextField(c.maxIter.toString(), { c = c.copy(maxIter = it.toIntOrNull() ?: c.maxIter) }, Modifier.fillMaxWidth(), label = { Text("Max tool iterations") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
        OutlinedTextField(c.timeoutS.toString(), { c = c.copy(timeoutS = it.toIntOrNull() ?: c.timeoutS) }, Modifier.fillMaxWidth(), label = { Text("Timeout (s)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
        OutlinedTextField(c.system, { c = c.copy(system = it) }, Modifier.fillMaxWidth(), label = { Text("Extra system prompt") })
        Text("Permission mode", color = Color.Gray)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("SAFE", "ASK", "AUTO", "STRICT").forEach { m -> FilterChip(c.mode == m, { c = c.copy(mode = m) }, { Text(m) }) } }
        Text("SAFE/ASK/STRICT: writes need approval (STRICT also blocks if not AUTO). AUTO: writes run immediately.", fontSize = 11.sp, color = Color.Gray)
        Button({ vm.save(c) }) { Text("Save") }
    }
}

# Compose
-keep class androidx.compose.runtime.** { *; }

# Keep data classes used for schedule (no reflection-based serialization used, but keep names for clarity in stack traces)
-keepclassmembers class com.grade.ice.** {
    <fields>;
}

-dontwarn kotlinx.**

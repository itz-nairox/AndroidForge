package com.grade.ice

import org.junit.Assert.assertEquals
import org.junit.Test

class PersianDateTest {

    @Test
    fun `known conversion cases match reference jalaali-js output`() {
        val cases = listOf(
            Triple(2026, 10, 9) to PersianDate.Jalali(1405, 7, 17),
            Triple(1979, 3, 21) to PersianDate.Jalali(1358, 1, 1),
            Triple(2024, 3, 20) to PersianDate.Jalali(1403, 1, 1),
            Triple(2025, 3, 21) to PersianDate.Jalali(1404, 1, 1),
            Triple(2000, 1, 1) to PersianDate.Jalali(1378, 10, 11),
            Triple(2024, 2, 29) to PersianDate.Jalali(1402, 12, 10),
        )

        for ((input, expected) in cases) {
            val (gy, gm, gd) = input
            val result = PersianDate.gregorianToJalali(gy, gm, gd)
            assertEquals("Mismatch for $gy-$gm-$gd", expected, result)
        }
    }

    @Test
    fun `today 2026-10-09 jalali day parity is odd`() {
        // jd = 17 -> odd
        assertEquals(false, PersianDate.isEvenDay(2026, 10, 9))
    }

    @Test
    fun `toPersianDigits converts latin digits to persian digits`() {
        assertEquals("۱", PersianDate.toPersianDigits(1))
        assertEquals("۱۲", PersianDate.toPersianDigits(12))
        assertEquals("۰", PersianDate.toPersianDigits(0))
    }
}

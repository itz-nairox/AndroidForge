package com.grade.ice

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class ScheduleDataTest {

    @Test
    fun `fixed period resolves the same regardless of parity`() {
        val p = Period(time = "۷:۴۵", content = PeriodContent("زمین شناسی", "حسینی"))
        assertEquals(p.content, p.resolveOrNull(isEven = true))
        assertEquals(p.content, p.resolveOrNull(isEven = false))
    }

    @Test
    fun `period with both even and odd resolves to the matching one`() {
        val even = PeriodContent("کارآفرینی", "گنجی")
        val odd = PeriodContent("شیمی", "اداک")
        val p = Period(time = "۹:۳۰", even = even, odd = odd)
        assertEquals(even, p.resolveOrNull(isEven = true))
        assertEquals(odd, p.resolveOrNull(isEven = false))
    }

    @Test
    fun `period with only even is absent on odd days`() {
        val even = PeriodContent("حسابان", "فتحی")
        val p = Period(time = "۱۱:۱۰", even = even)
        assertEquals(even, p.resolveOrNull(isEven = true))
        assertNull(p.resolveOrNull(isEven = false))
    }

    @Test
    fun `period with only odd is absent on even days`() {
        val odd = PeriodContent("خارجه", "عسکری")
        val p = Period(time = "۱۱:۱۰", odd = odd)
        assertNull(p.resolveOrNull(isEven = true))
        assertEquals(odd, p.resolveOrNull(isEven = false))
    }

    @Test
    fun `yekshanbe has 4 periods on even days and 2 on odd days`() {
        val day = ScheduleData.schedule.first { it.day == "یکشنبه" }
        assertEquals(4, day.resolvedPeriods(isEven = true).size)
        assertEquals(2, day.resolvedPeriods(isEven = false).size)
    }

    @Test
    fun `doshanbe has 4 periods on even days and 3 on odd days`() {
        val day = ScheduleData.schedule.first { it.day == "دوشنبه" }
        assertEquals(4, day.resolvedPeriods(isEven = true).size)
        assertEquals(3, day.resolvedPeriods(isEven = false).size)
    }

    @Test
    fun `charshanbe has 3 periods on odd days and 2 on even days`() {
        val day = ScheduleData.schedule.first { it.day == "چهارشنبه" }
        assertEquals(3, day.resolvedPeriods(isEven = false).size)
        assertEquals(2, day.resolvedPeriods(isEven = true).size)
    }

    @Test
    fun `seshanbe always has 4 periods regardless of parity`() {
        val day = ScheduleData.schedule.first { it.day == "سه‌شنبه" }
        assertEquals(4, day.resolvedPeriods(isEven = true).size)
        assertEquals(4, day.resolvedPeriods(isEven = false).size)
    }
}

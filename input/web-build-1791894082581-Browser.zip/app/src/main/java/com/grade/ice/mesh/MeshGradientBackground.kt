package com.grade.ice.mesh

import android.graphics.Bitmap
import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asComposeRenderEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import com.grade.ice.theme.MeshPalettes
import kotlin.math.sin

/**
 * Faithful port of the HTML `renderMesh()`:
 * - 4 corner colors, two palettes cross-faded by a slow sine wave, phase-shifted per corner
 *   (independent, continuous drift).
 * - A tiny offscreen grid (10x14) bilinearly interpolated between the 4 corners (pixel mesh,
 *   not a CSS radial gradient), then upscaled with smoothing.
 * - A soft blur pass on top for extra smoothness (hardware RenderEffect on API 31+, otherwise
 *   skipped — the finer source grid and bilinear upscale already read as smooth without it).
 *
 * Runs on an infinite animation clock, matching the original's continuous rAF loop.
 */
private const val GRID_COLS = 10
private const val GRID_ROWS = 14
private const val PHASE_SPEED = 0.00025f // matches t * 0.00025 in the HTML (t in ms)

@Composable
fun MeshGradientBackground(modifier: Modifier = Modifier) {
    val isDark = isSystemInDarkTheme()

    val infiniteTransition = rememberInfiniteTransition(label = "mesh")
    // A very long duration keeps the sine phase continuously advancing without
    // ever audibly "looping" (phase wraps naturally via sin()).
    val timeMs by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 100_000_000f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 100_000_000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "meshTime",
    )

    val canUseBlur = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S // API 31+

    Canvas(
        modifier = modifier
            .let {
                if (canUseBlur) {
                    it.graphicsLayer {
                        renderEffect = RenderEffect
                            .createBlurEffect(40f, 40f, Shader.TileMode.CLAMP)
                            .asComposeRenderEffect()
                    }
                } else {
                    it
                }
            },
    ) {
        drawMeshFrame(timeMs = timeMs, isDark = isDark)
    }
}

private fun DrawScope.drawMeshFrame(timeMs: Float, isDark: Boolean) {
    val w = size.width
    val h = size.height
    if (w <= 0f || h <= 0f) return

    val paletteA = if (isDark) MeshPalettes.darkA else MeshPalettes.lightA
    val paletteB = if (isDark) MeshPalettes.darkB else MeshPalettes.lightB

    // Per-corner independent sine cross-fade between palette A and B.
    val corners = Array(4) { i ->
        val phase = timeMs * PHASE_SPEED + i * 1.9f
        val blend = (sin(phase) + 1f) / 2f
        lerpColor(paletteA[i], paletteB[i], blend)
    }

    // Build the small bilinear grid bitmap (cols x rows), matching the HTML's
    // offscreen canvas + bilinear interpolation of the 4 corners.
    val bitmap = Bitmap.createBitmap(GRID_COLS, GRID_ROWS, Bitmap.Config.ARGB_8888)
    val pixels = IntArray(GRID_COLS * GRID_ROWS)

    for (j in 0 until GRID_ROWS) {
        val v = j / (GRID_ROWS - 1f)
        for (i in 0 until GRID_COLS) {
            val u = i / (GRID_COLS - 1f)

            val top = lerpColor(corners[0], corners[1], u)
            val bottom = lerpColor(corners[2], corners[3], u)
            val c = lerpColor(top, bottom, v)

            pixels[j * GRID_COLS + i] = c.toArgb()
        }
    }
    bitmap.setPixels(pixels, 0, GRID_COLS, 0, 0, GRID_COLS, GRID_ROWS)

    // Upscale with bilinear smoothing (anti-alias + filter bitmap) to fill the canvas,
    // matching ctx.imageSmoothingQuality = 'high' + drawImage upscale.
    drawContext.canvas.nativeCanvas.apply {
        val paint = android.graphics.Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
        }
        val src = android.graphics.Rect(0, 0, GRID_COLS, GRID_ROWS)
        val dst = android.graphics.RectF(0f, 0f, w, h)
        drawBitmap(bitmap, src, dst, paint)
    }
    bitmap.recycle()
}

private fun lerpColor(a: Color, b: Color, t: Float): Color {
    val tt = t.coerceIn(0f, 1f)
    return Color(
        red = a.red + (b.red - a.red) * tt,
        green = a.green + (b.green - a.green) * tt,
        blue = a.blue + (b.blue - a.blue) * tt,
        alpha = 1f,
    )
}

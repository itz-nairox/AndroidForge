package com.grade.ice.mesh

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp

/**
 * Port of the HTML `.fade` / `.fade-bottom` elements: a soft vertical mask
 * near the top/bottom edges of the scrolling list so content fades out
 * under the titlebar and at the bottom edge, rather than hard-clipping.
 */
@Composable
fun BoxScope.TopFadeEdge(height: Dp, backgroundColor: Color) {
    Box(
        modifier = Modifier
            .align(Alignment.TopCenter)
            .fillMaxWidth()
            .height(height)
            .background(
                Brush.verticalGradient(
                    0f to backgroundColor,
                    0.7f to backgroundColor.copy(alpha = backgroundColor.alpha * 0.4f),
                    1f to backgroundColor.copy(alpha = 0f),
                ),
            ),
    )
}

@Composable
fun BoxScope.BottomFadeEdge(height: Dp, backgroundColor: Color) {
    Box(
        modifier = Modifier
            .align(Alignment.BottomCenter)
            .fillMaxWidth()
            .height(height)
            .background(
                Brush.verticalGradient(
                    0f to backgroundColor.copy(alpha = 0f),
                    0.3f to backgroundColor.copy(alpha = backgroundColor.alpha * 0.4f),
                    1f to backgroundColor,
                ),
            ),
    )
}

package com.grade.ice

import java.util.Calendar
import java.util.Date

/**
 * Gregorian -> Jalali (Persian) date conversion.
 * Direct Kotlin port of the Python reference (jalaali-js algorithm,
 * based on Kazimierski/Birashk). Pure arithmetic, no external calendar library.
 */
object PersianDate {

    private val gDaysInMonth = intArrayOf(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
    private val jDaysInMonth = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29)

    data class Jalali(val year: Int, val month: Int, val day: Int)

    private fun div(a: Int, b: Int): Int {
        // Python's floor division (//) for ints; Kotlin's Int division already
        // floors for this algorithm's value ranges (all divisors positive,
        // but numerators can be negative for early gy2/gm2 offsets), so we
        // replicate true floor division explicitly for correctness.
        val q = a / b
        val r = a % b
        return if (r != 0 && (r xor b) < 0) q - 1 else q
    }

    fun gregorianToJalali(gy: Int, gm: Int, gd: Int): Jalali {
        val gy2 = gy - 1600
        val gm2 = gm - 1
        val gd2 = gd - 1

        var gDayNo = 365 * gy2 +
            div(gy2 + 3, 4) -
            div(gy2 + 99, 100) +
            div(gy2 + 399, 400)

        for (i in 0 until gm2) {
            gDayNo += gDaysInMonth[i]
        }

        if (gm2 > 1 && ((gy % 4 == 0 && gy % 100 != 0) || (gy % 400 == 0))) {
            gDayNo += 1
        }

        gDayNo += gd2

        var jDayNo = gDayNo - 79

        val jNp = div(jDayNo, 12053)
        jDayNo %= 12053
        // Kotlin's % can be negative like Python's isn't here since jDayNo
        // after subtracting 79 for realistic dates stays non-negative for
        // the supported range; guard defensively anyway.
        if (jDayNo < 0) jDayNo += 12053

        var jy = 979 + 33 * jNp + 4 * div(jDayNo, 1461)

        jDayNo %= 1461
        if (jDayNo < 0) jDayNo += 1461

        if (jDayNo >= 366) {
            jy += div(jDayNo - 1, 365)
            jDayNo = (jDayNo - 1) % 365
        }

        var jm = 0
        var remaining = jDayNo
        var matched = false
        for (i in 0 until 11) {
            if (remaining < jDaysInMonth[i]) {
                jm = i
                matched = true
                break
            }
            remaining -= jDaysInMonth[i]
            jm = i + 1
        }
        if (!matched) {
            jm = 11
        }

        val jd = remaining + 1

        return Jalali(jy, jm + 1, jd)
    }

    fun isEvenDay(gy: Int, gm: Int, gd: Int): Boolean {
        val (_, _, jd) = gregorianToJalali(gy, gm, gd)
        return jd % 2 == 0
    }

    /** Convenience: Jalali day-of-month for a java.util.Date (local calendar fields). */
    fun jalaliDayOfMonth(date: Date): Int {
        val cal = Calendar.getInstance()
        cal.time = date
        val gy = cal.get(Calendar.YEAR)
        val gm = cal.get(Calendar.MONTH) + 1
        val gd = cal.get(Calendar.DAY_OF_MONTH)
        return gregorianToJalali(gy, gm, gd).day
    }

    private val persianDigits = charArrayOf('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹')

    fun toPersianDigits(n: Int): String {
        val s = n.toString()
        val sb = StringBuilder(s.length)
        for (c in s) {
            if (c in '0'..'9') {
                sb.append(persianDigits[c - '0'])
            } else {
                sb.append(c)
            }
        }
        return sb.toString()
    }
}

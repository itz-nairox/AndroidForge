package com.grade.ice

/** A single period's content (subject + teacher). */
data class PeriodContent(val subject: String, val teacher: String)

/**
 * A scheduled period slot at a given [time]. Three shapes:
 * - Fixed: [content] set, happens every day regardless of parity.
 * - Both parities present: [even] and [odd] both set, different content
 *   depending on Jalali day-of-month parity (always happens, content varies).
 * - Single parity only: only [even] or only [odd] set — this period only
 *   exists on that parity; on the other parity this slot is skipped
 *   entirely (the day has one fewer period that day).
 */
data class Period(
    val time: String,
    val content: PeriodContent? = null,
    val even: PeriodContent? = null,
    val odd: PeriodContent? = null,
) {
    /** Returns the content to show for this parity, or null if this period doesn't occur today. */
    fun resolveOrNull(isEven: Boolean): PeriodContent? {
        return when {
            content != null -> content
            even != null && odd != null -> if (isEven) even else odd
            even != null -> if (isEven) even else null
            odd != null -> if (!isEven) odd else null
            else -> null
        }
    }
}

data class DaySchedule(val day: String, val periods: List<Period>) {
    /** Periods that actually occur for the given parity, in order. */
    fun resolvedPeriods(isEven: Boolean): List<Pair<Period, PeriodContent>> =
        periods.mapNotNull { p -> p.resolveOrNull(isEven)?.let { p to it } }
}

object ScheduleData {

    val schedule: List<DaySchedule> = listOf(
        DaySchedule(
            day = "شنبه",
            periods = listOf(
                Period(time = "۷:۴۵", content = PeriodContent("زمین شناسی", "حسینی")),
                Period(time = "۹:۳۰", content = PeriodContent("عربی", "لطفی")),
                Period(time = "۱۱:۱۰", content = PeriodContent("تربیت بدنی", "کلوندی")),
                Period(time = "۱۲:۳۵", content = PeriodContent("محیط زیست", "حسینی")),
            ),
        ),
        DaySchedule(
            day = "یکشنبه",
            periods = listOf(
                Period(time = "۷:۴۵", content = PeriodContent("فیزیک", "احمدی")),
                Period(time = "۹:۳۰", content = PeriodContent("فارسی", "سلطانی")),
                // only on even days — odd days have no period at 11:10
                Period(time = "۱۱:۱۰", even = PeriodContent("حسابان", "فتحی")),
                // only on even days — odd days have no period at 12:35
                Period(time = "۱۲:۳۵", even = PeriodContent("آزمایشگاه", "احمدی")),
            ),
        ),
        DaySchedule(
            day = "دوشنبه",
            periods = listOf(
                Period(time = "۷:۴۵", content = PeriodContent("فیزیک ۲", "احمدی")),
                Period(time = "۹:۳۰", content = PeriodContent("شیمی ۲", "اداک")),
                Period(time = "۱۱:۱۰", content = PeriodContent("دینی ۲", "رضایی")),
                // only on even days — odd days have no period at 12:35
                Period(time = "۱۲:۳۵", even = PeriodContent("نگارش", "سلطانی")),
            ),
        ),
        DaySchedule(
            day = "سه‌شنبه",
            periods = listOf(
                Period(time = "۷:۴۵", content = PeriodContent("حسابان", "فتحی")),
                // both parities present, different content
                Period(
                    time = "۹:۳۰",
                    odd = PeriodContent("شیمی", "اداک"),
                    even = PeriodContent("کارآفرینی", "گنجی"),
                ),
                Period(time = "۱۱:۱۰", content = PeriodContent("هندسه", "شکرالهی")),
                Period(time = "۱۲:۳۵", content = PeriodContent("تاریخ معاصر", "تفسیری")),
            ),
        ),
        DaySchedule(
            day = "چهارشنبه",
            periods = listOf(
                Period(time = "۷:۴۵", content = PeriodContent("خارجه", "عسکری")),
                Period(time = "۹:۳۰", content = PeriodContent("آمار و احتمال", "شکرالهی")),
                // only on odd days — even days have no period at 11:10
                Period(time = "۱۱:۱۰", odd = PeriodContent("خارجه", "عسکری")),
            ),
        ),
    )
}

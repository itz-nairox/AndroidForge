package com.grade.ice.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color

/**
 * Direct port of the HTML :root CSS custom properties (light) and the
 * @media (prefers-color-scheme: dark) / [data-theme="dark"] overrides.
 */
@Immutable
data class GlassPalette(
    val text: Color,
    val textDim: Color,
    val accent: Color,
    val glassBg: Color,
    val glassBg2: Color,
    val glassBorder: Color,
    val hairline: Color,
    val wallTop: Color,
    val wallMid: Color,
    val wallBottom: Color,
    val wallDeep: Color,
)

val LightGlassPalette = GlassPalette(
    text = Color(0xFF1C1C1E),
    textDim = Color(0x993C3C43), // rgba(60,60,67,0.6)
    accent = Color(0xFFFF9F0A),
    glassBg = Color(0x8CFFFFFF),  // rgba(255,255,255,0.55)
    glassBg2 = Color(0x59FFFFFF), // rgba(255,255,255,0.35)
    glassBorder = Color(0xA6FFFFFF), // rgba(255,255,255,0.65)
    hairline = Color(0x263C3C43), // rgba(60,60,67,0.15)
    wallTop = Color(0xFFEAF5FD),
    wallMid = Color(0xFF7EC4F0),
    wallBottom = Color(0xFF1D5FD1),
    wallDeep = Color(0xFF0A2F7A),
)

val DarkGlassPalette = GlassPalette(
    text = Color(0xFFF2F2F7),
    textDim = Color(0x99EBEBF5), // rgba(235,235,245,0.6)
    accent = Color(0xFFFF9F0A),
    glassBg = Color(0x8C2C2C2E),  // rgba(44,44,46,0.55)
    glassBg2 = Color(0x592C2C2E), // rgba(44,44,46,0.35)
    glassBorder = Color(0x1FFFFFFF), // rgba(255,255,255,0.12)
    hairline = Color(0x1AFFFFFF), // rgba(255,255,255,0.1)
    wallTop = Color(0xFF3A5878),
    wallMid = Color(0xFF1C5BB0),
    wallBottom = Color(0xFF0A2F7A),
    wallDeep = Color(0xFF040F33),
)

/** Mesh gradient corner palettes (two, cross-faded), from the HTML's renderMesh(). */
object MeshPalettes {
    val lightA = listOf(
        Color(0xFFA8E6C3), Color(0xFFFFF3A0), Color(0xFFA8C8F0), Color(0xFFD4B3F0),
    )
    val lightB = listOf(
        Color(0xFFFFF3A0), Color(0xFFA8C8F0), Color(0xFFD4B3F0), Color(0xFFA8E6C3),
    )
    val darkA = listOf(
        Color(0xFF1B5E3F), Color(0xFF8A7A1A), Color(0xFF1A2A4A), Color(0xFF4A2A6B),
    )
    val darkB = listOf(
        Color(0xFF8A7A1A), Color(0xFF1A2A4A), Color(0xFF4A2A6B), Color(0xFF1B5E3F),
    )
}

@Composable
fun glassPalette(isDark: Boolean): GlassPalette = if (isDark) DarkGlassPalette else LightGlassPalette

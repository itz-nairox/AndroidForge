package com.grade.ice

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.grade.ice.mesh.BottomFadeEdge
import com.grade.ice.mesh.MeshGradientBackground
import com.grade.ice.mesh.TopFadeEdge
import com.grade.ice.theme.glassPalette

/**
 * Single-activity app, matching the HTML's single-page structure. No custom
 * launcher icon or splash branding (per spec); kept minimal for fast cold
 * start — no heavy init work in onCreate, data is a static in-memory list,
 * and the Jalali parity is computed once per composition rather than on
 * every frame.
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            GradeIceApp()
        }
    }
}

@Composable
private fun GradeIceApp() {
    val isDark = isSystemInDarkTheme()
    val palette = glassPalette(isDark)

    val isEven = remember {
        val now = java.util.Date()
        PersianDate.jalaliDayOfMonth(now) % 2 == 0
    }

    Surface(modifier = Modifier.fillMaxSize(), color = androidx.compose.ui.graphics.Color.Transparent) {
        Box(modifier = Modifier.fillMaxSize()) {
            MeshGradientBackground(modifier = Modifier.fillMaxSize())

            Box(modifier = Modifier.fillMaxSize()) {
                ScheduleList(
                    palette = palette,
                    isEven = isEven,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(
                        start = 16.dp,
                        end = 16.dp,
                        top = 76.dp,
                        bottom = 24.dp,
                    ),
                )

                TopFadeEdge(height = 90.dp, backgroundColor = palette.glassBg)
                BottomFadeEdge(height = 40.dp, backgroundColor = palette.glassBg)

                Titlebar(palette = palette)
            }
        }
    }
}

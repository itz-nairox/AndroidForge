package com.grade.ice

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.grade.ice.glass.GlassSurface
import com.grade.ice.theme.GlassPalette

/**
 * Port of the HTML `.titlebar`: a centered, pill-shaped glass capsule
 * fixed at the top of the screen showing the schedule title.
 */
@Composable
fun Titlebar(palette: GlassPalette, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 12.dp),
        contentAlignment = Alignment.TopCenter,
    ) {
        GlassSurface(
            palette = palette,
            cornerRadius = 999.dp,
            modifier = Modifier
                .wrapContentWidth()
                .height(44.dp),
        ) {
            Box(
                modifier = Modifier.padding(horizontal = 24.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = "برنامه ریاضی یازدهم",
                    color = palette.text,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }
    }
}

package com.grade.ice

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.grade.ice.glass.GlassSurface
import com.grade.ice.theme.GlassPalette
import java.util.Calendar
import java.util.Date

/**
 * Port of the HTML `.scroller > .page > #days`: a vertical scroller of day
 * blocks, each containing a glass card list of period rows. Also ports
 * `scrollToToday()`.
 */
@Composable
fun ScheduleList(
    palette: GlassPalette,
    isEven: Boolean,
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(0.dp),
) {
    val listState = rememberLazyListState()

    LaunchedEffect(Unit) {
        val index = todayScheduleIndex()
        if (index != null) {
            listState.scrollToItem(index)
        }
    }

    LazyColumn(
        state = listState,
        modifier = modifier.fillMaxSize(),
        contentPadding = contentPadding,
        verticalArrangement = Arrangement.spacedBy(28.dp),
    ) {
        itemsIndexed(ScheduleData.schedule) { _, day ->
            DayBlock(day = day, isEven = isEven, palette = palette)
        }
    }
}

/**
 * Port of the HTML's day-of-week -> schedule index mapping used by
 * scrollToToday(). JS getDay(): Sun=0..Sat=6. Schedule order is
 * شنبه(Sat), یکشنبه(Sun), دوشنبه(Mon), سه‌شنبه(Tue), چهارشنبه(Wed).
 * Thursday/Friday (off days) return null (no scroll), matching the
 * original's no-op for days not present in the schedule.
 */
private fun todayScheduleIndex(): Int? {
    val cal = Calendar.getInstance()
    cal.time = Date()
    return when (cal.get(Calendar.DAY_OF_WEEK)) {
        Calendar.SATURDAY -> 0
        Calendar.SUNDAY -> 1
        Calendar.MONDAY -> 2
        Calendar.TUESDAY -> 3
        Calendar.WEDNESDAY -> 4
        else -> null // Thursday, Friday: not in schedule
    }
}

@Composable
private fun DayBlock(day: DaySchedule, isEven: Boolean, palette: GlassPalette) {
    // Only the periods that actually occur today (parity-filtered); a day
    // can have fewer rows on one parity than the other.
    val resolved = day.resolvedPeriods(isEven)

    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = day.day,
            color = palette.textDim,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(start = 20.dp, bottom = 8.dp),
        )

        GlassSurface(
            palette = palette,
            cornerRadius = 26.dp,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                resolved.forEachIndexed { index, (period, content) ->
                    PeriodRow(
                        index = index,
                        time = period.time,
                        content = content,
                        palette = palette,
                        showDivider = index != resolved.lastIndex,
                    )
                }
            }
        }
    }
}

@Composable
private fun PeriodRow(
    index: Int,
    time: String,
    content: PeriodContent,
    palette: GlassPalette,
    showDivider: Boolean,
) {
    Column {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // rank circle
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(palette.accent.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    text = PersianDate.toPersianDigits(index + 1),
                    color = palette.accent,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = content.subject,
                    color = palette.text,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    text = content.teacher,
                    color = palette.textDim,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
            }

            GlassSurface(
                palette = palette,
                cornerRadius = 999.dp,
            ) {
                Text(
                    text = time,
                    color = palette.text,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                )
            }
        }

        if (showDivider) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .padding(start = 56.dp)
                    .background(palette.hairline),
            )
        }
    }
}
